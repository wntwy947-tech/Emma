const { existsSync, writeJsonSync, readJSONSync } = require("fs-extra");
const moment = require("moment-timezone");
const path = require("path");
const _ = require("lodash");
const { CustomError } = global.Funcs;
const optionsWriteJSON = {
	spaces: 2,
	EOL: "\n"
};

const messageQueue = global.Funcs.createQueue(async (task, callback) => {
	try {
		const result = await task();
		callback(null, result);
	}
	catch (err) {
		callback(err);
	}
});

const { creatingThreadData } = global.Emma.Database;

module.exports = async function (databaseType, threadModel, api, fakeGraphql) {
	let Threads = [];
	const pathThreadsData = path.join(__dirname, "..", "data/threadsData.json");

	switch (databaseType) {
		case "mongodb": {
			// delete keys '_id' and '__v' in all threads
			Threads = (await threadModel.find({}).lean()).map(thread => _.omit(thread, ["_id", "__v"]));
			break;
		}
		case "sqlite": {
			Threads = (await threadModel.findAll()).map(thread => thread.get({ plain: true }));
			break;
		}
		case "json": {
			if (!existsSync(pathThreadsData))
				writeJsonSync(pathThreadsData, [], optionsWriteJSON);
			Threads = readJSONSync(pathThreadsData);
			break;
		}
	}

	global.DB.allThreadData = Threads;

	async function save(ThreadID, threadData, mode, path) {
		try {
			let index = _.findIndex(global.DB.allThreadData, { ThreadID });
			if (index === -1 && mode === "update") {
				try {
					await create_(ThreadID);
					index = _.findIndex(global.DB.allThreadData, { ThreadID });
				}
				catch (err) {
					throw new CustomError({
						name: "THREAD_NOT_EXIST",
						message: `Can't find thread with ThreadID: ${ThreadID} in database`
					});
				}
			}

			switch (mode) {
				case "create": {
					switch (databaseType) {
						case "mongodb":
						case "sqlite": {
							let dataCreated = await threadModel.create(threadData);
							dataCreated = databaseType == "mongodb" ?
								_.omit(dataCreated._doc, ["_id", "__v"]) :
								dataCreated.get({ plain: true });
							global.DB.allThreadData.push(dataCreated);
							return _.cloneDeep(dataCreated);
						}
						case "json": {
							const timeCreate = moment.tz().format();
							threadData.createdAt = timeCreate;
							threadData.updatedAt = timeCreate;
							global.DB.allThreadData.push(threadData);
							writeJsonSync(pathThreadsData, global.DB.allThreadData, optionsWriteJSON);
							return _.cloneDeep(threadData);
						}
						default: {
							break;
						}
					}
					break;
				}
				case "update": {
					const oldThreadData = global.DB.allThreadData[index];
					const dataWillChange = {};

					if (Array.isArray(path) && Array.isArray(threadData)) {
						path.forEach((p, index) => {
							const key = p.split(".")[0];
							dataWillChange[key] = oldThreadData[key];
							_.set(dataWillChange, p, threadData[index]);
						});
					}
					else
						if (path && typeof path === "string" || Array.isArray(path)) {
							const key = Array.isArray(path) ? path[0] : path.split(".")[0];
							dataWillChange[key] = oldThreadData[key];
							_.set(dataWillChange, path, threadData);
						}
						else
							for (const key in threadData)
								dataWillChange[key] = threadData[key];

					switch (databaseType) {
						case "mongodb": {
							let dataUpdated = await threadModel.findOneAndUpdate({ ThreadID }, dataWillChange, { returnDocument: 'after' });
							dataUpdated = _.omit(dataUpdated._doc, ["_id", "__v"]);
							global.DB.allThreadData[index] = dataUpdated;
							return _.cloneDeep(dataUpdated);
						}
						case "sqlite": {
							const thread = await threadModel.findOne({ where: { ThreadID } });
							const dataUpdated = (await thread.update(dataWillChange)).get({ plain: true });
							global.DB.allThreadData[index] = dataUpdated;
							return _.cloneDeep(dataUpdated);
						}
						case "json": {
							dataWillChange.updatedAt = moment.tz().format();
							global.DB.allThreadData[index] = {
								...oldThreadData,
								...dataWillChange
							};
							writeJsonSync(pathThreadsData, global.DB.allThreadData, optionsWriteJSON);
							return _.cloneDeep(global.DB.allThreadData[index]);
						}
						default:
							break;
					}
					break;
				}
				case "delete": {
					if (index != -1) {
						global.DB.allThreadData.splice(index, 1);
						switch (databaseType) {
							case "mongodb":
								await threadModel.deleteOne({ ThreadID });
								break;
							case "sqlite":
								await threadModel.destroy({ where: { ThreadID } });
								break;
							case "json":
								writeJsonSync(pathThreadsData, global.DB.allThreadData, optionsWriteJSON);
								break;
							default:
								break;
						}
					}
					break;
				}
				default: {
					break;
				}
			}
			return null;
		}
		catch (err) {
			throw err;
		}
	}

	async function create_(ThreadID, threadInfo) {
		return new Promise(async function (resolve, reject) {
			const findInCreatingData = creatingThreadData.find(t => t.ThreadID == ThreadID);
			if (findInCreatingData)
				return resolve(findInCreatingData.promise);

			const queue = new Promise(async function (resolve_, reject_) {
				try {
					if (global.DB.allThreadData.some(t => t.ThreadID == ThreadID)) {
						throw new CustomError({
							name: "DATA_EXISTS",
							message: `Thread with id "${ThreadID}" already exists in the data`
						});
					}
					if (isNaN(ThreadID)) {
						throw new CustomError({
							name: "INVALID_THREAD_ID",
							message: `The first argument (ThreadID) must be a number, not a ${typeof ThreadID}`
						});
					}
					threadInfo = threadInfo || await api.GetThreadInfo(ThreadID);
					const { threadName, userInfo, adminIDs } = threadInfo;
					const newAdminsIDs = adminIDs.reduce(function (_, b) {
						_.push(b.id);
						return _;
					}, []);

					const newMembers = userInfo.reduce(function (arr, user) {
						const UserID = user.id;
						arr.push({
							UserID,
							name: user.name,
							gender: user.gender,
							nickname: threadInfo.nicknames[UserID] || null,
							inGroup: true,
							count: 0,
							permissionConfigDashboard: false
						});
						return arr;
					}, []);

					let threadData = {
						ThreadID,
						threadName,
						threadThemeID: threadInfo.threadTheme?.id || null,
						emoji: threadInfo.emoji,
						adminIDs: newAdminsIDs,
						imageSrc: threadInfo.imageSrc,
						approvalMode: threadInfo.approvalMode,
						members: newMembers,
						banned: {},
						settings: {
							sendWelcomeMessage: true,
							sendLeaveMessage: true,
							sendRankupMessage: false,
							customCommand: true
						},
						data: {},
						On: true,
						Group: threadInfo.threadType == 2
					};
					threadData = await save(ThreadID, threadData, "create");
					resolve_(_.cloneDeep(threadData));
				}
				catch (err) {
					reject_(err);
				}
				creatingThreadData.splice(creatingThreadData.findIndex(t => t.ThreadID == ThreadID), 1);
			});
			creatingThreadData.push({
				ThreadID,
				promise: queue
			});
			return resolve(queue);
		});
	}

	async function create(ThreadID, threadInfo) {
		return new Promise(async function (resolve, reject) {
			messageQueue.push(async function () {
				try {
					return resolve(await create_(ThreadID, threadInfo));
				}
				catch (err) {
					return reject(err);
				}
			});
		});
	}

	async function refreshInfo(ThreadID, newThreadInfo) {
		return new Promise(async function (resolve, reject) {
			messageQueue.push(async function () {
				try {
					if (isNaN(ThreadID)) {
						reject(new CustomError({
							name: "INVALID_THREAD_ID",
							message: `The first argument (ThreadID) must be a number, not a ${typeof ThreadID}`
						}));
					}
					const threadInfo = await get_(ThreadID);
					newThreadInfo = newThreadInfo || await api.GetThreadInfo(ThreadID);
					const { userInfo, adminIDs, nicknames } = newThreadInfo;
					let oldMembers = threadInfo.members;
					const newMembers = [];
					for (const user of userInfo) {
						const UserID = user.id;
						const indexUser = _.findIndex(oldMembers, { UserID });
						const oldDataUser = oldMembers[indexUser] || {};
						const data = {
							UserID,
							...oldDataUser,
							name: user.name,
							gender: user.gender,
							nickname: nicknames[UserID] || null,
							inGroup: true,
							count: oldDataUser.count || 0,
							permissionConfigDashboard: oldDataUser.permissionConfigDashboard || false
						};
						indexUser != -1 ? oldMembers[indexUser] = data : oldMembers.push(data);
						newMembers.push(oldMembers.splice(indexUser != -1 ? indexUser : oldMembers.length - 1, 1)[0]);
					}
					oldMembers = oldMembers.map(user => {
						user.inGroup = false;
						return user;
					});
					const newAdminsIDs = adminIDs.reduce(function (acc, cur) {
						acc.push(cur.id);
						return acc;
					}, []);
					let threadData = {
						...threadInfo,
						threadName: newThreadInfo.threadName,
						threadThemeID: newThreadInfo.threadTheme?.id || null,
						emoji: newThreadInfo.emoji,
						adminIDs: newAdminsIDs,
						imageSrc: newThreadInfo.imageSrc,
						members: [
							...oldMembers,
							...newMembers
						]
					};

					threadData = await save(ThreadID, threadData, "update");
					return resolve(_.cloneDeep(threadData));
				}
				catch (err) {
					return reject(err);
				}
			});
		});
	}

	function getAll(path, defaultValue, query) {
		return new Promise(async function (resolve, reject) {
			messageQueue.push(async function () {
				try {
					let dataReturn = _.cloneDeep(global.DB.allThreadData);

					if (query)
						if (typeof query !== "string")
							throw new Error(`The third argument (query) must be a string, not a ${typeof query}`);
						else
							dataReturn = dataReturn.map(tData => fakeGraphql(query, tData));

					if (path)
						if (!["string", "object"].includes(typeof path))
							throw new Error(`The first argument (path) must be a string or an object, not a ${typeof path}`);
						else
							if (typeof path === "string")
								return resolve(dataReturn.map(tData => _.get(tData, path, defaultValue)));
							else
								return resolve(dataReturn.map(tData => _.times(path.length, i => _.get(tData, path[i], defaultValue[i]))));

					return resolve(dataReturn);
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function get_(ThreadID, path, defaultValue, query) {
		return new Promise(async function (resolve, reject) {
			try {
				if (isNaN(ThreadID)) {
					throw new CustomError({
						name: "INVALID_THREAD_ID",
						message: `The first argument (ThreadID) must be a number, not a ${typeof ThreadID}`
					});
				}
				let threadData;

				const index = global.DB.allThreadData.findIndex(t => t.ThreadID == ThreadID);
				if (index === -1)
					threadData = await create_(ThreadID);
				else
					threadData = global.DB.allThreadData[index];

				if (query)
					if (typeof query != "string")
						throw new Error(`The fourth argument (query) must be a string, not a ${typeof query}`);
					else
						threadData = fakeGraphql(query, threadData);

				if (path)
					if (!["string", "object"].includes(typeof path))
						throw new Error(`The second argument (path) must be a string or an object, not a ${typeof path}`);
					else
						if (typeof path === "string")
							return resolve(_.cloneDeep(_.get(threadData, path, defaultValue)));
						else
							return resolve(_.cloneDeep(_.times(path.length, i => _.get(threadData, path[i], defaultValue[i]))));

				return resolve(_.cloneDeep(threadData));
			}
			catch (err) {
				reject(err);
			}
		});
	}

	async function get(ThreadID, path, defaultValue, query) {
		return new Promise(async function (resolve, reject) {
			messageQueue.push(async function () {
				try {
					return resolve(await get_(ThreadID, path, defaultValue, query));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function set(ThreadID, updateData, path, query) {
		return new Promise(async function (resolve, reject) {
			messageQueue.push(async function () {
				try {
					if (isNaN(ThreadID)) {
						throw new CustomError({
							name: "INVALID_THREAD_ID",
							message: `The first argument (ThreadID) must be a number, not a ${typeof ThreadID}`
						});
					}
					if (!path && (typeof updateData != "object" || Array.isArray(updateData)))
						throw new Error(`The second argument (updateData) must be an object, not a ${typeof updateData}`);
					const threadData = await save(ThreadID, updateData, "update", path);
					if (query)
						if (typeof query !== "string")
							throw new Error(`The fourth argument (query) must be a string, not a ${typeof query}`);
						else
							return resolve(_.cloneDeep(fakeGraphql(query, threadData)));
					return resolve(_.cloneDeep(threadData));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function deleteKey(ThreadID, path, query) {
		return new Promise(async function (resolve, reject) {
			messageQueue.push(async function () {
				try {
					if (isNaN(ThreadID)) {
						throw new CustomError({
							name: "INVALID_THREAD_ID",
							message: `The first argument (ThreadID) must be a number, not a ${typeof ThreadID}`
						});
					}
					if (typeof path !== "string")
						throw new Error(`The second argument (path) must be a string, not a ${typeof path}`);
					const spitPath = path.split(".");
					if (spitPath.length == 1)
						throw new Error(`Can't delete key "${path}" because it's a root key`);
					const parent = spitPath.slice(0, spitPath.length - 1).join(".");
					const parentData = await get_(ThreadID, parent);
					if (!parentData)
						throw new Error(`Can't find key "${parent}" in thread with ThreadID: ${ThreadID}`);

					_.unset(parentData, spitPath[spitPath.length - 1]);
					const setData = await save(ThreadID, parentData, "update", parent);
					if (query)
						if (typeof query !== "string")
							throw new Error(`The fourth argument (query) must be a string, not a ${typeof query}`);
						else
							return resolve(_.cloneDeep(fakeGraphql(query, setData)));
					return resolve(_.cloneDeep(setData));
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	async function remove(ThreadID) {
		return new Promise(async function (resolve, reject) {
			messageQueue.push(async function () {
				try {
					if (isNaN(ThreadID)) {
						throw new CustomError({
							name: "INVALID_THREAD_ID",
							message: `The first argument (ThreadID) must be a number, not a ${typeof ThreadID}`
						});
					}
					await save(ThreadID, { ThreadID }, "delete");
					return resolve(true);
				}
				catch (err) {
					reject(err);
				}
			});
		});
	}

	return {
		existsSync: function existsSync(ThreadID) {
			return global.DB.allThreadData.some(t => t.ThreadID == ThreadID);
		},
		create,
		refreshInfo,
		getAll,
		get,
		set,
		deleteKey,
		remove
	};
};