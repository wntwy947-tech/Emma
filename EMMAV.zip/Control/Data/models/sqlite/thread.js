module.exports = function (sequelize) {
	const { Model, DataTypes } = require("sequelize");
	class threadModel extends Model { }
	threadModel.init({
		ThreadID: {
			type: DataTypes.STRING,
			primaryKey: true
		},
		threadName: DataTypes.STRING,
		threadThemeID: DataTypes.STRING,
		emoji: DataTypes.STRING,
		adminIDs: {
			type: DataTypes.JSON,
			defaultValue: []
		},
		imageSrc: DataTypes.STRING,
		approvalMode: DataTypes.BOOLEAN,
		members: {
			type: DataTypes.JSON,
			defaultValue: []
		},
		banned: {
			type: DataTypes.JSON,
			defaultValue: {}
		},
		settings: {
			type: DataTypes.JSON,
			defaultValue: {}
		},
		data: {
			type: DataTypes.JSON,
			defaultValue: {}
		},
		Group: DataTypes.BOOLEAN,
		On: DataTypes.BOOLEAN
	}, {
		sequelize,
		modelName: "threads"
	});

	return threadModel;
};