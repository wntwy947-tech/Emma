const crypto = require('crypto');
const os = require("os");
const axios = require("axios");
const fs = require("fs-extra");
const mimeDB = require("mime-db");
const qs = require("qs");
const cheerio = require('cheerio');
const sizeOf = require("image-size");
const sharp = require("sharp");
const Sleep = require('time-sleep');
const { randomUUID } = require('crypto');
const FormData = require('form-data');
const OpenAI = require('openai');
const fsx = require('fs/promises');
const { v4: uuidv4 } = require("uuid");
const moment = require("moment-timezone");
const probe = require('probe-image-size');
const https = require('https');
const modelsInfo = JSON.parse(fs.readFileSync(__dirname + '/../Modules/Scripts/cache/Json/Models.json', 'utf8'));

const agent = new https.Agent({
	rejectUnauthorized: false
});
const ora = require("ora");
const log = require("../Control/Logger/Log.js");

class CustomError extends Error {
	constructor(obj) {
		if (typeof obj === 'string')
			obj = { message: obj };
		if (typeof obj !== 'object' || obj === null)
			throw new TypeError('Object required');
		obj.message ? super(obj.message) : super();
		Object.assign(this, obj);
	}
}
function createQueue(callback) {
	const queue = [];
	const queueObj = {
		push: function (task) {
			queue.push(task);
			if (queue.length == 1)
				queueObj.next();
		},
		running: null,
		length: function () {
			return queue.length;
		},
		next: function () {
			if (queue.length > 0) {
				const task = queue[0];
				queueObj.running = task;
				callback(task, async function (err, result) {
					queueObj.running = null;
					queue.shift();
					queueObj.next();
				});
			}
		}
	};
	return queueObj;
}
const word = [
	'A', 'Á', 'À', 'Ả', 'Ã', 'Ạ', 'a', 'á', 'à', 'ả', 'ã', 'ạ',
	'Ă', 'Ắ', 'Ằ', 'Ẳ', 'Ẵ', 'Ặ', 'ă', 'ắ', 'ằ', 'ẳ', 'ẵ', 'ặ',
	'Â', 'Ấ', 'Ầ', 'Ẩ', 'Ẫ', 'Ậ', 'â', 'ấ', 'ầ', 'ẩ', 'ẫ', 'ậ',
	'B', 'b',
	'C', 'c',
	'D', 'Đ', 'd', 'đ',
	'E', 'É', 'È', 'Ẻ', 'Ẽ', 'Ẹ', 'e', 'é', 'è', 'ẻ', 'ẽ', 'ẹ',
	'Ê', 'Ế', 'Ề', 'Ể', 'Ễ', 'Ệ', 'ê', 'ế', 'ề', 'ể', 'ễ', 'ệ',
	'F', 'f',
	'G', 'g',
	'H', 'h',
	'I', 'Í', 'Ì', 'Ỉ', 'Ĩ', 'Ị', 'i', 'í', 'ì', 'ỉ', 'ĩ', 'ị',
	'J', 'j',
	'K', 'k',
	'L', 'l',
	'M', 'm',
	'N', 'n',
	'O', 'Ó', 'Ò', 'Ỏ', 'Õ', 'Ọ', 'o', 'ó', 'ò', 'ỏ', 'õ', 'ọ',
	'Ô', 'Ố', 'Ồ', 'Ổ', 'Ỗ', 'Ộ', 'ô', 'ố', 'ồ', 'ổ', 'ỗ', 'ộ',
	'Ơ', 'Ớ', 'Ờ', 'Ở', 'Ỡ', 'Ợ', 'ơ', 'ớ', 'ờ', 'ở', 'ỡ', 'ợ',
	'P', 'p',
	'Q', 'q',
	'R', 'r',
	'S', 's',
	'T', 't',
	'U', 'Ú', 'Ù', 'Ủ', 'Ũ', 'Ụ', 'u', 'ú', 'ù', 'ủ', 'ũ', 'ụ',
	'Ư', 'Ứ', 'Ừ', 'Ử', 'Ữ', 'Ự', 'ư', 'ứ', 'ừ', 'ử', 'ữ', 'ự',
	'V', 'v',
	'W', 'w',
	'X', 'x',
	'Y', 'Ý', 'Ỳ', 'Ỷ', 'Ỹ', 'Ỵ', 'y', 'ý', 'ỳ', 'ỷ', 'ỹ', 'ỵ',
	'Z', 'z',
	' '
];

function throwError(command, ThreadID, MessageID) {
	return global.Emma.api.SendMessage(global.Settings.PREFIX, command, ThreadID, MessageID);
}

function getPrefix(ThreadID) {
	if (!ThreadID || isNaN(ThreadID))
		throw new Error('The first argument (ThreadID) must be a number');
	ThreadID = String(ThreadID);
	let prefix = global.Settings.PREFIX;
	const threadData = global.DB.allThreadData.find(t => t.ThreadID == ThreadID);
	if (threadData)
		prefix = threadData.data.prefix || prefix;
	return prefix;
}

function cleanAnilistHTML(text) {
	text = text
		.replace('<br>', '\n')
		.replace(/<\/?(i|em)>/g, '*')
		.replace(/<\/?b>/g, '**')
		.replace(/~!|!~/g, '||')
		.replace("&amp;", "&")
		.replace("&lt;", "<")
		.replace("&gt;", ">")
		.replace("&quot;", '"')
		.replace("&#039;", "'");
	return text;
}
function getExtFromMimeType(mimeType = "") {
	return mimeDB[mimeType] ? (mimeDB[mimeType].extensions || [])[0] || "unknow" : "unknow";
}

const AES = {
	encrypt(cryptKey, crpytIv, plainData) {
		const encipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(cryptKey), Buffer.from(crpytIv));
		let encrypted = encipher.update(plainData);
		encrypted = Buffer.concat([encrypted, encipher.final()]);
		return encrypted.toString('hex');
	},
	decrypt(cryptKey, cryptIv, encrypted) {
		encrypted = Buffer.from(encrypted, "hex");
		const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(cryptKey), Buffer.from(cryptIv, 'binary'));
		let decrypted = decipher.update(encrypted);

		decrypted = Buffer.concat([decrypted, decipher.final()]);

		return String(decrypted);
	},
	makeIv() {
		return Buffer.from(crypto.randomBytes(16)).toString('hex').slice(0, 16);
	}
};

function homeDir() {
	let returnHome, typeSystem;
	const home = process.env["HOME"];
	const user = process.env["LOGNAME"] || process.env["USER"] || process.env["LNAME"] || process.env["USERNAME"];

	switch (process.platform) {
		case "win32": {
			returnHome = process.env.USERPROFILE || process.env.HOMEDRIVE + process.env.HOMEPATH || home || null;
			typeSystem = "win32";
			break;
		}
		case "darwin": {
			returnHome = home || (user ? '/Users/' + user : null);
			typeSystem = "darwin";
			break;
		}
		case "linux": {
			returnHome = home || (process.getuid() === 0 ? '/root' : (user ? '/home/' + user : null));
			typeSystem = "linux";
			break;
		}
		default: {
			returnHome = home || null;
			typeSystem = "unknown";
			break;
		}
	}

	return [typeof os.homedir === 'function' ? os.homedir() : returnHome, typeSystem];
}

function convertTime(miliSeconds, replaceSeconds = "s", replaceMinutes = "m", replaceHours = "h", replaceDays = "d", replaceMonths = "M", replaceYears = "y", notShowZero = false) {
	if (typeof replaceSeconds == 'boolean') {
		notShowZero = replaceSeconds;
		replaceSeconds = "s";
	}
	const second = Math.floor(miliSeconds / 1000 % 60);
	const minute = Math.floor(miliSeconds / 1000 / 60 % 60);
	const hour = Math.floor(miliSeconds / 1000 / 60 / 60 % 24);
	const day = Math.floor(miliSeconds / 1000 / 60 / 60 / 24 % 30);
	const month = Math.floor(miliSeconds / 1000 / 60 / 60 / 24 / 30 % 12);
	const year = Math.floor(miliSeconds / 1000 / 60 / 60 / 24 / 30 / 12);
	let formattedDate = '';

	const dateParts = [
		{ value: year, replace: replaceYears },
		{ value: month, replace: replaceMonths },
		{ value: day, replace: replaceDays },
		{ value: hour, replace: replaceHours },
		{ value: minute, replace: replaceMinutes },
		{ value: second, replace: replaceSeconds }
	];

	for (let i = 0; i < dateParts.length; i++) {
		const datePart = dateParts[i];
		if (datePart.value)
			formattedDate += datePart.value + datePart.replace;
		else if (formattedDate != '')
			formattedDate += '00' + datePart.replace;
		else if (i == dateParts.length - 1)
			formattedDate += '0' + datePart.replace;
	}

	if (formattedDate == '')
		formattedDate = '0' + replaceSeconds;

	if (notShowZero)
		formattedDate = formattedDate.replace(/00\w+/g, '');

	return formattedDate;
}


function getExtFromUrl(url = "") {
	if (!url || typeof url !== "string")
		throw new Error('The first argument (url) must be a string');
	const reg = /(?<=https:\/\/cdn.fbsbx.com\/v\/.*?\/|https:\/\/video.xx.fbcdn.net\/v\/.*?\/|https:\/\/scontent.xx.fbcdn.net\/v\/.*?\/).*?(\/|\?)/g;
	const fileName = url.match(reg)[0].slice(0, -1);
	return fileName.slice(fileName.lastIndexOf(".") + 1);
}



function getTime(timestamps, format) {
	if (!format && typeof timestamps == 'string') {
		format = timestamps;
		timestamps = undefined;
	}

	return moment(timestamps).tz('Africa/Cairo').format(format);
}

function message(Client, Event) {
	async function SendMessageError(err) {
		if (typeof err === "object" && !err.stack) return;
	}
	return {
		Send: async (form, callback) => await Client.SendMessage(form, Event.ThreadID, callback),
		send: async (form, callback) => await Client.SendMessage(form, Event.ThreadID, callback),
		reply: async (form, callback) => await Client.SendMessage(form, Event.ThreadID, callback, Event.MessageID),
		Reply: async (form, callback) => await Client.SendMessage(form, Event.ThreadID, callback, Event.MessageID),
		Edit: async (form) => {
			if (Event?.MessageReply?.SenderID === Client.getCurrentUserID()) {
				return await Client.EditMessage(Event.MessageReply.MessageID, form);
			}
		},
		Unsend: async (MessageID, callback) => await Client.Unsend(MessageID, callback),
		unsend: async (MessageID, callback) => await Client.Unsend(MessageID, callback),
		React: async (emoji) => Client.React(emoji, Event.MessageID, Event.ThreadID),
		react: async (emoji) => Client.React(emoji, Event.MessageID, Event.ThreadID),
		err: async (err) => await SendMessageError(err),
		error: async (err) => await SendMessageError(err)
	};
}


class MidJourney {

	constructor() {

		this.path = './Modules/Scripts/cache/Midjourney.json';

	}

	async ReadToken() {

		try {

			const data = await fsx.readFile(this.path, 'utf-8');

			const token = JSON.parse(data).token;

			return token;

		} catch (error) {

			return null;

		}

	}

	async SaveToken(token) {

		try {

			await fsx.writeFile(this.path, JSON.stringify({ token }));

		} catch (error) {

			console.error('Error saving token:', error);

		}

	}

	async ScrapeToken() {

		const { email } = await this.MakeMail();

		await this.Verificate(email);

		const code = await this.GetMails(email);

		if (code) {

			const { email: registeredEmail, password, Code: verificationCode } = await this.MakeUser(email, code);

			const accessToken = await this.Login(registeredEmail, verificationCode, password);

			if (accessToken) {

				const finalToken = await this.FinalToken(accessToken);

				await this.SaveToken(finalToken);

				return finalToken;

			}

		}

		throw new Error('Failed to scrape token');

	}

	async GetToken() {

		let token = await this.ReadToken();

		if (!token) {

			token = await this.ScrapeToken();

		}

		return token;

	}

	async CallMJ(url, body, token) {

		try {

			const response = await axios.post(`${url}?token=${token}`, body);

			return response.data;

		} catch (error) {

			if (error.response && (error.response.status === 403 || error.response.status === 401 || error.response.status === 402)) {

				token = await this.ScrapeToken();

				return await this.CallMJ(url, body, token);

			}

			throw error;

		}

	}

	RandomPass(length = 12) {

		const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=';

		let password = '';

		for (let i = 0; i < length; i++) {

			const randomIndex = Math.floor(Math.random() * charset.length);

			password += charset[randomIndex];

		}

		return password;

	}

	async MakeMail() {

		const options = {

			method: 'POST',

			url: 'https://api.internal.temp-mail.io/api/v3/email/new',

			data: {

				min_name_length: 10,

				max_name_length: 10

			}

		};

		try {

			const response = await axios.request(options);

			return response.data;

		} catch (error) {



		}

	}

	async Verificate(email) {

		try {

			await axios.post('https://auth.zhishuyun.com/api/v1/email-code', {

				template: "115309",

				receiver: email

			});

		} catch (error) {



		}

	}

	async GetMails(mail) {

		const options = {

			method: 'GET',

			url: `https://api.internal.temp-mail.io/api/v3/email/${mail}/messages`,

			data: null

		};

		try {

			let response = await axios.request(options);

			while (!response.data[0]) {

				response = await axios.request(options);

			}

			let emailText = response.data[0].body_text;

			const codeMatch = emailText.match(/您的邮箱验证码为\s*(\d{6})/);

			const code = codeMatch ? codeMatch[1] : null;

			if (code) {

				return code;

			} else {



				return null;

			}

		} catch (error) {



		}

	}

	async MakeUser(email, code) {

		const password = this.RandomPass();

		try {

			const response = await axios.post('https://auth.zhishuyun.com/api/v1/users', {

				email: email,

				email_code: code,

				password: password

			});

			if (response.status === 200) {

				return { email, password, Code: code };

			} else {



			}

		} catch (error) {



		}

	}

	async Login(email, code, password) {

		try {

			const response = await axios.post('https://auth.zhishuyun.com/api/v1/login/', {

				email: email,

				email_code: code,

				password: password

			});

			if (response.status === 200) {

				const { access_token } = response.data;

				return access_token;

			}

		} catch (error) {



		}

	}

	async FinalToken(auth) {

		try {

			const response = await axios.post(

				'https://data.zhishuyun.com/api/v1/applications/',

				{

					'type': 'Api',

					'api_id': '9a628863-8879-462b-bbee-5dc46505b733'

				},

				{

					headers: {

						'Accept': 'application/json',

						'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',

						'Authorization': 'Bearer ' + auth,

						'Connection': 'keep-alive',

						'Content-Type': 'application/json',

						'Cookie': 'INVITER_ID=undefined',

						'Origin': 'https://data.zhishuyun.com',

						'Referer': 'https://data.zhishuyun.com/services/d87e5e99-b797-4ade-9e73-b896896b0461',

						'Sec-Fetch-Dest': 'empty',

						'Sec-Fetch-Mode': 'cors',

						'Sec-Fetch-Site': 'same-origin',

						'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',

						'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',

						'sec-ch-ua-mobile': '?0',

						'sec-ch-ua-platform': '"Linux"'

					}

				}

			);





			const response1 = await axios.get('https://data.zhishuyun.com/api/v1/applications/', {

				params: {

					'limit': '10',

					'offset': '0',

					'user_id': response.data.user_id,

					'type': 'Api',

					'ordering': '-created_at'

				},

				headers: {

					'Accept': 'application/json',

					'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',

					'Authorization': 'Bearer ' + auth,

					'Connection': 'keep-alive',

					'Cookie': 'INVITER_ID=undefined',

					'Referer': 'https://data.zhishuyun.com/console/applications',

					'Sec-Fetch-Dest': 'empty',

					'Sec-Fetch-Mode': 'cors',

					'Sec-Fetch-Site': 'same-origin',

					'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',

					'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',

					'sec-ch-ua-mobile': '?0',

					'sec-ch-ua-platform': '"Linux"'

				}

			});



			return response1.data.items[0].credential.token;

		} catch (e) {



			return "err";

		}

	}

	async Generate(Prompt) {

		if (!Prompt) return;

		try {

			const Token = await this.GetToken();

			const url = 'https://api.zhishuyun.com/midjourney/imagine';

			const body = {

				prompt: Prompt,

				action: 'generate',

			};

			return await this.CallMJ(url, body, Token);

		} catch (error) {

			if (error.response.data.detail === "internal server error, please contact admin" || error.response.data.detail.includes("Invalid parameter")) return 'Failed to generate image';

			return 'Failed to generate image';

		}

	}

	async Action(Options) {

		if (!Options.action) return;

		try {

			const Token = await this.GetToken();

			const url = 'https://api.zhishuyun.com/midjourney/imagine';

			return await this.CallMJ(url, Options, Token);

		} catch (error) {



			return 'Failed to generate image';

		}

	}



}


function randomString(max, onlyOnce = false, possible) {
	if (!max || isNaN(max))
		max = 10;
	let text = "";
	possible = possible || "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	for (let i = 0; i < max; i++) {
		let random = Math.floor(Math.random() * possible.length);
		if (onlyOnce) {
			while (text.includes(possible[random]))
				random = Math.floor(Math.random() * possible.length);
		}
		text += possible[random];
	}
	return text;
}

async function downloadFile(url = "", path = "") {
	if (!url || typeof url !== "string")
		throw new Error(`The first argument (url) must be a string`);
	if (!path || typeof path !== "string")
		throw new Error(`The second argument (path) must be a string`);
	const getFile = await axios.get(url, {
		responseType: "arraybuffer"
	});
	fs.writeFileSync(path, Buffer.from(getFile.data));
	return path;
}


async function getStreamsFromAttachment(attachments) {
	const streams = [];
	for (const attachment of attachments) {
		const url = attachment.url;
		const ext = Mods.getExtFromUrl(url);
		const fileName = `${Mods.randomString(10)}.${ext}`;
		streams.push({
			pending: axios({
				url,
				method: "GET",
				responseType: "stream"
			}),
			fileName
		});
	}
	for (let i = 0; i < streams.length; i++) {
		const stream = await streams[i].pending;
		stream.data.path = streams[i].fileName;
		streams[i] = stream.data;
	}
	return streams;
}


async function getStreamFromURL(url = "", pathName = "", options = {}) {
	if (!options && typeof pathName === "object") {
		options = pathName;
		pathName = "";
	}
	try {
		if (!url || typeof url !== "string")
			throw new Error(`The first argument (url) must be a string`);
		const response = await axios({
			url,
			method: "GET",
			responseType: "stream",
			...options
		});
		if (!pathName)
			pathName = Mods.randomString(10) + (response.headers["content-type"] ? '.' + Mods.getExtFromMimeType(response.headers["content-type"]) : ".noext");
		response.data.path = pathName;
		return response.data;
	}
	catch (err) {
		throw err;
	}
}



async function uploadImgbb({ file, type = 'file' }) {
	try {
		const res_ = await axios({
			method: 'GET',
			url: 'https://imgbb.com'
		});

		const auth_token = res_.data.match(/auth_token="([^"]+)"/)[1];
		const timestamp = Date.now();

		const res = await axios({
			method: 'POST',
			url: 'https://imgbb.com/json',
			headers: {
				"content-type": "multipart/form-data;",
			},
			data: {
				source: file,
				type: type,
				action: 'upload',
				timestamp: timestamp,
				auth_token: auth_token
			}
		});

		return res.data;
	} catch (err) {
		let error;
		if (err.response) {
			error = new Error();
			Object.assign(error, err.response.data);
		} else
			error = new Error(err.message);

		throw error;
	}
}
async function shortenURL(url) {
	try {
		const result = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`);
		return result.data;
	}
	catch (err) {
		let error;
		if (err.response) {
			error = new Error();
			Object.assign(error, err.response.data);
		}
		else
			error = new Error(err.message);
	}
}
async function findUid(link) {
	const response = await axios.post("https://id.traodoisub.com/api.php", qs.stringify({ link }));
	const uid = response.data.id;
	if (!uid) {
		const err = new Error(response.data.error);
		for (const key in response.data)
			err[key] = response.data[key];
		if (err.error == "Vui lòng thao tác chậm lại") {
			err.name = "SlowDown";
			err.error = "Please wait a few seconds";
		}
		else if (err.error == "Vui lòng nhập đúng link facebook") {
			err.name = "InvalidLink";
			err.error = "Please enter the correct facebook link";
		}
		else if (err.error == "Không thể lấy được dữ liệu vui lòng báo admin!!!") {
			err.name = "CannotGetData";
			err.error = "Unable to get data, please report to admin!!!";
		}
		else if (err.error == "Link không tồn tại hoặc chưa để chế độ công khai!") {
			err.name = "LinkNotExist";
			err.error = "Link does not exist or is not set to public!";
		}
		throw err;
	}
	return uid;
}
function randomNumber(min, max) {
	if (!max) {
		max = min;
		min = 0;
	}
	if (min == null || min == undefined || isNaN(min))
		throw new Error('The first argument (min) must be a number');
	if (max == null || max == undefined || isNaN(max))
		throw new Error('The second argument (max) must be a number');
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function removeHomeDir(fullPath) {
	if (!fullPath || typeof fullPath !== "string")
		throw new Error('The first argument (fullPath) must be a string');
	while (fullPath.includes(process.cwd()))
		fullPath = fullPath.replace(process.cwd(), "");
	return fullPath;
}

function splitPage(arr, limit) {
	const allPage = _.chunk(arr, limit);
	return {
		totalPage: allPage.length,
		allPage
	};
}

function translateAPI(text, lang) {
	return new Promise((resolve, reject) => {
		axios.get(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(text)}`)
			.then(res => {
				resolve(res.data[0][0][0]);
			})
			.catch(err => {
				reject(err);
			});
	});
}
async function share(stream) {
	try {
		const res = await axios({
			method: 'POST',
			url: 'https://api.zippysha.re/upload',
			httpsAgent: agent,
			headers: {
				'Content-Type': 'multipart/form-data'
			},
			data: {
				file: stream
			}
		});

		const fullUrl = res.data.data.file.url.full;
		const res_ = await axios({
			method: 'GET',
			url: fullUrl,
			httpsAgent: agent,
			headers: {
				"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.43"
			}
		});

		const downloadUrl = res_.data.match(/id="download-url"(?:.|\n)*?href="(.+?)"/)[1];
		res.data.data.file.url.download = downloadUrl;

		return downloadUrl;
	} catch (error) {
		console.error(error);
		throw new Error("An error occurred while sharing the file.");
	}
}

class SeaDream {
	constructor() {
		this.Ratios = ["21:9", "16:9", "4:3", "3:2", "1:1", "2:3", "3:4", "9:16", "9:21"];
	}

	ParseRatio(r) {
		const [w, h] = r.split(":").map(Number);
		return w / h;
	}

	RASS(length = 14) {
		const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=";
		return Array.from(
			{ length },
			() => chars[Math.floor(Math.random() * chars.length)]
		).join("");
	}

	async MakeMail() {
		const initResponse = await fetch("https://tempmail100.com/init", {
			method: "POST",
			headers: {
				accept: "*/*",
				"x-requested-with": "XMLHttpRequest",
				Referer: "https://tempmail100.com/",
			},
		});

		const initJson = await initResponse.json();
		const token = initJson.data.token;

		const generateResponse = await fetch(
			"https://tempmail100.com/web/generate",
			{
				method: "POST",
				headers: {
					accept: "*/*",
					authorization: token,
					"x-requested-with": "XMLHttpRequest",
					Referer: "https://tempmail100.com/",
				},
			}
		);

		const mailJson = await generateResponse.json();

		return {
			token,
			email: mailJson.data.address,
		};
	}

	async GetMails(token) {
		const intervalMs = 5000;
		const timeoutMs = 120000;
		const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
		const startTime = Date.now();

		while (true) {
			if (Date.now() - startTime > timeoutMs) {
				throw new Error("Timeout: security email not received");
			}

			const emailsResponse = await fetch(
				"https://tempmail100.com/web/emails",
				{
					method: "GET",
					headers: {
						accept: "*/*",
						authorization: token,
						"x-requested-with": "XMLHttpRequest",
						Referer: "https://tempmail100.com/",
					},
				}
			);

			const emailsJson = await emailsResponse.json();
			const emails = emailsJson?.data?.list ?? [];

			const targetEmail = emails.find(
				(mail) =>
					mail.fromAddress === "notice@sgmail.fluxproweb.com" &&
					mail.subject === "Account security code"
			);

			if (targetEmail) {
				const { uuid } = targetEmail;

				const contentResponse = await fetch(
					`https://tempmail100.com/emails/content/${uuid}`,
					{
						method: "GET",
						headers: {
							accept: "application/json, text/javascript, */*; q=0.01",
							authorization: token,
							"x-requested-with": "XMLHttpRequest",
						},
						credentials: "include",
					}
				);

				const contentJson = await contentResponse.json();
				const content = contentJson?.data?.content ?? "";

				const match = content.match(/\b\d{6}\b/);
				if (!match) {
					throw new Error("Security code not found");
				}

				return match[0];
			}

			await sleep(intervalMs);
		}
	}


	GetNearest(width, height) {
		const actual = width / height;
		let best = this.Ratios[0];
		let diff = Math.abs(actual - this.ParseRatio(best));
		for (const r of this.Ratios) {
			const d = Math.abs(actual - this.ParseRatio(r));
			if (d < diff) {
				best = r;
				diff = d;
			}
		}
		return best.split(":").map(Number);
	}

	async SignUser(Email, Username, Password) {
		const Data = JSON.stringify([
			{
				email: Email,
				userName: Username,
				password: Password,
			},
		]);
		const Config = {
			method: "POST",
			url: "https://fluxproweb.com",
			headers: {
				"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
				"Content-Type": "text/plain;charset=UTF-8",
				"next-action": "424401cbe4e8b1b79045e4ac3dcf3d788c2156dd",
			},
			data: Data,
		};
		const Response = await axios.request(Config);
		return Response.data;
	}

	async VerifyUser(Email, Code) {
		const Data = JSON.stringify([
			{
				email: Email,
				emailCode: Code,
			},
		]);
		const Config = {
			method: "POST",
			url: "https://fluxproweb.com",
			headers: {
				"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
				"Content-Type": "text/plain;charset=UTF-8",
				"next-action": "efbaa6169049c8cb5fd4fd1abe810d880738ab19",
			},
			data: Data,
		};
		const Response = await axios.request(Config);
		return Response.data;
	}

	async LoginUser(Email, Password) {
		const Data = JSON.stringify([
			{
				email: Email,
				password: Password,
			},
		]);
		const Config = {
			method: "POST",
			url: "https://fluxproweb.com",
			headers: {
				"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
				"Content-Type": "text/plain;charset=UTF-8",
				"next-action": "1c7778f900ce2db3f2c455a90e709ef29ae30db3",
			},
			data: Data,
			withCredentials: true,
			maxRedirects: 0,
		};
		const Response = await axios.request(Config);
		const Cookies = Response.headers["set-cookie"] || [];
		const cookieStr = Array.isArray(Cookies) ? Cookies.join("; ") : (Cookies || "");
		return cookieStr;
	}

	async GetPresignedUrl(Token, Length = 1) {
		const Response = await axios.request({
			method: "POST",
			url: "https://api2.tap4.ai/image/presignedUrl",
			headers: {
				"Content-Type": "application/json",
				authorization: `Bearer ${Token}`,
			},
			data: {
				site: "fluxproweb.com",
				mineType: Array(Length).fill("image/jpeg"),
			},
		});
		return Response.data;
	}

	async UploadImages(Urls, Buffers) {
		const Results = [];
		for (let I = 0; I < Urls.length; I++) {
			try {
				await axios.put(Urls[I].signedUrl, Buffers[I], {
					headers: { "Content-Type": "image/jpeg" },
				});
				Results.push(Urls[I].url);
			} catch { }
		}
		return Results;
	}

	async ToBuffer(Urls) {
		const Buffers = [];
		for (let I = 0; I < Urls.length; I++) {
			const Response = await axios.get(Urls[I], {
				responseType: "arraybuffer",
			});
			Buffers.push(Buffer.from(Response.data));
		}
		return Buffers;
	}

	async Sleep(TaskID, Token, Interval = 2000) {
		const Url = `https://api2.tap4.ai/image/getResult/${TaskID}?site=fluxproweb.com`;
		while (true) {
			const Response = await axios.get(Url, {
				headers: { authorization: `Bearer ${Token}` },
			});
			const Result = Response.data;
			if (!Result.data || Result.data.status === "success") {
				return Result;
			}
			await new Promise((R) => setTimeout(R, Interval));
		}
	}

	async SeeDreamEdit(Prompt, ImageUrl, Token, Width, Height) {
		const Response = await axios.post(
			"https://api2.tap4.ai/image/generator4login/async",
			{
				site: "fluxproweb.com",
				imageType: "seedream-4-5",
				platformType: 44,
				modelName: "seedream-v4.5-edit",
				isPublic: 0,
				prompt: Prompt,
				outputPrompt: Prompt,
				width: Width,
				height: Height,
				resolution: "4k",
				imageUrlList: ImageUrl,
			},
			{ headers: { authorization: `Bearer ${Token}` } }
		);
		return Response.data;
	}

	async SeeDreamGen(Prompt, Token, Width, Height) {
		const Response = await axios.post(
			"https://api2.tap4.ai/image/generator4login/async",
			{
				site: "fluxproweb.com",
				imageType: "seedream-4-5",
				platformType: 44,
				modelName: "seedream-v4.5",
				isPublic: 0,
				prompt: Prompt,
				outputPrompt: Prompt,
				width: Width,
				height: Height,
				resolution: "4k",
			},
			{ headers: { authorization: `Bearer ${Token}` } }
		);
		return Response.data;
	}

	async AuthFlow() {
		const username = crypto.randomBytes(8).toString("hex");
		const password = this.RASS();

		const { email, token } = await this.MakeMail();
		await this.SignUser(email, username, password);

		const code = await this.GetMails(token);
		await this.VerifyUser(email, code);

		const cookie = await this.LoginUser(email, password);
		const decoded = cookie ? decodeURIComponent(cookie) : "";

		const match = decoded.match(
			/Authorization=(?:Bearer\s*)?([A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+)/
		);

		if (!match) {
			throw new Error("Authorization token not found in cookie");
		}

		return match[1];
	}

	async Edit(Prompt, Images) {
		const ImageUrls = Array.isArray(Images) ? Images : [Images];
		const Token = await this.AuthFlow();
		const Buffers = await this.ToBuffer(ImageUrls);
		const dimensions = sizeOf(Buffers[0]);
		const [Width, Height] = this.GetNearest(dimensions.width, dimensions.height);

		const Presigned = await this.GetPresignedUrl(Token, ImageUrls.length);
		const Urls = await this.UploadImages(Presigned.rows, Buffers);

		const Task = await this.SeeDreamEdit(Prompt, Urls, Token, Width, Height);
		const Result = await this.Sleep(Task.data.key, Token);
		return Result.data.imageResponseVo;
	}

	async Gen(Prompt, Width = 16, Height = 9) {
		const Token = await this.AuthFlow();
		const Task = await this.SeeDreamGen(Prompt, Token, Width, Height);
		const Result = await this.Sleep(Task.data.key, Token);
		return Result.data.imageResponseVo;
	}
}

const translate = async function (text, sourceLang, targetLang) {
	try {
		const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sourceLang}&tl=${targetLang}&dt=t&q=${encodeURIComponent(
			text
		)}`;
		const res = await axios.get(url);
		const translation = res.data[0].map((item) => item[0]).join("");
		return translation;
	} catch (error) {
		throw new Error("Error translating text");
	}
}

class NanoBanana {
	constructor() {
		this.Ratios = ["21:9", "16:9", "4:3", "3:2", "1:1", "2:3", "3:4", "9:16", "9:21"];
	}

	ParseRatio(r) {
		const [w, h] = r.split(":").map(Number);
		return w / h;
	}

	RASS(length = 14) {
		const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=";
		return Array.from(
			{ length },
			() => chars[Math.floor(Math.random() * chars.length)]
		).join("");
	}

	async MakeMail() {
		const initResponse = await fetch("https://tempmail100.com/init", {
			method: "POST",
			headers: {
				accept: "*/*",
				"x-requested-with": "XMLHttpRequest",
				Referer: "https://tempmail100.com/",
			},
		});

		const initJson = await initResponse.json();
		const token = initJson.data.token;

		const generateResponse = await fetch(
			"https://tempmail100.com/web/generate",
			{
				method: "POST",
				headers: {
					accept: "*/*",
					authorization: token,
					"x-requested-with": "XMLHttpRequest",
					Referer: "https://tempmail100.com/",
				},
			}
		);

		const mailJson = await generateResponse.json();

		return {
			token,
			email: mailJson.data.address,
		};
	}

	async GetMails(token) {
		const intervalMs = 5000;
		const timeoutMs = 120000;
		const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
		const startTime = Date.now();

		while (true) {
			if (Date.now() - startTime > timeoutMs) {
				throw new Error("Timeout: security email not received");
			}

			const emailsResponse = await fetch(
				"https://tempmail100.com/web/emails",
				{
					method: "GET",
					headers: {
						accept: "*/*",
						authorization: token,
						"x-requested-with": "XMLHttpRequest",
						Referer: "https://tempmail100.com/",
					},
				}
			);

			const emailsJson = await emailsResponse.json();
			const emails = emailsJson?.data?.list ?? [];

			const targetEmail = emails.find(
				(mail) =>
					mail.subject === "Account security code"
			);

			if (targetEmail) {
				const { uuid } = targetEmail;

				const contentResponse = await fetch(
					`https://tempmail100.com/emails/content/${uuid}`,
					{
						method: "GET",
						headers: {
							accept: "application/json, text/javascript, */*; q=0.01",
							authorization: token,
							"x-requested-with": "XMLHttpRequest",
						},
						credentials: "include",
					}
				);

				const contentJson = await contentResponse.json();
				const content = contentJson?.data?.content ?? "";

				const match = content.match(/\b\d{6}\b/);
				if (!match) {
					throw new Error("Security code not found");
				}

				return match[0];
			}

			await sleep(intervalMs);
		}
	}

	GetNearest(width, height) {
		const actual = width / height;
		let best = this.Ratios[0];
		let diff = Math.abs(actual - this.ParseRatio(best));
		for (const r of this.Ratios) {
			const d = Math.abs(actual - this.ParseRatio(r));
			if (d < diff) {
				best = r;
				diff = d;
			}
		}
		return best.split(":").map(Number);
	}

	async SignUser(Email, Username, Password) {
		const Data = JSON.stringify([
			{
				email: Email,
				userName: Username,
				password: Password,
			},
		]);
		const Config = {
			method: "POST",
			url: "https://fluxproweb.com",
			headers: {
				"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
				"Content-Type": "text/plain;charset=UTF-8",
				"next-action": "424401cbe4e8b1b79045e4ac3dcf3d788c2156dd",
			},
			data: Data,
		};
		const Response = await axios.request(Config);
		return Response.data;
	}

	async VerifyUser(Email, Code) {
		const Data = JSON.stringify([
			{
				email: Email,
				emailCode: Code,
			},
		]);
		const Config = {
			method: "POST",
			url: "https://fluxproweb.com",
			headers: {
				"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
				"Content-Type": "text/plain;charset=UTF-8",
				"next-action": "efbaa6169049c8cb5fd4fd1abe810d880738ab19",
			},
			data: Data,
		};
		const Response = await axios.request(Config);
		return Response.data;
	}

	async LoginUser(Email, Password) {
		const Data = JSON.stringify([
			{
				email: Email,
				password: Password,
			},
		]);
		const Config = {
			method: "POST",
			url: "https://fluxproweb.com",
			headers: {
				"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
				"Content-Type": "text/plain;charset=UTF-8",
				"next-action": "1c7778f900ce2db3f2c455a90e709ef29ae30db3",
			},
			data: Data,
			withCredentials: true,
			maxRedirects: 0,
		};
		const Response = await axios.request(Config);
		const Cookies = Response.headers["set-cookie"] || [];
		const cookieStr = Array.isArray(Cookies) ? Cookies.join("; ") : (Cookies || "");
		return cookieStr;
	}

	async GetPresignedUrl(Token, Length = 1) {
		const Response = await axios.request({
			method: "POST",
			url: "https://api2.tap4.ai/image/presignedUrl",
			headers: {
				"Content-Type": "application/json",
				authorization: `Bearer ${Token}`,
			},
			data: {
				site: "fluxproweb.com",
				mineType: Array(Length).fill("image/jpeg"),
			},
		});
		return Response.data;
	}

	async UploadImages(Urls, Buffers) {
		const Results = [];
		for (let I = 0; I < Urls.length; I++) {
			try {
				await axios.put(Urls[I].signedUrl, Buffers[I], {
					headers: { "Content-Type": "image/jpeg" },
				});
				Results.push(Urls[I].url);
			} catch { }
		}
		return Results;
	}

	async ToBuffer(Urls) {
		const Buffers = [];
		for (let I = 0; I < Urls.length; I++) {
			const Response = await axios.get(Urls[I], {
				responseType: "arraybuffer",
			});
			Buffers.push(Buffer.from(Response.data));
		}
		return Buffers;
	}

	async Sleep(TaskID, Token, Interval = 2000) {
		const Url = `https://api2.tap4.ai/image/getResult/${TaskID}?site=fluxproweb.com`;
		while (true) {
			const Response = await axios.get(Url, {
				headers: { authorization: `Bearer ${Token}` },
			});
			const Result = Response.data;
			if (!Result.data || Result.data.status === "success") {
				return Result;
			}
			await new Promise((R) => setTimeout(R, Interval));
		}
	}

	async NanoEdit(Prompt, ImageUrl, Token, Width, Height) {
		const Response = await axios.post(
			"https://api2.tap4.ai/image/generator4login/async",
			{
				site: "fluxproweb.com",
				imageType: "nano-banana-pro-image",
				platformType: 39,
				modelName: "gemini-3-pro-image-preview-edit",
				isPublic: 0,
				prompt: Prompt,
				outputPrompt: Prompt,
				width: Width,
				height: Height,
				resolution: "1k",
				supportRatio: true,
				imageUrlList: ImageUrl,
			},
			{ headers: { authorization: `Bearer ${Token}` } }
		);
		return Response.data;
	}

	async NanoGen(Prompt, Token, Width, Height) {
		const Response = await axios.post(
			"https://api2.tap4.ai/image/generator4login/async",
			{
				site: "fluxproweb.com",
				imageType: "nano-banana-pro-image",
				platformType: 39,
				modelName: "gemini-3-pro-image-preview",
				isPublic: 0,
				prompt: Prompt,
				outputPrompt: Prompt,
				width: Width,
				height: Height,
				supportRatio: true,
				resolution: "1k",
			},
			{ headers: { authorization: `Bearer ${Token}` } }
		);
		return Response.data;
	}

	async AuthFlow() {
		const username = crypto.randomBytes(8).toString("hex");
		const password = this.RASS();

		const { email, token } = await this.MakeMail();
		await this.SignUser(email, username, password);

		const code = await this.GetMails(token);
		await this.VerifyUser(email, code);

		const cookie = await this.LoginUser(email, password);
		const decoded = cookie ? decodeURIComponent(cookie) : "";

		const match = decoded.match(
			/Authorization=(?:Bearer\s*)?([A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+)/
		);

		if (!match) {
			throw new Error("Authorization token not found in cookie");
		}

		return match[1];
	}

	async Edit(Prompt, Images) {
		const ImageUrls = Array.isArray(Images) ? Images : [Images];
		const Token = await this.AuthFlow();
		const Buffers = await this.ToBuffer(ImageUrls);
		const dimensions = sizeOf(Buffers[0]);
		const [Width, Height] = this.GetNearest(dimensions.width, dimensions.height);

		const Presigned = await this.GetPresignedUrl(Token, ImageUrls.length);
		const Urls = await this.UploadImages(Presigned.rows, Buffers);

		const Task = await this.NanoEdit(Prompt, Urls, Token, Width, Height);
		const Result = await this.Sleep(Task.data.key, Token);
		return Result.data.imageResponseVo;
	}

	async Gen(Prompt, Width = 16, Height = 9) {
		const Token = await this.AuthFlow();
		const Task = await this.NanoGen(Prompt, Token, Width, Height);
		const Result = await this.Sleep(Task.data.key, Token);
		return Result.data.imageResponseVo;
	}
}

async function PinLens(Url) {
	try {
		const imgr = await axios.get(Url, { responseType: "arraybuffer" });
		const buffer = imgr.data;

		const formData = new FormData();
		formData.append("camera_type", "0");
		formData.append("source_type", "1");
		formData.append("video_autoplay_disabled", "1");
		formData.append("fields", "pin.{description,id,created_at},pin.image_large_url");
		formData.append("page_size", "250");
		formData.append("image", buffer, { filename: "image.jpg", contentType: "image/jpeg" });


		const headers = {
			authorization: 'Bearer pina_AEATFWAVAC6I4BIAGBAKGD3PYOOL3GYBABHO3D26K5IAJNTLVVZCT4HEK3AREZZEOOHEHZKV5CQQGB6IXSAQJZROYUYIPTYA',
			...formData.getHeaders(),
		};


		const response = await axios.post(
			"https://api.pinterest.com/v3/visual_search/lens/search/",
			formData,
			{ headers }
		);

		const Pics = [];
		for (let Pic of response.data.data) {
			Pics.push(Pic.image_large_url);
		}

		return Pics;
	} catch (err) {
		return [];
	}
}

async function Pinterest(search) {
	const url = 'https://api.pinterest.com/v3/search/pins/';
	const params = {
		query: search,
		etslf: 25901,
		fields: 'explorearticle.cover_images[474x,236x,280x280],pin.images[736x,236x],board.images[150x150],user.explicitly_followed_by_me,pin.story_pin_data_id,pin.story_pin_data(),explorearticle.dominant_colors,board.id,pin.domain,user.last_name,pincarouseldata.id,user.is_partner,pin.is_eligible_for_brand_catalog,pin.tracking_params,pin.promoter(),pin.aggregated_pin_data(),video.duration,user.partner(),pincarouselslot.details,pin.source_interest(),pin.promoted_android_deep_link,pin.ad_match_reason,explorearticle.type,pincarouseldata.carousel_slots,pin.is_repin,pin.is_video,board.collaborator_invites_enabled,pin.is_native,pincarouselslot.rich_metadata,board.category,user.show_creator_profile,pin.category,user.id,pin.link,pin.requires_advertiser_attribution,pin.is_cpc_ad,pin.pinner(),aggregatedpindata.is_shop_the_look,pin.grid_title,aggregatedpindata.aggregated_stats,board.privacy,pin.id,pin.comment_count,pin.is_full_width,pin.promoted_is_removable,pin.native_creator(),pin.type,pin.dark_profile_link,pin.done_by_me,aggregatedpindata.comment_count,board.archived_by_me_at,user.custom_gender,explorearticle.subtitle,aggregatedpindata.did_it_data,board.name,pin.promoted_is_max_video,pin.via_pinner,explorearticle.show_cover,pin.image_crop,pincarouseldata.index,pin.dominant_color,pincarouselslot.images[345x,750x],aggregatedpindata.pin_tags,pin.is_eligible_for_web_closeup,pincarouselslot.title,pin.ad_destination_url,board.created_at,pin.image_signature,explorearticle.curator(),explorearticle.title,board.followed_by_me,user.full_name,pin.videos(),aggregatedpindata.pin_tags_chips,pin.closeup_description,board.owner(),user.is_default_image,pincarouselslot.id,user.first_name,explorearticle.video_cover_pin(),storypindata.page_count,pincarouselslot.domain,pin.created_at,pincarouselslot.link,user.type,board.type,aggregatedpindata.id,board.url,pin.description,pin.board(),pin.is_promoted,pin.cacheable_id,pin.carousel_data(),board.should_show_board_activity,explorearticle.content_type,user.verified_identity,explorearticle.story_category,board.image_cover_url,pin.shopping_flags,pin.embed(),pin.is_downstream_promotion,board.section_count,user.gender,pin.recommendation_reason,aggregatedpindata.is_stela,video.video_list[V_HLSV4],user.image_medium_url,user.username,pincarouselslot.ad_destination_url,explorearticle.id,video.id,board.pin_count,pin.rich_summary()',
		eq: 'gojo',
		dynamic_grid_stories: 6,
		page_size: 200,
		asterix: true,
		commerce_only: false,
		filters: '',
		rs: 'autocomplete',
		'term_meta[0]': 'gojo satoru|autocomplete|0'
	};

	const headers = {
		'authorization': 'Bearer pina_AEATFWAVAC6I4BIAGBAKGD3PYOOL3GYBABHO3D26K5IAJNTLVVZCT4HEK3AREZZEOOHEHZKV5CQQGB6IXSAQJZROYUYIPTYA'
	};

	const response = await axios.get(url, { params, headers });
	const Data = response.data.data
		.filter(item => item.type === "pin")
		.map((item, index) => {
			let imageUrls = [];

			if (item.carousel_data && item.carousel_data.carousel_slots) {
				imageUrls = item.carousel_data.carousel_slots
					.map(slot => slot.images?.['736x']?.url)
					.filter(url => url);
			} else {

				const singleImageUrl = item.images?.['736x']?.url || item.link || '';
				if (singleImageUrl) {
					imageUrls.push(singleImageUrl);
				}
			}

			return {
				id: item.id,
				title: item.grid_title || item.title || '',
				image_urls: imageUrls
			};
		})
		.filter(item => item.image_urls.length > 0);

	const imgs = Data.flatMap(pin => pin.image_urls);

	return imgs

};

async function DiMentions(url) {
	const result = await probe(url);
	return { width: result.width, height: result.height };
}

function UID() {
	const characters = '0123456789abcdef';
	let uid = '2';
	for (let i = 0; i < 15; i++) {
		uid += characters.charAt(Math.floor(Math.random() * characters.length));
	}
	return uid;
}
function Settings(modelNumber) {
	return modelsInfo[modelNumber] || { id: 0, name: "Anime Premium" };
}
async function AiMirror(Url, Model) {
	try {
		const imageUrl = Url;
		let modelNumber = parseInt(Model);
		if (isNaN(modelNumber) || !(modelNumber in modelsInfo)) {
			modelNumber = 1;
		}
		const modelSettings = Settings(modelNumber);
		const modelId = modelSettings.id;
		const modelName = modelSettings.name;


		const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
		const imageBuffer = Buffer.from(response.data, 'binary');
		const dimensions = await DiMentions(imageUrl);
		const aspectRatio = dimensions.width / dimensions.height;


		const supportedAr = {
			"1:1": { height: 768, width: 768 },
			"3:4": { height: 1024, width: 768 },
			"4:3": { height: 768, width: 1024 },
			"4:5": { height: 960, width: 768 },
			"5:4": { height: 768, width: 960 },
			"9:16": { height: 1280, width: 720 },
			"16:9": { height: 720, width: 1280 }
		};


		let closestAR = null;
		let closest = null;
		let minDiff = Infinity;
		for (const ratio in supportedAr) {
			const dimensions = supportedAr[ratio];
			const difference = Math.abs(aspectRatio - (dimensions.width / dimensions.height));
			if (difference < minDiff) {
				closestAR = ratio;
				closest = dimensions;
				minDiff = difference;
			}
		}

		const uid = UID();


		const { data: uploadDetails } = await axios.get('https://be.aimirror.fun/app_token/v2', {
			params: {
				cropped_image_hash: 'image.jpeg',
				model_id: modelId,
				version: '5.2.0',
				uid: uid
			},
			headers: {
				'User-Agent': 'AIMirror/3.12.0+91 (android)',
				'Accept-Encoding': 'gzip',
				'store': 'googleplay',
				'uid': uid,
				'env': 'PRO',
				'accept-language': 'en',
				'package-name': 'com.ai.polyverse.mirror',
				'app-version': '5.2.0+133'
			}
		});


		const data = new FormData();
		for (const [key, value] of Object.entries(uploadDetails)) {
			if (key !== 'upload_host') {
				data.append(key, value);
			}
		}
		data.append('file', imageBuffer, { filename: 'image.jpeg' });


		await axios.post(uploadDetails.upload_host, data, {
			headers: data.getHeaders(),
		});



		const requestData = {
			model_id: modelId,
			cropped_image_key: uploadDetails.key,
			cropped_height: closest.height,
			cropped_width: closest.width,
			package_name: 'com.ai.polyverse.mirror',
			ext_args: {
				imagine_value2: 50,
				custom_prompt: ""
			},
			version: '5.2.0',
			is_free_trial: false
		};


		const { data: secondRequestResponse } = await axios.post('https://be.aimirror.fun/draw?uid=' + uid, requestData, {
			headers: {
				'User-Agent': 'AIMirror/5.2.0+133  (android)',
				'Accept-Encoding': 'gzip',
				'Content-Type': 'application/json',
				'store': 'googleplay',
				'uid': uid,
				'env': 'PRO',
				'accept-language': 'en',
				'package-name': 'com.ai.polyverse.mirror',
				'app-version': '5.2.0+133'
			}
		});

		let drawRequestId = secondRequestResponse.draw_request_id;
		let drawStatus = secondRequestResponse.draw_status;


		while (drawStatus === 'WAITING' || drawStatus === 'RENDERING') {
			if (drawStatus === 'WAITING') await Sleep(35000);
			else await Sleep(20000);
			const drawStatusResponse = await axios.get(`https://be.aimirror.fun/draw/process?draw_request_id=${drawRequestId}&uid=${uid}`, {
				headers: {
					'User-Agent': 'AIMirror/5.2.0+133  (android)',
					'Accept-Encoding': 'gzip',
					'store': 'googleplay',
					'uid': uid,
					'env': 'PRO',
					'accept-language': 'en',
					'package-name': 'com.ai.polyverse.mirror',
					'app-version': '5.2.0+133'
				}
			});
			drawStatus = drawStatusResponse.data.draw_status;
			if (drawStatus === 'SUCCEED') {
				const genimage = drawStatusResponse.data.generated_image_addresses[0];
				const genres = await axios.get(genimage, { responseType: 'stream' });
				const Done = {
					Image: genres.data,
					Number: modelNumber,
					Name: modelName
				};
				return Done;
			}
		}
	} catch (error) {
	}
}

class Ghibili {
	constructor() {
		this.Ratios = ["21:9", "16:9", "4:3", "3:2", "1:1", "2:3", "3:4", "9:16", "9:21"];
	}

	ParseRatio(r) {
		const [w, h] = r.split(":").map(Number);
		return w / h;
	}

	RASS(length = 14) {
		const chars =
			"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=";

		return Array.from({ length }, () =>
			chars[Math.floor(Math.random() * chars.length)]
		).join("");
	}

	async MakeMail() {
		const initResponse = await fetch("https://tempmail100.com/init", {
			method: "POST",
			headers: {
				accept: "*/*",
				"x-requested-with": "XMLHttpRequest",
				Referer: "https://tempmail100.com/",
			},
		});

		const initJson = await initResponse.json();
		const token = initJson.data.token;

		const generateResponse = await fetch(
			"https://tempmail100.com/web/generate",
			{
				method: "POST",
				headers: {
					accept: "*/*",
					authorization: token,
					"x-requested-with": "XMLHttpRequest",
					Referer: "https://tempmail100.com/",
				},
			}
		);

		const mailJson = await generateResponse.json();

		return {
			token,
			email: mailJson.data.address,
		};
	}

	async GetMails(token) {
		const intervalMs = 5000;
		const timeoutMs = 120000;
		const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
		const startTime = Date.now();

		while (true) {
			if (Date.now() - startTime > timeoutMs) {
				throw new Error("Timeout: security email not received");
			}

			const emailsResponse = await fetch(
				"https://tempmail100.com/web/emails",
				{
					method: "GET",
					headers: {
						accept: "*/*",
						authorization: token,
						"x-requested-with": "XMLHttpRequest",
						Referer: "https://tempmail100.com/",
					},
				}
			);

			const emailsJson = await emailsResponse.json();
			const emails = emailsJson?.data?.list ?? [];

			const targetEmail = emails.find(
				(mail) =>
					mail.fromAddress === "notice@sgmail.fluxproweb.com" &&
					mail.subject === "Account security code"
			);

			if (targetEmail) {
				const { uuid } = targetEmail;

				const contentResponse = await fetch(
					`https://tempmail100.com/emails/content/${uuid}`,
					{
						method: "GET",
						headers: {
							accept: "application/json, text/javascript, */*; q=0.01",
							authorization: token,
							"x-requested-with": "XMLHttpRequest",
						},
						credentials: "include",
					}
				);

				const contentJson = await contentResponse.json();
				const content = contentJson?.data?.content ?? "";

				const match = content.match(/\b\d{6}\b/);
				if (!match) {
					throw new Error("Security code not found");
				}
				return match[0];
			}

			await sleep(intervalMs);
		}
	}


	GetNearest(width, height) {
		const actual = width / height;
		let best = this.Ratios[0];
		let diff = Math.abs(actual - this.ParseRatio(best));

		for (const r of this.Ratios) {
			const d = Math.abs(actual - this.ParseRatio(r));
			if (d < diff) {
				best = r;
				diff = d;
			}
		}

		return best.split(":").map(Number);
	}

	async SignUser(email, username, password) {
		const Data = JSON.stringify([
			{
				email,
				userName: username,
				password,
			},
		]);

		const Response = await axios.request({
			method: "POST",
			url: "https://fluxproweb.com",
			headers: {
				"User-Agent":
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
				"Content-Type": "text/plain;charset=UTF-8",
				"next-action": "424401cbe4e8b1b79045e4ac3dcf3d788c2156dd",
			},
			data: Data,
		});

		return Response.data;
	}

	async VerifyUser(email, code) {
		const Data = JSON.stringify([
			{
				email,
				emailCode: code,
			},
		]);

		const Response = await axios.request({
			method: "POST",
			url: "https://fluxproweb.com",
			headers: {
				"User-Agent":
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
				"Content-Type": "text/plain;charset=UTF-8",
				"next-action": "efbaa6169049c8cb5fd4fd1abe810d880738ab19",
			},
			data: Data,
		});

		return Response.data;
	}

	async LoginUser(email, password) {
		const Data = JSON.stringify([
			{
				email,
				password,
			},
		]);

		const Response = await axios.request({
			method: "POST",
			url: "https://fluxproweb.com",
			headers: {
				"User-Agent":
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
				"Content-Type": "text/plain;charset=UTF-8",
				"next-action": "1c7778f900ce2db3f2c455a90e709ef29ae30db3",
			},
			data: Data,
			withCredentials: true,
			maxRedirects: 0,
		});

		const cookies = Response.headers["set-cookie"] || [];
		return Array.isArray(cookies) ? cookies.join("; ") : cookies;
	}

	async GetPresignedUrl(token, length = 1) {
		const Response = await axios.request({
			method: "POST",
			url: "https://api2.tap4.ai/image/presignedUrl",
			headers: {
				"Content-Type": "application/json",
				authorization: `Bearer ${token}`,
			},
			data: {
				site: "fluxproweb.com",
				mineType: Array(length).fill("image/jpeg"),
			},
		});

		return Response.data;
	}

	async UploadImages(urls, buffers) {
		const results = [];

		for (let i = 0; i < urls.length; i++) {
			try {
				await axios.put(urls[i].signedUrl, buffers[i], {
					headers: { "Content-Type": "image/jpeg" },
				});
				results.push(urls[i].url);
			} catch { }
		}

		return results;
	}

	async ToBuffer(urls) {
		const buffers = [];

		for (const url of urls) {
			const res = await axios.get(url, { responseType: "arraybuffer" });
			buffers.push(Buffer.from(res.data));
		}

		return buffers;
	}

	async Sleep(taskID, token, interval = 2000) {
		const url = `https://api2.tap4.ai/image/getResult/${taskID}?site=fluxproweb.com`;

		while (true) {
			const res = await axios.get(url, {
				headers: { authorization: `Bearer ${token}` },
			});

			if (!res.data.data || res.data.data.status === "success") {
				return res.data;
			}

			await new Promise((r) => setTimeout(r, interval));
		}
	}

	async Ghibilify(prompt, imageUrls, token, width, height) {
		const Response = await axios.post(
			"https://api2.tap4.ai/image/generator4login/async",
			{
				site: "fluxproweb.com",
				imageType: "ghiblify",
				modelName: "4o-image",
				isPublic: 0,
				isTranslate: true,
				platformType: 39,
				prompt: `Make this ghibli anime style + ${prompt}`,
				outputPrompt: `Make this ghibli anime style + ${prompt}`,
				width,
				height,
				imageUrlList: imageUrls,
			},
			{ headers: { authorization: `Bearer ${token}` } }
		);

		return Response.data;
	}

	async AuthFlow() {
		const username = crypto.randomBytes(8).toString("hex");
		const password = this.RASS();

		const { email, token } = await this.MakeMail();
		await this.SignUser(email, username, password);

		const code = await this.GetMails(token);
		await this.VerifyUser(email, code);

		const cookie = await this.LoginUser(email, password);
		const decoded = cookie ? decodeURIComponent(cookie) : "";

		const match = decoded.match(
			/Authorization=(?:Bearer\s*)?([A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+)/
		);

		if (!match) {
			throw new Error("Authorization token not found in cookie");
		}

		return match[1];
	}

	async Edit(prompt, images) {
		const imageUrls = Array.isArray(images) ? images : [images];
		const token = await this.AuthFlow();

		const buffers = await this.ToBuffer(imageUrls);
		const dimensions = sizeOf(buffers[0]);
		const [width, height] = this.GetNearest(
			dimensions.width,
			dimensions.height
		);

		const presigned = await this.GetPresignedUrl(token, imageUrls.length);
		const uploaded = await this.UploadImages(presigned.rows, buffers);

		const task = await this.Ghibilify(
			prompt,
			uploaded,
			token,
			width,
			height
		);

		const result = await this.Sleep(task.data.key, token);
		return result.data.imageResponseVo;
	}
}

class SeaArt {
	constructor() {
		this.defaultAgent = 'SeaArt/2.2.8';
		this.appId = 'app_global_seaart';
		this.deviceName = 'realme-8';
		this.deviceOS = 'android';
		this.lang = 'en';
		this.timezone = 'Asia/Dhaka';
		this.minDim = 512;
		this.maxDim = 1536;
		this.snapVal = 64;
		this.area = 1024 * 1024;
		this.imgPresets = {
			'1:1': { width: 1024, height: 1024 },
			'16:9': { width: 1440, height: 810 },
			'9:16': { width: 810, height: 1440 },
			'3:2': { width: 1152, height: 768 },
			'2:3': { width: 768, height: 1152 },
			'4:3': { width: 1024, height: 768 },
			'3:4': { width: 768, height: 1024 },
			'5:4': { width: 1152, height: 1440 },
			'4:5': { width: 1440, height: 1152 },
			'21:9': { width: 1536, height: 672 },
			'9:21': { width: 672, height: 1536 }
		};
	}

	Dimentions(aspectRatio = '1:1') {
		const clamp = v => Math.max(this.minDim, Math.min(this.maxDim, v));
		const snap = v => Math.max(this.snapVal, Math.round(v / this.snapVal) * this.snapVal);

		if (this.imgPresets[aspectRatio]) {
			const { width, height } = this.imgPresets[aspectRatio];
			return { width: clamp(width), height: clamp(height) };
		}

		const [wR, hR] = aspectRatio.split(':').map(Number);
		if (!wR || !hR) {
			return this.Dimentions('1:1');
		}

		let width = Math.sqrt(this.area * (wR / hR));
		let height = Math.sqrt(this.area * (hR / wR));
		width = clamp(snap(width));
		height = clamp(snap(height));
		return { width, height };
	}

	async GetToken() {
		const deviceId = randomUUID();
		const headers = {
			'User-Agent': `Mozilla/5.0 (android) ${this.defaultAgent}`,
			'Accept': 'application/json',
			'x-platform': 'app',
			'x-app-id': this.appId,
			'x-device-name': this.deviceName,
			'x-device-os': this.deviceOS,
			'x-version': this.defaultAgent.split('/')[1],
			'accept-language': this.lang,
			'x-device-id': deviceId
		};

		const { data } = await axios.post(
			'https://www.seaart.ai/api/v1/account/login-in/tourist',
			null,
			{ headers }
		);

		if (!data?.data?.token) throw new Error('Failed to retrieve SeaArt token');
		return { token: data.data.token, deviceId };
	}

	async SendText(token, deviceId, prompt, width, height) {
		const seed = Math.floor(Math.random() * 2_147_483_647);
		const payload = {
			model_no: '393e8391b688dbda18e08121b8db5710',
			model_ver_no: '34da43b70ae7e154b331e579ee5e6d69',
			speed_type: 2,
			meta: {
				prompt,
				negative_prompt: 'lowres, overexposed, bad anatomy, bad hands, text, error, watermark, blurry',
				width,
				height,
				cfg_scale: 6,
				clip_skip: 1,
				n_iter: 4,
				vae: 'None',
				steps: 28,
				sampler_name: 'Euler a',
				generate: { gen_mode: 0, mode: 0, prompt_magic_mode: 2 },
				seed: -1,
				lora_models: [
					{ model_id: '65a1dff726f92ac751647412514286af', model_ver_no: '27f10a050fa6093541824fb7db69ab93', weight: 0.5 },
					{ model_id: '8342e4d4ed0e46dc7be78e70c84d5f3c', model_ver_no: 'e943895f17144f76fdf4fbe74fa16f4e', weight: 0.5 },
					{ model_id: '6e8939b167ab0d814baf7b9c94da65c5', model_ver_no: '3e048ceeeb1a0e10db1a6096522c64b0', weight: 0.5 }
				],
				restore_faces: true,
				hr_upscaler: 'R-ESRGAN 4x+ Anime6B',
				ad_units: [{ ad_model: 'hand', ad_denoising_strength: 0.3, ad_confidence: 0.3 }]
			}
		};

		const headers = {
			'User-Agent': `Mozilla/5.0 (android) ${this.defaultAgent}`,
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'x-platform': 'app',
			'x-app-id': this.appId,
			'x-device-name': this.deviceName,
			'x-device-os': this.deviceOS,
			'x-version': this.defaultAgent.split('/')[1],
			'accept-language': this.lang,
			'x-canary': 'true',
			'x-timezone': this.timezone,
			token,
			'x-device-id': deviceId
		};

		const { data } = await axios.post(
			'https://www.seaart.ai/api/v1/task/v2/text-to-img',
			payload,
			{ headers }
		);

		if (!data?.data?.id) throw new Error('Task submission failed');
		return data.data.id;
	}

	async Results(token, deviceId, taskId) {
		const headers = {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'x-platform': 'app',
			'x-app-id': this.appId,
			'x-device-name': this.deviceName,
			'x-device-os': this.deviceOS,
			'x-version': this.defaultAgent.split('/')[1],
			'accept-language': this.lang,
			'x-timezone': this.timezone,
			token,
			'x-device-id': deviceId
		};
		const body = { task_ids: [taskId] };

		for (let i = 0; i < 40; i++) {
			await new Promise(r => setTimeout(r, 5000));
			const { data } = await axios.post(
				'https://www.seaart.ai/api/v1/task/batch-progress',
				body,
				{ headers }
			);

			const item = data.data?.items?.[0];
			if (item?.status === 3) return item.img_uris.map(u => u.url);
			if (item?.status === 4) throw new Error(item.status_desc || 'Task failed');
		}

		throw new Error('SeaArt task timed out');
	}



	async AniGen(prompt, aspectRatio = '1:1') {
		if (!prompt) throw new Error('Prompt required');
		const { token, deviceId } = await this.GetToken();
		const { width, height } = this.Dimentions(aspectRatio);
		const taskId = await this.SendText(token, deviceId, prompt, width, height);
		const urls = await this.Results(token, deviceId, taskId);


		return { prompt, aspectRatio, urls };
	}
}


async function Upscale(imageUrl) {
	try {
		if (!imageUrl) {
			return 'Missing required query parameter: imageurl';
		}

		const fetchResponse = await axios.get(imageUrl, { responseType: 'arraybuffer' });
		const imageBuffer = Buffer.from(fetchResponse.data);

		const uploadForm = new FormData();
		const randomName = crypto.randomBytes(8).toString('hex') + '.jpg';
		uploadForm.append('name', randomName);
		uploadForm.append('chunk', '0');
		uploadForm.append('chunks', '1');
		uploadForm.append('task', 'g3As5pt3x4pstxccxvvgcqvyzcnlh381kn8f5gtf48109391r2vpA45f4xdlw0gbr1vx3tkq9pwgghv40yh4lcqb3wwn59t6q5d3hmpvp6ztnsr9wt3svrcdmmvrvbrd2pz5jpzy9dr2741xllylpt9mnzqbnblfp7m358jqpmf1g80cby41');
		uploadForm.append('preview', '1');
		uploadForm.append('pdfinfo', '0');
		uploadForm.append('pdfforms', '0');
		uploadForm.append('pdfresetforms', '0');
		uploadForm.append('v', 'web.0');
		uploadForm.append('file', imageBuffer, { filename: randomName, contentType: 'image/jpeg' });


		const uploadFormHeaders = uploadForm.getHeaders();
		const uploadHeaders = {
			'Content-Type': uploadFormHeaders['content-type'],
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
			'Accept': 'application/json',
			'Accept-Encoding': 'gzip, deflate, br, zstd',
			'sec-ch-ua-platform': '"Windows"',
			'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE1MjMzNjQ4MjQsIm5iZiI6MTUyMzM2NDgyNCwianRpIjoicHJvamVjdF9wdWJsaWNfYzkwNWRkMWMwMWU5ZmQ3NzY5ODNjYTQwZDBhOWQyZjNfT1Vzd2EwODA0MGI4ZDJjN2NhM2NjZGE2MGQ2MTBhMmRkY2U3NyJ9.qvHSXgCJgqpC4gd6-paUlDLFmg0o2DsOvb1EUYPYx_E',
			'sec-ch-ua': '"Brave";v="135", "Not-A.Brand";v="8", "Chromium";v="135"',
			'sec-ch-ua-mobile': '?0',
			'Sec-GPC': '1',
			'Accept-Language': 'en-US,en;q=0.6',
			'Origin': 'https://www.iloveimg.com',
			'Sec-Fetch-Site': 'same-site',
			'Sec-Fetch-Mode': 'cors',
			'Sec-Fetch-Dest': 'empty',
			'Referer': 'https://www.iloveimg.com/',
			'Cookie': '_csrf=eRRUIHhyjrizQII-hTd42JvFmaeVsq4n'
		};

		const uploadResponse = await axios.post('https://api1g.iloveimg.com/v1/upload', uploadForm, { headers: uploadHeaders });

		const serverFilename = uploadResponse.data.server_filename;
		if (!serverFilename) {
			throw new Error('uploadResponse.data.server_filename missing');
		}

		const upscaleForm = new FormData();
		upscaleForm.append('task', 'g3As5pt3x4pstxccxvvgcqvyzcnlh381kn8f5gtf48109391r2vpA45f4xdlw0gbr1vx3tkq9pwgghv40yh4lcqb3wwn59t6q5d3hmpvp6ztnsr9wt3svrcdmmvrvbrd2pz5jpzy9dr2741xllylpt9mnzqbnblfp7m358jqpmf1g80cby41');
		upscaleForm.append('server_filename', serverFilename);
		upscaleForm.append('scale', '4');
		const upscaleFormHeaders = upscaleForm.getHeaders();
		const upscaleHeaders = {
			'Content-Type': upscaleFormHeaders['content-type'],
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
			'Accept-Encoding': 'gzip, deflate, br, zstd',
			'sec-ch-ua-platform': '"Windows"',
			'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiIiLCJhdWQiOiIiLCJpYXQiOjE1MjMzNjQ4MjQsIm5iZiI6MTUyMzM2NDgyNCwianRpIjoicHJvamVjdF9wdWJsaWNfYzkwNWRkMWMwMWU5ZmQ3NzY5ODNjYTQwZDBhOWQyZjNfT1Vzd2EwODA0MGI4ZDJjN2NhM2NjZGE2MGQ2MTBhMmRkY2U3NyJ9.qvHSXgCJgqpC4gd6-paUlDLFmg0o2DsOvb1EUYPYx_E',
			'sec-ch-ua': '"Brave";v="135", "Not-A.Brand";v="8", "Chromium";v="135"',
			'sec-ch-ua-mobile': '?0',
			'Sec-GPC': '1',
			'Accept-Language': 'en-US,en;q=0.6',
			'Origin': 'https://www.iloveimg.com',
			'Sec-Fetch-Site': 'same-site',
			'Sec-Fetch-Mode': 'cors',
			'Sec-Fetch-Dest': 'empty',
			'Referer': 'https://www.iloveimg.com/',
			'Cookie': '_csrf=eRRUIHhyjrizQII-hTd42JvFmaeVsq4n'
		};
		const UR = await axios.post('https://api1g.iloveimg.com/v1/upscale', upscaleForm, {
			headers: upscaleHeaders,
			responseType: 'stream'
		});

		return UR.data
	} catch (error) {
		if (error.response) {
		}
	}
}


const Upload = async function (file) {
	const regCheckURL = /^(http|https):\/\/[^ "]+$/;
	let type = "file";
	try {
		if (!file) {
			throw new Error("The first argument (file) must be a stream or an image URL");
		}
		if (regCheckURL.test(file) === true) {
			type = "url";
		}
		if (
			(type !== "url" && !(typeof file._read === "function" && typeof file._readableState === "object")) ||
			(type === "url" && !regCheckURL.test(file))
		) {
			throw new Error("The first argument (file) must be a stream or an image URL");
		}

		const res_ = await axios({
			method: "GET",
			url: "https://imgbb.com",
		});

		const auth_token = res_.data.match(/auth_token="([^"]+)"/)[1];
		const timestamp = Date.now();

		const formData = new FormData();
		formData.append("source", file);
		formData.append("type", type);
		formData.append("action", "upload");
		formData.append("timestamp", timestamp);
		formData.append("auth_token", auth_token);

		const res = await axios.post("https://imgbb.com/json", formData, {
			headers: formData.getHeaders(),
		});

		return res.data.image.url;
	} catch (err) {
		throw new Error(err.response ? err.response.data : err);
	}
}


class Suno {
	constructor() {
		this.ApiUrl = "https://aimusic-api.topmediai.com/app/v2";
		this.AccountUrl = "https://account-api.topmediai.com/app/v2";
	}

	Decrypt(Base64Str) {
		const Key = Buffer.from("147258369topmeidia96385topmeidia", "utf-8");
		const Iv = Buffer.from("1597531topmeidia", "utf-8");
		const Data = Buffer.from(Base64Str, "base64");
		const Decipher = crypto.createDecipheriv("aes-256-cbc", Key, Iv);
		return Buffer.concat([Decipher.update(Data), Decipher.final()]).toString("utf-8");
	}

	async GetToken() {
		const Data = qs.stringify({
			email: crypto.randomBytes(7).toString("hex") + "@gmail.com",
			password: crypto.randomBytes(16).toString("hex"),
			equipment_code: "a54x",
			first_name: "",
			last_name: "",
			information_sources: "20035",
			lang: "EN",
			source_site: "",
			platform: "phone-app",
			from_language: "EN",
			operating_system: "android",
			token: "",
			timestamp: Date.now().toString(),
			sign: "6298C3A0EADF18F164E1BE2E890663148F7A3D3A"
		});

		const Config = {
			method: "POST",
			url: `${this.AccountUrl}/register`,
			headers: {
				"User-Agent": "Okhttp/4.12.0",
				Connection: "Keep-Alive",
				"Accept-Encoding": "Gzip",
				"Content-Type": "Application/x-www-form-urlencoded"
			},
			data: Data
		};

		return (await axios.request(Config)).data.data.token;
	}

	async Result(Token, TaskIDs) {
		const Interval = 2000
		const Url = `${this.ApiUrl}/task/results`;
		const IdsParam = TaskIDs.join(",");

		while (true) {
			try {
				const Res = await axios.get(`${Url}?ids=${encodeURIComponent(IdsParam)}`, {
					headers: {
						"User-Agent": "Okhttp/4.12.0",
						"Accept-Encoding": "Gzip",
						Authorization: `Bearer ${Token}`
					}
				});

				const Results = Res.data?.data?.result;

				if (Results && Results.every(R => R.audio_url !== null && R.duration !== -1)) {
					return Results.map(R => ({
						Audio: this.Decrypt(R.audio_url),
						Image: this.Decrypt(R.cover_url),
						Lyrics: R.lyric,
						Title: R.title
					}));
				}

				await new Promise(Resolve => setTimeout(Resolve, Interval));
			} catch (Err) {
				console.error("Error Fetching Results:", Err.message);
				await new Promise(Resolve => setTimeout(Resolve, Interval));
			}
		}
	}

	async MakePrompt(Lyrics) {
		const Token = await this.GetToken()
		const Data = qs.stringify({
			action: "auto",
			style: Lyrics,
			instrumental: "0",
			mv: "v4.5"
		});

		const Config = {
			method: "POST",
			url: `${this.ApiUrl}/async/text-to-song`,
			headers: {
				"User-Agent": "Okhttp/4.12.0",
				"Accept-Encoding": "Gzip",
				"Content-Type": "Application/x-www-form-urlencoded",
				Authorization: "Bearer " + Token
			},
			data: Data
		};

		const Res = await axios.request(Config);
		return await this.Result(Token, Res.data.data.ids);
	}

	async MakeSong(Lyrics, Styles, Title) {
		const Token = await this.GetToken()
		const Data = qs.stringify({
			action: "custom",
			lyrics: Lyrics,
			style: Styles,
			title: Title,
			instrumental: "0",
			mv: "v4.5"
		});

		const Config = {
			method: "POST",
			url: `${this.ApiUrl}/async/text-to-song`,
			headers: {
				"User-Agent": "Okhttp/4.12.0",
				"Accept-Encoding": "Gzip",
				"Content-Type": "Application/x-www-form-urlencoded",
				Authorization: "Bearer " + Token
			},
			data: Data
		};

		const Res = await axios.request(Config);
		return await this.Result(Token, Res.data.data.ids);
	}

	async MakeImage(Url, Prompt, Title) {
		const Token = await this.GetToken()
		const Data = qs.stringify({
			action: "custom",
			image_url: Url,
			style: Prompt || "",
			title: Title || "",
			instrumental: "0",
			mv: "v4.5",
		});

		const Config = {
			method: "POST",
			url: `${this.ApiUrl}/async/image-to-song`,
			headers: {
				"User-Agent": "Okhttp/4.12.0",
				"Accept-Encoding": "Gzip",
				"Content-Type": "Application/x-www-form-urlencoded",
				Authorization: "Bearer " + Token
			},
			data: Data
		};

		const Res = await axios.request(Config);
		return await this.Result(Token, Res.data.data.ids);
	}
}
async function YouTube(youtubeUrl, quality = "720") {
	const MAX_ERROR_RETRIES = 10;
	const PROCESS_DELAY = 3000;

	const wait = ms => new Promise(r => setTimeout(r, ms));

	async function retry(fn, retries = MAX_ERROR_RETRIES) {
		let err;
		for (let i = 0; i < retries; i++) {
			try {
				return await fn();
			} catch (e) {
				err = e;
				await wait(1000);
			}
		}
		throw err;
	}

	function Quality(q) {
		if (!q) return { type: "auto" };
		const s = q.toString().toLowerCase();
		if (s.includes("k")) return { type: "audio", bitrate: parseInt(s) };
		if (s === "audio") return { type: "audio", best: true };
		if (s === "video") return { type: "video", best: true };
		const p = parseInt(s);
		if (!isNaN(p)) return { type: "video", height: p };
		return { type: "auto" };
	}

	function PickMedia(mediaItems, quality) {
		const q = Quality(quality);

		if (q.type === "audio") {
			const audios = mediaItems.filter(m => m.type === "Audio");
			return q.best
				? audios.sort((a, b) => b.mediaQuality - a.mediaQuality)[0]
				: audios.find(a => parseInt(a.mediaQuality) === q.bitrate);
		}

		if (q.type === "video") {
			const videos = mediaItems.filter(m => m.type === "Video");
			return q.best
				? videos.sort(
					(a, b) =>
						parseInt(b.mediaRes.split("x")[1]) -
						parseInt(a.mediaRes.split("x")[1])
				)[0]
				: videos.find(v => v.mediaRes?.endsWith(`x${q.height}`));
		}

		return mediaItems[0];
	}

	const headers = {
		"User-Agent":
			"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36",
		"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
		"x-requested-with": "XMLHttpRequest",
		origin: "https://ytdown.to",
		referer: "https://ytdown.to/fr2/",
	};

	const jsonA = await retry(async () => {
		const res = await fetch("https://ytdown.to/proxy.php", {
			method: "POST",
			headers,
			body: new URLSearchParams({ url: youtubeUrl }),
		});
		return res.json();
	});
	const targetMedia = PickMedia(jsonA?.api?.mediaItems, quality);
	if (!targetMedia) throw new Error("Media not found");

	let jsonB = await retry(async () => {
		const res = await fetch("https://ytdown.to/proxy.php", {
			method: "POST",
			headers,
			body: new URLSearchParams({ url: targetMedia.mediaUrl }),
		});
		return res.json();
	});

	let lastPercent = null;
	let stagnantCount = 0;

	while (jsonB?.api?.fileUrl === "In Processing...") {
		const currentPercent = jsonB?.api?.percent;

		if (currentPercent === lastPercent) {
			stagnantCount++;
			if (stagnantCount >= 10) {
				throw new Error("Processing stalled");
			}
		} else {
			stagnantCount = 0;
			lastPercent = currentPercent;
		}

		await wait(PROCESS_DELAY);

		jsonB = await retry(async () => {
			const res = await fetch("https://ytdown.to/proxy.php", {
				method: "POST",
				headers,
				body: new URLSearchParams({ url: targetMedia.mediaUrl }),
			});
			return res.json();
		});

	}

	return {
		title: jsonA.api.title,
		description: jsonA.api.description,
		fileName: jsonB.api.fileName,
		duration: targetMedia.mediaDuration,
		fileUrl: jsonB.api.fileUrl,
		meta: jsonB.api,
	};
}

class Prompt {
	constructor() {
		this.path = './Modules/Scripts/cache/Json/Prompt.json';
	}

	async ReadToken() {
		try {
			const data = await fsx.readFile(this.path, 'utf-8');
			const token = JSON.parse(data).token;
			return token;
		} catch (error) {
			return null;
		}
	}

	async SaveToken(token) {
		try {
			await fsx.writeFile(this.path, JSON.stringify({ token }));
		} catch (error) {
			console.error('Error saving token:', error);
		}
	}

	async ScrapeToken() {
		const { email } = await this.MakeMail();
		await this.Verificate(email);
		const code = await this.GetMails(email);
		if (code) {
			const { email: registeredEmail, password, Code: verificationCode } = await this.MakeUser(email, code);
			const accessToken = await this.Login(registeredEmail, verificationCode, password);
			if (accessToken) {
				const finalToken = await this.FinalToken(accessToken);
				await this.SaveToken(finalToken);
				return finalToken;
			}
		}
		throw new Error('Failed to scrape token');
	}

	async GetToken() {
		let token = await this.ReadToken();
		if (!token) {
			token = await this.ScrapeToken();
		}
		return token;
	}

	async CallMJ(url, body, token) {
		try {
			const response = await axios.post(`${url}?token=${token}`, body);
			return response.data;
		} catch (error) {
			if (error.response && (error.response.status === 403 || error.response.status === 401 || error.response.status === 402)) {
				token = await this.ScrapeToken();
				return await this.CallMJ(url, body, token);
			}
			throw error;
		}
	}

	RandomPass(length = 12) {
		const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=';
		let password = '';
		for (let i = 0; i < length; i++) {
			const randomIndex = Math.floor(Math.random() * charset.length);
			password += charset[randomIndex];
		}
		return password;
	}

	async MakeMail() {
		const options = {
			method: 'POST',
			url: 'https://api.internal.temp-mail.io/api/v3/email/new',
			data: {
				min_name_length: 10,
				max_name_length: 10
			}
		};

		try {
			const response = await axios.request(options);
			return response.data;
		} catch (error) {

		}
	}

	async Verificate(email) {
		try {
			await axios.post('https://auth.zhishuyun.com/api/v1/email-code', {
				template: "115309",
				receiver: email
			});
		} catch (error) {

		}
	}

	async GetMails(mail) {
		const options = {
			method: 'GET',
			url: `https://api.internal.temp-mail.io/api/v3/email/${mail}/messages`,
			data: null
		};

		try {
			let response = await axios.request(options);
			while (!response.data[0]) {
				response = await axios.request(options);
			}
			let emailText = response.data[0].body_text;
			const codeMatch = emailText.match(/您的邮箱验证码为\s*(\d{6})/);
			const code = codeMatch ? codeMatch[1] : null;
			if (code) {
				return code;
			} else {

				return null;
			}
		} catch (error) {

		}
	}

	async MakeUser(email, code) {
		const password = this.RandomPass();
		try {
			const response = await axios.post('https://auth.zhishuyun.com/api/v1/users', {
				email: email,
				email_code: code,
				password: password
			});

			if (response.status === 200) {
				return { email, password, Code: code };
			} else {

			}
		} catch (error) {

		}
	}

	async Login(email, code, password) {
		try {
			const response = await axios.post('https://auth.zhishuyun.com/api/v1/login/', {
				email: email,
				email_code: code,
				password: password
			});

			if (response.status === 200) {
				const { access_token } = response.data;
				return access_token;
			}
		} catch (error) {

		}
	}

	async FinalToken(auth) {
		try {
			const response = await axios.post(
				'https://data.zhishuyun.com/api/v1/applications/',
				{
					'type': 'Api',
					'api_id': '362de49d-80f1-4844-9f50-1f751e010dfe'
				},
				{
					headers: {
						'Accept': 'application/json',
						'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
						'Authorization': 'Bearer ' + auth,
						'Connection': 'keep-alive',
						'Content-Type': 'application/json',
						'Cookie': 'INVITER_ID=undefined',
						'Origin': 'https://data.zhishuyun.com',
						'Referer': 'https://data.zhishuyun.com/services/d87e5e99-b797-4ade-9e73-b896896b0461',
						'Sec-Fetch-Dest': 'empty',
						'Sec-Fetch-Mode': 'cors',
						'Sec-Fetch-Site': 'same-origin',
						'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
						'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
						'sec-ch-ua-mobile': '?0',
						'sec-ch-ua-platform': '"Linux"'
					}
				}
			);


			const response1 = await axios.get('https://data.zhishuyun.com/api/v1/applications/', {
				params: {
					'limit': '10',
					'offset': '0',
					'user_id': response.data.user_id,
					'type': 'Api',
					'ordering': '-created_at'
				},
				headers: {
					'Accept': 'application/json',
					'Accept-Language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7',
					'Authorization': 'Bearer ' + auth,
					'Connection': 'keep-alive',
					'Cookie': 'INVITER_ID=undefined',
					'Referer': 'https://data.zhishuyun.com/console/applications',
					'Sec-Fetch-Dest': 'empty',
					'Sec-Fetch-Mode': 'cors',
					'Sec-Fetch-Site': 'same-origin',
					'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
					'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
					'sec-ch-ua-mobile': '?0',
					'sec-ch-ua-platform': '"Linux"'
				}
			});

			return response1.data.items[0].credential.token;
		} catch (e) {

			return "err";
		}
	}

	async Generate(Url) {
		if (!Url) return;
		try {
			const Token = await this.GetToken();
			const url = 'https://api.zhishuyun.com/midjourney/describe';
			const body = {
				image_url: Url,
			};
			return await this.CallMJ(url, body, Token);
		} catch (error) {
			if (error.response.data.detail === "internal server error, please contact admin") return 'Failed to generate image';
			return 'Failed to generate image';
		}
	}

}

async function topMedia(input, ext = "png") {
	try {
		let buf;

		if (typeof input === "string") {
			let b = await axios.get(input, { responseType: "arraybuffer" });
			buf = Buffer.from(b.data);
		} else if (Buffer.isBuffer(input)) {
			buf = input;
		} else if (input && typeof input.pipe === "function") {
			buf = await streamToBuffer(input);
		} else {
			throw new Error("Input must be a URL, Buffer, or Stream");
		}

		let data = new FormData();
		data.append("file_1_", buf, { filename: `shelly.${ext}` });
		data.append("submitr", "[ رفع الملفات ]");

		let config = {
			method: "POST",
			url: "https://top4top.io/index.php",
			headers: {
				...data.getHeaders(),
				"User-Agent":
					"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
				"Accept":
					"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
				"Accept-Language": "en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7",
				"Origin": "https://top4top.io",
				"Referer": "https://top4top.io/",
				"Upgrade-Insecure-Requests": "1",
			},
			data,
		};

		let res = await axios.request(config);
		let s = res.data;
		const m = s.match(/<input[^>]*\svalue="(https?:\/\/[^"]+)"/);
		return m?.[1] || null;
	} catch (e) {
		return { err: "ext not allowed or upload failed", msg: e.message };
	}
}


const Mods = {
	Ghibili,
	SeaArt,
	YouTube,
	PinLens,
	Upscale,
	Pinterest,
	NanoBanana,
	AiMirror,
	topMedia,
	SeaDream,
	translate,
	Upload,
	convertTime,
	createQueue,
	CustomError,
	getExtFromMimeType,
	splitPage,
	translateAPI,
	removeHomeDir,
	Prompt,
	randomNumber,
	findUid,
	share,
	translate,
	cleanAnilistHTML,
	randomString,
	getExtFromUrl,
	getPrefix,
	getTime,
	log,
	message,
	downloadFile,
	getStreamsFromAttachment,
	getStreamFromURL,
	uploadImgbb,
	throwError,
	AES,
	shortenURL,
	homeDir,
	MidJourney,
	Suno
};

module.exports = Mods;
