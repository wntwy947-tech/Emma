const { readdirSync } = require("fs-extra");
const chalk = require('chalk');
const gradient = require('gradient-string');
const con = require('./../../Config/Settings.json');
const theme = con.DESIGN.Theme;
let cra;
let co;
let cb;
let cv;
if (theme.toLowerCase() === 'blue') {
  cra = gradient('yellow', 'lime', 'green');
  co = gradient("#243aff", "#4687f0", "#5800d4");
  cb = chalk.blueBright;
  cv = chalk.bold.hex("#3467eb");
} else if (theme.toLowerCase() === 'fiery') {
  cra = gradient('orange', 'orange', 'yellow');
  co = gradient("#fc2803", "#fc6f03", "#fcba03");
  cb = chalk.hex("#fff308");
  cv = chalk.bold.hex("#fc3205");
} else if (theme.toLowerCase() === 'red') {
  cra = gradient('yellow', 'lime', 'green');
  co = gradient("red", "orange");
  cb = chalk.hex("#ff0000");
  cv = chalk.bold.hex("#ff0000");
} else if (theme.toLowerCase() === 'aqua') {
  cra = gradient("#6883f7", "#8b9ff7", "#b1bffc")
  co = gradient("#0030ff", "#4e6cf2");
  cb = chalk.hex("#3056ff");
  cv = chalk.bold.hex("#0332ff");
} else if (theme.toLowerCase() === 'pink') {
  cra = gradient('purple', 'pink');
  co = gradient("#d94fff", "purple");
  cb = chalk.hex("#6a00e3");
  cv = chalk.bold.hex("#6a00e3");
} else if (theme.toLowerCase() === 'retro') {
  cra = gradient("orange", "purple");
  co = gradient.retro;
  cb = chalk.hex("#ffce63");
  cv = chalk.bold.hex("#3c09ab");
} else if (theme.toLowerCase() === 'sunlight') {
  cra = gradient("#f5bd31", "#f5e131");
  co = gradient("#ffff00", "#ffe600");
  cb = chalk.hex("#faf2ac");
  cv = chalk.bold.hex("#ffe600");
} else if (theme.toLowerCase() === 'teen') {
  cra = gradient("#81fcf8", "#853858");
  co = gradient.teen;
  cb = chalk.hex("#a1d5f7");
  cv = chalk.bold.hex("#ad0042");
} else if (theme.toLowerCase() === 'summer') {
  cra = gradient("#fcff4d", "#4de1ff");
  co = gradient.summer;
  cb = chalk.hex("#ffff00");
  cv = chalk.bold.hex("#fff700")
} else if (theme.toLowerCase() === 'flower') {
  cra = gradient("yellow", "yellow", "#81ff6e");
  co = gradient.pastel;
  cb = gradient('#47ff00', "#47ff75");
  cv = chalk.bold.hex("#47ffbc");
} else if (theme.toLowerCase() === 'ghost') {
  cra = gradient("#0a658a", "#0a7f8a", "#0db5aa");
  co = gradient.mind;
  cb = chalk.blueBright;
  cv = chalk.bold.hex("#1390f0");
} else if (theme === 'hacker') {
  cra = chalk.hex('#4be813');
  co = gradient('#47a127', '#0eed19', '#27f231');
  cb = chalk.hex("#22f013");
  cv = chalk.bold.hex("#0eed19");
} else {
  cra = gradient('yellow', 'lime', 'green');
  co = gradient("#243aff", "#4687f0", "#5800d4");
  cb = chalk.blueBright;
  cv = chalk.bold.hex("#3467eb");
}

function LoadEvents(loginApiData) {
  const events = readdirSync(global.Emma.mainPath + '/Modules/Events').filter(event => event.endsWith('.js') && !global.Settings.EventUload.includes(event));
  const TheListCommand = readdirSync(global.Emma.mainPath + '/Modules/Scripts').filter(command => command.endsWith('.js'));
  const LengthH = TheListCommand.length;
  global.loading(`${cra(` LOADED`)} ${cb(`${global.Emma.commands.size}`)} Script from ${cb(`${LengthH}`)}`, "SCRIPTS");

  console.log(`${cv(`\n` + `──LOADING EVENTS─●`)}`);
  for (const ev of events) {
    try {
      var event = require(global.Emma.mainPath + '/Modules/Events/' + ev);
      if (!event.Emma || !event.Begin) {
        return;
      }
      if (global.Emma.events.has(event.Emma.name) || '')

        if (event.Start) {
          try {
            const eventData = {};
            eventData.api = loginApiData;
            event.Start(eventData);
          } catch (error) {
            global.loading(error, "Events")
          }
        }
      global.Emma.events.set(event.Emma.name, event);
      global.loading(`${cra(`LOADED`)} ${cb(event.Emma.name)} Success`, "EVENT");
    } catch (error) {

    }
  }
}

function LoadScripts(loginApiData) {
  const listCommand = readdirSync(global.Emma.mainPath + '/Modules/Scripts').filter(command => command.endsWith('.js') && !command.includes('eg') && !global.Settings.ScriptUload.includes(command));

  for (const command of listCommand) {
    try {
      var module = require(global.Emma.mainPath + '/Modules/Scripts/' + command);
      if (!module.Emma || !module.Begin || !module.Emma.Class) throw new Error("Error in Loading Command");
      if (global.Emma.commands.has(module.Emma.name || '')) throw new Error("Error in Loading Command no Name");

      if (module.Emma.Aliases) {
        let { Aliases } = module.Emma;
        if (typeof Aliases === "string") {
          Aliases = [Aliases];
        }

        for (const Aliasess of Aliases) {
          if (typeof Aliasess === "string") {
            if (global.Emma.Aliases.has(Aliasess)) {
              continue;
            } else {
              global.Emma.Aliases.set(Aliasess, module.Emma.name);
            }
          }
        }
      }


      if (module.Start) {
        try {
          const moduleData = {};
          moduleData.api = loginApiData;
          module.Start(moduleData);
        } catch (error) {
          global.loading(error, "Scripts");
        }
      }

      if (module.onEvent) {
        global.Emma.EvReg.push(module.Emma.name);
      }

      if (module.onRun) {
        global.Emma.onEvent.set(module.Emma.name, module);
      }


      global.Emma.commands.set(module.Emma.name, module);
    } catch (error) {
console.log(error)
        console.log(module)
    }
  }
}

module.exports = { LoadEvents, LoadScripts };