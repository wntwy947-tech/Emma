const utils = require('../Funcs.js') ;
const util = require('util');

function isCallable(func) {
    if (!func) {
        return false;
    }
    return typeof func === 'function' && util.types.isFunction(func);
}

module.exports = function (FcaData, Client, Context) {
    async function editMessageMqtt(messageId, text) {
        await utils.parseAndCheckLogin(Context, FcaData);
        let callback = null;
        const mqttClient = Context.mqttClient;

        if (!mqttClient) {
            throw new Error("Not connected to MQTT");
        }

        Context.wsReqNumber += 1;
        Context.wsTaskNumber += 1;

        const taskPayload = {
            message_id: messageId,
            text: text,
        };

        const task = {
            failure_count: null,
            label: "742",
            payload: JSON.stringify(taskPayload),
            queue_name: "edit_message",
            task_id: Context.wsTaskNumber,
        };

        const content = {
            app_id: "2220391788200892",
            payload: {
                data_trace_id: null,
                epoch_id: parseInt(utils.generateOfflineThreadingID()),
                tasks: [task], 
                version_id: "6903494529735864",
            },
            request_id: Context.wsReqNumber,
            type: 3,
        };
        content.payload = JSON.stringify(content.payload);

        if (isCallable(callback)) {
            Context.reqCallbacks[Context.wsReqNumber] = callback;
        }
        await mqttClient.publish("/ls_req", JSON.stringify(content), { qos: 1, retain: false });
    }

    return editMessageMqtt;
};
