const utils = require('../Funcs.js');


  module.exports = function (FcaData, Client, Context) {
	return function forwardAttachment(attachmentID, userOrUsers, callback) {
		let resolveFunc = function () { };
		let rejectFunc = function () { };
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});
		if (!callback) {
			callback = function (err) {
				if (err) {
					return rejectFunc(err);
				}
				resolveFunc();
			};
		}

		const form = {
			attachment_id: attachmentID
		};

		if (utils.getType(userOrUsers) !== "Array") {
			userOrUsers = [userOrUsers];
		}

		const timestamp = Math.floor(Date.now() / 1000);

		for (let i = 0; i < userOrUsers.length; i++) {
			
			form["recipient_map[" + (timestamp + i) + "]"] = userOrUsers[i];
		}

		FcaData
			.post(
				"https://www.facebook.com/mercury/attachments/forward/",
				Context.jar,
				form
			)
			.then(utils.parseAndCheckLogin(Context.jar, FcaData))
			.then(function (resData) {
				if (resData.error) {
					throw resData;
				}

				return callback();
			})
			.catch(function (err) {
				return callback(err);
			});

		return returnPromise;
	};
};
