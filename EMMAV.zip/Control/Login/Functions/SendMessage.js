const mimeDB = require("mime-db");
const axios = require("axios");
const utils = require('../Funcs.js');
const { fileTypeFromBuffer } = require('file-type');

const RandomString = function (max, onlyOnce = false, possible) {
    try {
        if (!max || isNaN(max)) max = 10;
        let text = "";
        possible = possible || "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for (let i = 0; i < max; i++) {
            let random = Math.floor(Math.random() * possible.length);
            if (onlyOnce) {
                while (text.includes(possible[random]))
                    random = Math.floor(Math.random() * possible.length);
            }
            text += possible[random];
        }
        return text;
    } catch (e) {
        throw e;
    }
};

const StreamFromURL = async function (url = "", pathName = "", options = {}) {
    try {
        const ExtFromMimeType = function (mimeType = "") {
            try {
                return mimeDB[mimeType]
                    ? (mimeDB[mimeType].extensions || [])[0] || "unknown"
                    : "unknown";
            } catch (e) {
                throw e;
            }
        };
        if (!options && typeof pathName === "object") {
            options = pathName;
            pathName = "";
        }
        if (!url || typeof url !== "string")
            throw new Error(`The first argument (url) must be a string`);
        const response = await axios({
            url,
            method: "GET",
            responseType: "stream",
            ...options
        });
        if (!pathName)
            pathName = RandomString(10) + (response.headers["content-type"]
                ? '.' + ExtFromMimeType(response.headers["content-type"])
                : ".noext");
        response.data.path = pathName;
        return response.data;
    } catch (e) {
        throw e;
    }
};

const allowedProperties = {
    Attachment: true,
    Sticker: true,
    Emoji: true,
    EmojiSize: true,
    Body: true,
    Mentions: true,
    Location: true
};

const EmojiSizes = {
    Small: 1,
    Medium: 2,
    Large: 3
};

async function ExtFromBuffer(buffer) {
    try {
        const type = await fileTypeFromBuffer(buffer);
        return type ? type.ext : 'jpg';
    } catch (e) {
        throw e;
    }
}

function SpecialChar(inputString) {
    try {
        if (typeof inputString !== "string") return inputString;
        const buffer = Buffer.from(inputString, 'utf8');
        let filteredBuffer = Buffer.alloc(0);
        for (let i = 0; i < buffer.length; i++) {
            if (buffer[i] === 0xEF && buffer[i + 1] === 0xB8 && buffer[i + 2] === 0x8F) {
                i += 2;
            } else {
                filteredBuffer = Buffer.concat([filteredBuffer, buffer.slice(i, i + 1)]);
            }
        }
        return filteredBuffer.toString('utf8');
    } catch (e) {
        throw e;
    }
}

module.exports = function (FcaData, Client, Context) {
    try {
        async function uploadFile(attachments) {
            try {
                if (utils.getType(attachments) !== "Array") attachments = [attachments];
                const uploads = attachments.map(attachment => {
                    try {
                        if (!utils.isReadableStream(attachment) && !Buffer.isBuffer(attachment)) {
                            throw new Error(`Attachment should be a readable stream or a buffer, but got ${utils.getType(attachment)}`);
                        }
                        const form = { upload_1024: attachment, voice_clip: "true" };
                        return FcaData
                            .postFormData("https://upload.facebook.com/ajax/mercury/upload.php", Context.jar, form, {})
                            .then(utils.parseAndCheckLogin(Context, FcaData))
                            .then(resData => {
                                if (resData.error) return;
                                return resData.payload.metadata[0];
                            });
                    } catch (e) {
                        throw e;
                    }
                });
                return await Promise.all(uploads);
            } catch (e) {
                throw e;
            }
        }

        return async function sendMessage(msg, threadkey, callback, messageId) {

             if (callback && typeof callback !== "function") {
              messageId = callback;
              callback = null;
             }
             
            Context.wsReqNumber++;
            Context.wsTaskNumber++;
            const reqID = Context.wsReqNumber;
            const task_id = Context.wsTaskNumber;

            let resolveFunc = () => {};
            let rejectFunc = () => {};
            const returnPromise = new Promise((resolve, reject) => {
                resolveFunc = resolve;
                rejectFunc = reject;
            });

            if (!callback) {
                callback = function (err, result) {
                    if (err) return rejectFunc(err);
                    resolveFunc(result);
                };
            }

            try {
                const threadkeyType = utils.getType(threadkey);
                if (threadkeyType !== "Number" && threadkeyType !== "String") {
                    const err = { error: `Invalid threadkey type: ${threadkeyType}` };
                    callback(err);
                    return returnPromise;
                }

                const messageIDType = utils.getType(messageId);
                const msgType = utils.getType(msg);
                if (messageId && messageIDType !== "String") {
                    callback({ error: "MessageID should be of type string and not " + messageIDType });
                    return returnPromise;
                }
                if (msgType === "String") msg = { Body: msg };
                if (utils.getType(msg.Body) === "String") msg.Body = SpecialChar(msg.Body);
                const disallowedProperties = Object.keys(msg).filter(prop => !allowedProperties[prop]);
                if (disallowedProperties.length > 0) {
                    callback({ error: "Disallowed props: `" + disallowedProperties.join(", ") + "`" });
                    return returnPromise;
                }

                const finalAttachments = [];
                if (msg.Attachment) {
                    try {
                        const attachmentInput = Array.isArray(msg.Attachment) ? msg.Attachment : [msg.Attachment];
                        const processingPromises = attachmentInput.map(async item => {
                            try {
                                if (typeof item === "string") {
                                    return await StreamFromURL(item).catch(() => null);
                                } else if (utils.isReadableStream(item)) {
                                    return item;
                                } else if (Buffer.isBuffer(item)) {
                                    if (!item.path) {
                                        const ext = await ExtFromBuffer(item);
                                        item.path = `${RandomString(10)}.${ext}`;
                                    }
                                    return item;
                                } else if (item instanceof ArrayBuffer) {
                                    const buffer = Buffer.from(item);
                                    const ext = await ExtFromBuffer(buffer);
                                    buffer.path = `${RandomString(10)}.${ext}`;
                                    return buffer;
                                } else {
                                    return null;
                                }
                            } catch (e) {
                                return null;
                            }
                        });
                        const processedAttachments = await Promise.all(processingPromises);
                        finalAttachments.push(...processedAttachments.filter(Boolean));
                    } catch (e) {
                        callback(e);
                        return returnPromise;
                    }
                }

                function generatePayload(threadkey, sendType, text, attachmentFbids, messageId) {
                    try {
                        const x = {
                            thread_id: threadkey,
                            otid: utils.generateOfflineThreadingID(),
                            source: 65537,
                            send_type: sendType,
                            sync_group: 1,
                            mark_thread_read: 1,
                            text: text,
                            attachment_fbids: attachmentFbids || [],
                            initiating_source: 1,
                            skip_url_preview_gen: 0,
                            text_has_links: 0,
                            multitab_env: 0
                        };
                        if (messageId) {
                            x.reply_metadata = {
                                reply_source_id: messageId,
                                reply_source_type: 1,
                                reply_type: 0,
                                reply_source_attachment_id: null
                            };
                        }
                        if (msg?.Emoji) {
                            if (!msg?.EmojiSize) msg.EmojiSize = "small";
                            if (
                                msg.EmojiSize !== "small" &&
                                msg.EmojiSize !== "medium" &&
                                msg.EmojiSize !== "large" &&
                                (isNaN(msg?.EmojiSize) || msg?.EmojiSize < 1 || msg?.EmojiSize > 3)
                            ) {
                                return callback({ error: "emojiSize property is invalid" });
                            }
                            x.send_type = 1;
                            x.text = msg?.Emoji;
                            x.hot_emoji_size = !isNaN(msg?.EmojiSize)
                                ? msg?.EmojiSize
                                : EmojiSizes[msg?.EmojiSize];
                        }
                        if (msg?.Sticker) {
                            x.send_type = 2;
                            x.sticker_id = msg.Sticker;
                        }
                        if (msg?.Mentions) {
                            const arrayIds = [];
                            const arrayOffsets = [];
                            const arrayLengths = [];
                            const mention_types = [];
                            for (let i = 0; i < msg?.Mentions.length; i++) {
                                const mention = msg?.Mentions[i];
                                const tag = mention.tag;
                                const offset = text.indexOf(tag, mention.fromIndex || 0);
                                if (offset < 0) continue;
                                const id = mention.id || 0;
                                arrayIds.push(id);
                                arrayOffsets.push(offset);
                                arrayLengths.push(tag?.length);
                                mention_types.push("p");
                            }
                            x.mention_data = {
                                mention_ids: arrayIds.join(","),
                                mention_offsets: arrayOffsets.join(","),
                                mention_lengths: arrayLengths.join(","),
                                mention_types: mention_types.join(",")
                            };
                        }
                        if (msg?.Location) {
                            x.location_data = {
                                coordinates: {
                                    latitude: msg?.Location.Latitude,
                                    longitude: msg?.Location.Longitude
                                },
                                is_current_location: !!msg?.Location.Current,
                                is_live_location: !!msg?.Location.Live
                            };
                        }
                        return {
                            app_id: "2220391788200892",
                            payload: JSON.stringify({
                                epoch_id: parseInt(utils.generateOfflineThreadingID(), 10),
                                tasks: [
                                    {
                                        failure_count: null,
                                        label: "46",
                                        payload: JSON.stringify(x),
                                        queue_name: threadkey,
                                        task_id: task_id
                                    }
                                ],
                                version_id: "6903494529735864",
                                data_trace_id: null
                            }),
                            request_id: reqID,
                            type: 3
                        };
                    } catch (e) {
                        throw e;
                    }
                }

                async function sendContent(text = null, attachmentsToUpload = [], threadkey, messageId, callback) {
                    try {
                        let attachmentFbids = [];
                        if (attachmentsToUpload.length > 0) {
                            const files = await uploadFile(attachmentsToUpload) || [];
                            files.forEach(file => {
                                if (file) {
                                    const key = Object.keys(file);
                                    const type = key[0];
                                    attachmentFbids.push(file[type]);
                                }
                            });
                        }
                        const payload = generatePayload(threadkey, 3, text, attachmentFbids, messageId);
                        Context.mqttClient.publish("/ls_req", JSON.stringify(payload), { qos: 1, retain: false });
                        const handleRes = function (topic, message) {
                            try {
                                if (topic === "/ls_resp") {
                                    let jsonMsg = JSON.parse(message.toString());
                                    jsonMsg.payload = JSON.parse(jsonMsg.payload);
                                    if (jsonMsg.request_id != reqID) return;
                                    Context.mqttClient.removeListener("message", handleRes);
                                    const MessageID = jsonMsg.payload.step[1][2][2][1][3];
                                    const TimeStamp = Date.now();
                                    callback(null, { Task: "sendMessage", MessageID, ThreadID: threadkey, TimeStamp });
                                }
                            } catch (e) {
                                callback(e);
                            }
                        };
                        Context.mqttClient.on("message", handleRes);
                    } catch (e) {
                        callback(e);
                    }
                }
            try {
                await sendContent(msg.Body, finalAttachments, threadkey, messageId, callback);
            } catch(e) {}
                return returnPromise;
            } catch (e) {
                callback(e);
                return returnPromise;
            }
        };
    } catch (e) {
        throw e;
    }
}
