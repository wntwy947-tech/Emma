
function isCallable(func) {
  try {
    Reflect.apply(func, null, []);
    return true;
  } catch (error) {
    return false;
  }
}

module.exports = function (FcaData, Client, Context) {
  return async function markAsRead(threadID, callback) {
    if (!Context.mqttClient) {
      throw new Error("Not connected to MQTT");
    }

    Context.wsReqNumber += 1;
    Context.wsTaskNumber += 1;

    const label = "21";

    const taskPayload = {
      thread_id: threadID,
      last_read_watermark_ts: Date.now(),
      sync_group: 1,
    };

    const payload = JSON.stringify(taskPayload);

    const version = "31717246394556702";

    const task = {
      failure_count: null,
      label: label,
      payload: payload,
      queue_name: String(threadID),
      task_id: Context.wsTaskNumber,
    };

    const content = {
      app_id: "2220391788200892",
      payload: JSON.stringify({
        tasks: [task],
        epoch_id: 7381297531259411272,
        version_id: version,
      }),
      request_id: Context.wsReqNumber,
      type: 3,
    };

    if (isCallable(callback)) {
    }
    Context.mqttClient.publish(
      "/ls_req",
      JSON.stringify(content),
      { qos: 0, retain: false }
    );
  };
};
