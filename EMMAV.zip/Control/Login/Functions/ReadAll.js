const utils = require('../Funcs.js');

module.exports = function (FcaData, api, Context) {
	return function markAsReadAll(callback) {
		let resolveFunc = function () {};
		let rejectFunc = function () {};
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});

		if (!callback) {
			callback = function (err, result) {
				if (err) return rejectFunc(err);
				resolveFunc(result);
			};
		}

		const form = { folder: "inbox" };

		try {
			FcaData.post(
				"https://www.facebook.com/ajax/mercury/mark_folder_as_read.php",
				Context.jar,
				form
			)
				.then(utils.saveCookies(Context.jar))
				.then(utils.parseAndCheckLogin(Context, FcaData))
				.then(function (resData) {
					try {
						if (!resData) {
							throw new Error("Empty response received from Facebook.");
						}
						if (resData.error) {
							throw new Error(
								`Facebook API returned an error: ${resData.errorDescription || resData.error}`
							);
						}

						return callback(null, { success: true });
					} catch (innerErr) {
						return callback(innerErr);
					}
				})
				.catch(function (err) {
                console.log(err)
					return callback(err);
				});
		} catch (outerErr) {
			callback(outerErr);
			rejectFunc(outerErr);
		}

		return returnPromise;
	};
}
