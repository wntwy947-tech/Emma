const utils = require('../Funcs.js');


module.exports = function(FcaData, Client, Context) {
	return function createNewGroup(ParticipantIDs, groupTitle, callback) {
		if (utils.getType(groupTitle) == "Function") {
			callback = groupTitle;
			groupTitle = null;
		}

		if (utils.getType(ParticipantIDs) !== "Array") {
			throw { error: "createNewGroup: ParticipantIDs should be an array." };
		}

		if (ParticipantIDs.length < 2) {
			throw { error: "createNewGroup: ParticipantIDs should have at least 2 IDs." };
		}

		let resolveFunc = function () { };
		let rejectFunc = function () { };
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});

		if (!callback) {
			callback = function (err, ThreadID) {
				if (err) {
					return rejectFunc(err);
				}
				resolveFunc(ThreadID);
			};
		}

		const pids = [];
		for (const n in ParticipantIDs) {
			pids.push({
				fbid: ParticipantIDs[n]
			});
		}
		pids.push({ fbid: Context.i_userID || Context.userID });

		const form = {
			fb_api_caller_class: "RelayModern",
			fb_api_req_friendly_name: "MessengerGroupCreateMutation",
			av: Context.i_userID || Context.userID,
			//This doc_id is valid as of January 11th, 2020
			doc_id: "577041672419534",
			variables: JSON.stringify({
				input: {
					entry_point: "jewel_new_group",
					actor_id: Context.i_userID || Context.userID,
					participants: pids,
					client_mutation_id: Math.round(Math.random() * 1024).toString(),
					thread_settings: {
						name: groupTitle,
						joinable_mode: "PRIVATE",
						thread_image_fbid: null
					}
				}
			})
		};

		FcaData
			.post(
				"https://www.facebook.com/api/graphql/",
				Context.jar,
				form
			)
			.then(utils.parseAndCheckLogin(Context, FcaData))
			.then(function (resData) {
				if (resData.errors) {
					throw resData;
				}
				return callback(null, resData.data.messenger_group_thread_create.thread.thread_key.thread_fbid);
			})
			.catch(function (err) {
				return callback(err);
			});

		return returnPromise;
	};
};
