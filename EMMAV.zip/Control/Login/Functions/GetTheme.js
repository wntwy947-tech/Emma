const utils = require('../Funcs.js')

function Filter(themes) {
  return themes.map(theme => {
    const result = {
      name: theme.accessibility_label,
      id: theme.id,
      normal_mode_images: [],
      dark_mode_images: []
    };

    
    if (theme.app_color_mode === "NORMAL") {
      if (theme.background_asset && theme.background_asset.image) {
        result.normal_mode_images.push(theme.background_asset.image.uri);
      }

      if (theme.icon_asset && theme.icon_asset.image) {
        result.normal_mode_images.push(theme.icon_asset.image.uri);
      }
    }

    
    if (theme.alternative_themes) {
      theme.alternative_themes.forEach(altTheme => {

        if (altTheme.app_color_mode === "DARK") {
      
          if (altTheme.background_asset && altTheme.background_asset.image) {
            result.dark_mode_images.push(altTheme.background_asset.image.uri);
          }
      
          if (altTheme.icon_asset && altTheme.icon_asset.image) {
            result.dark_mode_images.push(altTheme.icon_asset.image.uri);
          }
        }
      });
    }

    return result;
  });
}

function formatData(resData) {
  const themes = resData.messenger_thread_themes;
  return Filter(themes);
}

module.exports = function (defaultFuncs, api, ctx) {
  return function getThreadThemes(callback) {
    let resolveFunc = function () { };
    let rejectFunc = function () { };
    const returnPromise = new Promise(function (resolve, reject) {
      resolveFunc = resolve;
      rejectFunc = reject;
    });

    if (!callback) {
      callback = function (err, data) {
        if (err) {
          return rejectFunc(err);
        }
        resolveFunc(data);
      };
    }

    const form = {
      av: ctx.i_userID || ctx.userID,
      fb_api_caller_class: "RelayModern",
      fb_api_req_friendly_name: "MWPThreadThemeQuery_AllThemesQuery",
      doc_id: "26068956082718275",
      variables: JSON.stringify({
        version: "default",
      }),
      fb_dtsg: ctx.fb_dtsg
    };

    defaultFuncs
      .post("https://web.facebook.com/api/graphql/", ctx.jar, form)
      .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
      .then(function (resData) {
        if (resData.errors) {
          throw resData;
        }
        return callback(null, formatData(resData.data));
      })
      .catch(function (err) {
        return callback(err);
      });

    return returnPromise;
  };
};
