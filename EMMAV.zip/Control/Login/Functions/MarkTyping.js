function isCallable(func) {
  try {
    Reflect.apply(func, null, []);
    return true;
  } catch {
    return false;
  }
}

module.exports = function (FcaData, Client, Context) {
  return async function sendTypingState(threadID, isGroup = false, isTyping = true, callback) {
    if (!Context.mqttClient) {
      throw new Error("Not connected to MQTT");
    }

    if (typeof Context.wsReqNumber !== "number") Context.wsReqNumber = 0;
    Context.wsReqNumber += 1;

    const version = "31717246394556702";

    const payload = {
      label: "3",
      payload: JSON.stringify({
        thread_key: threadID,
        is_group_thread: isGroup ? 1 : 0,
        is_typing: isTyping ? 1 : 0,
        attribution: 0,
        sync_group: 1,
        thread_type: isGroup ? 2 : 1,
      }),
      version,
    };

    const content = {
      app_id: "2220391788200892",
      payload: JSON.stringify(payload),
      request_id: Context.wsReqNumber,
      type: 4,
    };

    Context.mqttClient.publish("/ls_req", JSON.stringify(content), {
      qos: 1,
      retain: false,
    });

    if (isCallable(callback)) {
      callback(null, {
        success: true,
        threadID,
        isTyping,
        request_id: Context.wsReqNumber,
      });
    }

    return { success: true, threadID, isTyping };
  };
}
