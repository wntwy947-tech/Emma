"use strict";

const Funcs = require('../Funcs.js');
const { generateOfflineThreadingID } = Funcs
function canBeCalled(func) {
 try {
  Reflect.apply(func, null, []);
  return true;
 } catch (error) {
  return false;
 }
}

module.exports = function (FcaData, Client, Context) {
 return function toggleAdminApproval(threadKey, enabled, callback) {
  if (!Context.mqttClient) {
   throw new Error('Not connected to MQTT');
  }

  if (typeof threadKey !== 'string' || typeof enabled !== 'boolean') {
   throw new Error('Invalid threadKey or enabled value'); 
  }

  Context.wsReqNumber += 1;
  Context.wsTaskNumber += 1;

  const queryPayload = {
   thread_key: threadKey,
   enabled: enabled ? 1 : 0,
   sync_group: 1
  };

  const query = {
   failure_count: null,
   label: '28',
   payload: JSON.stringify(queryPayload),
   queue_name: 'set_needs_admin_approval_for_new_participant',
   task_id: Context.wsTaskNumber
  };

  const context = {
   app_id: '772021112871879',
   payload: {
    data_trace_id: null,
    epoch_id: parseInt(generateOfflineThreadingID), 
    tasks: [query],
    version_id: '8595046457214655'
   },
   request_id: Context.wsReqNumber,
   type: 3
  };

  context.payload = JSON.stringify(context.payload);

  Context.mqttClient.publish('/ls_req', JSON.stringify(context), { qos: 1, retain: false }, (err) => {
   if (err) {
    if (callback) callback(err); 
   } else {
    if (callback) callback(null, context); 
   }
  });
 };
};
