

module.exports = function (FcaData, Client, Context) {
    return async function changeContactNickname(newNickname, threadKey, contactID, callback) {
        if (!Context.mqttClient) {
            throw new Error("Not connected to MQTT");
        }
        Context.wsReqNumber += 1;
        Context.wsTaskNumber += 1;
        
        var form = JSON.stringify({
            "app_id": "772021112871879",
            "payload": JSON.stringify({
                epoch_id: null,
                tasks: [{
                    label: '44',
                    payload: JSON.stringify({
                        "thread_key": threadKey,
                        "contact_id": contactID,
                        "nickname": newNickname,
                        "sync_group": 1
                    }),
                    queue_name: 'thread_participant_nickname',
                    task_id: Context.wsTaskNumber,
                    failure_count: null
                }],
                version_id: '8595046457214655'
            }),
            "request_id": Context.wsReqNumber,
            "type": 3
        });

        Context.mqttClient.publish('/ls_req', form);

        if (typeof callback === 'function') {
            callback(null, { success: true, request_id: Context.wsReqNumber });
        }
    };
};