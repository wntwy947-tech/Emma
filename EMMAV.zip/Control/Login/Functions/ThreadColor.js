const utils = require('../Funcs.js');


  module.exports = function(FcaData, Client, Context) {
	return function changeThreadColor(color, ThreadID, callback) {
		let resolveFunc = function () { };
		let rejectFunc = function () { };
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});

		if (!callback) {
			callback = function (err) {
				if (err) {
					return rejectFunc(err);
				}
				resolveFunc(err);
			};
		}

		if (!isNaN(color)) {
			color = color.toString();
		}
		const validatedColor = color !== null ? color.toLowerCase() : color; 
		const form = {
			dpr: 1,
			queries: JSON.stringify({
				o0: {
					doc_id: "1727493033983591",
					query_params: {
						data: {
							actor_id: Context.i_userID || Context.userID,
							client_mutation_id: "0",
							source: "SETTINGS",
							theme_id: validatedColor,
							thread_id: ThreadID
						}
					}
				}
			})
		};

		FcaData
			.post("https://www.facebook.com/api/graphqlbatch/", Context.jar, form)
			.then(utils.parseAndCheckLogin(Context, FcaData))
			.then(function (resData) {
				if (resData[resData.length - 1].error_results > 0) {
					throw new utils.CustomError(resData[0].o0.errors);
				}

				return callback();
			})
			.catch(function (err) {
				return callback(err);
			});

		return returnPromise;
	};
};
