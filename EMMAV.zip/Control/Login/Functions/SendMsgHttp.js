const mimeDB = require("mime-db");
const axios = require("axios");
const utils = require('../Funcs.js');
const { fileTypeFromBuffer } = require('file-type');

const randomString = function (max, onlyOnce = false, possible) {
    if (!max || isNaN(max))
        max = 10;
    let text = "";
    possible = possible || "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (let i = 0; i < max; i++) {
        let random = Math.floor(Math.random() * possible.length);
        if (onlyOnce) {
            while (text.includes(possible[random]))
                random = Math.floor(Math.random() * possible.length);
        }
        text += possible[random];
    }
    return text;
};

const getStreamFromURL = async function (url = "", pathName = "", options = {}) {
    const getExtFromMimeType = function (mimeType = "") {
        return mimeDB[mimeType] ? (mimeDB[mimeType].extensions || [])[0] || "unknown" : "unknown";
    }

    if (!options && typeof pathName === "object") {
        options = pathName;
        pathName = "";
    }
    try {
        if (!url || typeof url !== "string")
            throw new Error(`The first argument (url) must be a string`);
        const response = await axios({
            url,
            method: "GET",
            responseType: "stream",
            ...options
        });
        if (!pathName)
            pathName = randomString(10) + (response.headers["content-type"] ? '.' + getExtFromMimeType(response.headers["content-type"]) : ".noext");
        response.data.path = pathName;
        return response.data;
    }
    catch (err) {
        throw err;
    }
}

async function getExtFromBuffer(buffer) {
    const type = await fileTypeFromBuffer(buffer);
    return type ? type.ext : 'bin';
}

const allowedProperties = {
    Attachment: true,
    Sticker: true,
    Emoji: true,
    EmojiSize: true,
    Body: true,
    Mentions: true,
    Location: true,
};

module.exports = function (FcaData, Client, Context) {
    async function uploadAttachment(attachments) {
        var uploads = [];
        for (var i = 0; i < attachments.length; i++) {
            if (!utils.isReadableStream(attachments[i]) && !Buffer.isBuffer(attachments[i])) {
                throw new Error("Attachment should be a readable stream or a buffer, and not " + utils.getType(attachments[i]) + ".");
            }
            const uploaded = await FcaData.postFormData("https://upload.facebook.com/ajax/mercury/upload.php", Context.jar, {
                upload_1024: attachments[i],
                voice_clip: "true"
            }, {}).then(utils.parseAndCheckLogin(Context, FcaData));
            if (uploaded.error) {
                throw uploaded;
            }
            uploads.push(uploaded.payload.metadata[0]);
        }
        return uploads;
    }

    async function sendContent(form, threadID, isSingleUser, messageAndOTID) {
        if (utils.getType(threadID) === "Array") {
            for (var i = 0; i < threadID.length; i++) {
                form["specific_to_list[" + i + "]"] = "fbid:" + threadID[i];
            }
            form["specific_to_list[" + threadID.length + "]"] = "fbid:" + Context.userID;
            form["client_thread_id"] = "root:" + messageAndOTID;
        } else {
            if (isSingleUser) {
                form["specific_to_list[0]"] = "fbid:" + threadID;
                form["specific_to_list[1]"] = "fbid:" + Context.userID;
                form["other_user_fbid"] = threadID;
            } else {
                form["thread_fbid"] = threadID;
            }
        }

        if (Context.GlobalSettings.pageID) {
            form["author"] = "fbid:" + Context.GlobalSettings.pageID;
            form["specific_to_list[1]"] = "fbid:" + Context.GlobalSettings.pageID;
            form["creator_info[creatorID]"] = Context.userID;
            form["creator_info[creatorType]"] = "direct_admin";
            form["creator_info[labelType]"] = "sent_message";
            form["creator_info[pageID]"] = Context.GlobalSettings.pageID;
            form["request_user_id"] = Context.GlobalSettings.pageID;
            form["creator_info[profileURI]"] =
                "https://www.facebook.com/profile.php?id=" + Context.userID;
        }

        const resData = await FcaData.post("https://www.facebook.com/messaging/send/", Context.jar, form).then(utils.parseAndCheckLogin(Context, FcaData));
        if (!resData) {
            throw new Error("Send message failed.");
        }
        if (resData.error) {
            if (resData.error === 1545012) {
                return
            }
            throw resData;
        }
        const messageInfo = resData.payload.actions.reduce((p, v) => {
            return {
                ThreadID: v.thread_fbid,
                MessageID: v.message_id,
                Timestamp: v.timestamp
            } || p;
        }, null);
        return messageInfo;
    }

    return async (msg, threadID, replyToMessage, isSingleUser = false) => {
        let msgType = utils.getType(msg);
        let threadIDType = utils.getType(threadID);
        let messageIDType = utils.getType(replyToMessage);
        if (msgType !== "String" && msgType !== "Object") throw new Error("Message should be of type string or object and not " + msgType + ".");
        if (threadIDType !== "Array" && threadIDType !== "Number" && threadIDType !== "String") throw new Error("ThreadID should be of type number, string, or array and not " + threadIDType + ".");
        if (replyToMessage && messageIDType !== 'String') throw new Error("MessageID should be of type string and not " + threadIDType + ".");
        
        if (msgType === "String") {
            msg = {
                Body: msg
            };
        }

        let disallowedProperties = Object.keys(msg).filter(prop => !allowedProperties[prop]);
        if (disallowedProperties.length > 0) {
            throw new Error("Dissallowed props: `" + disallowedProperties.join(", ") + "`");
        }
        
        const finalAttachments = [];
        if (msg.Attachment) {
            const attachmentInput = Array.isArray(msg.Attachment) ? msg.Attachment : [msg.Attachment];
            const processingPromises = attachmentInput.map(async item => {
                if (typeof item === 'string') {
                    return getStreamFromURL(item).catch(() => null);
                } else if (utils.isReadableStream(item)) {
                    return item;
                } else if (Buffer.isBuffer(item)) {
                    if (!item.path) {
                        const ext = await getExtFromBuffer(item);
                        item.path = `${randomString(10)}.${ext}`;
                    }
                    return item;
                } else if (item instanceof ArrayBuffer) {
                    const buffer = Buffer.from(item);
                    const ext = await getExtFromBuffer(buffer);
                    buffer.path = `${randomString(10)}.${ext}`;
                    return buffer;
                } else {
                    return null;
                }
            });
            const processedAttachments = await Promise.all(processingPromises);
            finalAttachments.push(...processedAttachments.filter(Boolean));
        }

        let messageAndOTID = utils.generateOfflineThreadingID();
        let form = {
            client: "mercury",
            action_type: "ma-type:user-generated-message",
            author: "fbid:" + Context.userID,
            timestamp: Date.now(),
            timestamp_absolute: "Today",
            timestamp_relative: utils.generateTimestampRelative(),
            timestamp_time_passed: "0",
            is_unread: false,
            is_cleared: false,
            is_forward: false,
            is_filtered_content: false,
            is_filtered_content_bh: false,
            is_filtered_content_account: false,
            is_filtered_content_quasar: false,
            is_filtered_content_invalid_app: false,
            is_spoof_warning: false,
            source: "source:chat:web",
            "source_tags[0]": "source:chat",
            ...(msg.Body && {
                body: msg.Body
            }),
            html_body: false,
            ui_push_phase: "V3",
            status: "0",
            offline_threading_id: messageAndOTID,
            message_id: messageAndOTID,
            threading_id: utils.generateThreadingID(Context.clientID),
            "ephemeral_ttl_mode:": "0",
            manual_retry_cnt: "0",
            has_attachment: !!(finalAttachments.length || msg.Sticker),
            signatureID: utils.getSignatureID(),
            ...(replyToMessage && {
                replied_to_message_id: replyToMessage
            })
        };

        if (msg.Location) {
            if (!msg.Location.latitude || !msg.Location.longitude) throw new Error("Location property needs both latitude and longitude");
            form["location_attachment[coordinates][latitude]"] = msg.Location.latitude;
            form["location_attachment[coordinates][longitude]"] = msg.Location.longitude;
            form["location_attachment[is_current_location]"] = !!msg.Location.current;
        }
        if (msg.Sticker) {
            form["sticker_id"] = msg.Sticker;
        }
        if (finalAttachments.length > 0) {
            form.image_ids = [];
            form.gif_ids = [];
            form.file_ids = [];
            form.video_ids = [];
            form.audio_ids = [];
            const files = await uploadAttachment(finalAttachments);
            files.forEach(file => {
                const type = Object.keys(file)[0];
                form["" + type + "s"].push(file[type]);
            });
        }
        if (msg.Emoji) {
            if (!msg.EmojiSize) {
                msg.EmojiSize = "medium";
            }
            if (msg.EmojiSize !== "small" && msg.EmojiSize !== "medium" && msg.EmojiSize !== "large") {
                throw new Error("EmojiSize property is invalid");
            }
            if (form.body) {
                form.body = msg.Emoji;
            }
            form["tags[0]"] = "hot_emoji_size:" + msg.EmojiSize;
        }
        if (msg.Mentions) {
            for (let i = 0; i < msg.Mentions.length; i++) {
                const mention = msg.Mentions[i];
                const tag = mention.tag;
                if (typeof tag !== "string") {
                    throw new Error("Mention tags must be strings.");
                }
                const offset = msg.Body.indexOf(tag, mention.fromIndex || 0);
                if (offset < 0) throw new Error("Mention tag was not found in message body.");
                if (!mention?.id) throw new Error("Mention id must be not null.");
                const id = mention.id || 0;
                const emptyChar = '\u200E';
                form["body"] = emptyChar + msg.Body;
                form["profile_xmd[" + i + "][offset]"] = offset + 1;
                form["profile_xmd[" + i + "][length]"] = tag.length;
                form["profile_xmd[" + i + "][id]"] = id;
                form["profile_xmd[" + i + "][type]"] = "p";
            }
        }
        const result = await sendContent(form, threadID, isSingleUser, messageAndOTID);
        return result;
    };
};

