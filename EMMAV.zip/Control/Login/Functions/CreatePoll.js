const utils = require('../Funcs.js');

const { generateOfflineThreadingID} = utils;

function isCallable(func) {
  try {
    Reflect.apply(func, null, []);
    return true;
  } catch (error) {
    return false;
  }
}

module.exports = function (FcaData, Client, Context) {
  return function createPollMqtt(title, options, threadID, callback) {
    if (!Context.mqttClient) {
      throw new Error('Not connected to MQTT');
    }

    Context.wsReqNumber += 1;
    Context.wsTaskNumber += 1;

    const taskPayload = {
      question_text: title,
      thread_key: threadID,
      options: options,
      sync_group: 1,
    };

    const task = {
      failure_count: null,
      label: '163',
      payload: JSON.stringify(taskPayload),
      queue_name: 'poll_creation',
      task_id: Context.wsTaskNumber,
    };

    const content = {
      app_id: '2220391788200892',
      payload: JSON.stringify({
        data_trace_id: null,
        epoch_id: parseInt(generateOfflineThreadingID()),
        tasks: [task],
        version_id: '7158486590867448',
      }),
      request_id: Context.wsReqNumber,
      type: 3,
    };

    if (isCallable(callback)) {
    }

    Context.mqttClient.publish('/ls_req', JSON.stringify(content), { qos: 1, retain: false });
  };
};
