const utils = require('../Funcs.js')

module.exports = function(FcaData, Client, Context) {

  return function CreateNote(text, privacy = "EVERYONE", callback) {
    if (typeof callback !== 'function') {
      callback = () => {};
    }

    const variables = {
      input: {
        client_mutation_id: Math.round(Math.random() * 10).toString(),
        actor_id: Context.userID,
        description: text,
        duration: 86400, 
        note_type: "TEXT_NOTE",
        privacy,
        session_id: utils.getGUID(),
      },
    };
    const form = {
      fb_api_caller_class: "RelayModern",
      fb_api_req_friendly_name: "MWInboxTrayNoteCreationDialogCreationStepContentMutation",
      variables: JSON.stringify(variables),
      doc_id: "24060573783603122",
    };

    FcaData
      .post("https://www.facebook.com/api/graphql/", Context.jar, form)
      .then(utils.parseAndCheckLogin(Context, FcaData))
      .then(resData => {
        if (resData && resData.errors) throw resData.errors[0];
        const status = resData?.data?.xfb_rich_status_create?.status;
        console.log(status)
        if (!status) throw new Error("Could not find note status in the server response.");
        callback(null, status);
      })
      .catch(err => {
      return err
      });
  }

};