

module.exports = function (FcaData, Client, Context) {
    return async function changeQuickReaction(emoji, threadKey,callback) {
        if (!Context.mqttClient) {
            throw new Error("Not connected to MQTT");
        }
        Context.wsReqNumber += 1;
        Context.wsTaskNumber += 1;
        
        var form = JSON.stringify({
            "app_id": "772021112871879",
            "payload": JSON.stringify({
                epoch_id: null,
                tasks: [{
                    label: '100003',
                    payload: JSON.stringify({
                        "thread_key": threadKey,
                        "custom_emoji": emoji,
                        "avatar_sticker_instruction_key_id": null,
                        "sync_group": 1
                    }),
                    queue_name: 'thread_quick_reaction',
                    task_id: Context.wsTaskNumber,
                    failure_count: null
                }],
                version_id: '8595046457214655'
            }),
            "request_id": Context.wsReqNumber,
            "type": 3
        });

        Context.mqttClient.publish('/ls_req', form);

        if (typeof callback === 'function') {
            callback(null, { success: true, request_id: Context.wsReqNumber });
        }
    };
};