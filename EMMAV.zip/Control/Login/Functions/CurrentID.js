  module.exports = function (FcaData, Client, Context) {
	return function CurrentID() {
		return Context.i_userID || Context.userID;
	};
};
