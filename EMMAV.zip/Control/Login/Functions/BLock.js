const utils = require('../Funcs.js');

const { generateOfflineThreadingID,  getGUID } = utils;

function isCallable(func) {
  try {
    Reflect.apply(func, null, []);
    return true;
  } catch (error) {
    return false;
  }
}

module.exports = function (FcaData, Client, Context) {
  return function changeBlockedStatusMqtt(userID, status, type, callback) {
    if (!Context.mqttClient) {
      throw new Error('Not connected to MQTT');
    }

    Context.wsReqNumber += 1;
    Context.wsTaskNumber += 1;

    const label = '334';
    let userBlockAction = 0;

    switch (type) {
      case 'messenger':
        if (status) {
          userBlockAction = 1;
        } else {
          userBlockAction = 0; 
        }
        break;
      case 'facebook':
        if (status) {
          userBlockAction = 3; 
        } else {
          userBlockAction = 2; 
        }
        break;
      default:
        throw new Error('Invalid type');
    }

    const taskPayload = {
      blockee_id: userID,
      request_id: getGUID(),
      user_block_action: userBlockAction,
    };

    const payload = JSON.stringify(taskPayload);
    const version = '25393437286970779';

    const task = {
      failure_count: null,
      label: label,
      payload: payload,
      queue_name: 'native_sync_block',
      task_id: Context.wsTaskNumber,
    };

    const content = {
      app_id: '2220391788200892',
      payload: JSON.stringify({
        tasks: [task],
        epoch_id: parseInt(generateOfflineThreadingID()),
        version_id: version,
      }),
      request_id: Context.wsReqNumber,
      type: 3,
    };

    if (isCallable(callback)) {
    }

    Context.mqttClient.publish('/ls_req', JSON.stringify(content), { qos: 1, retain: false });
  };
};
