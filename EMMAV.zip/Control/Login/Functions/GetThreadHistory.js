const utils = require('../Funcs.js');



function getExtension(original_extension, filename = "") {
	if (original_extension) {
		return original_extension;
	}
	else {
		const extension = filename.split(".").pop();
		if (extension === filename) {
			return "";
		}
		else {
			return extension;
		}
	}
}

function formatAttachmentsGraphQLResponse(attachment) {
	switch (attachment.__typename) {
		case "MessageImage":
			return {
				Type: "Photo",
				ID: attachment.legacy_attachment_id,
				filename: attachment.filename,
				original_extension: getExtension(attachment.original_extension, attachment.filename),
				thumbnailUrl: attachment.thumbnail.uri,

				previewUrl: attachment.preview.uri,
				previewWidth: attachment.preview.width,
				previewHeight: attachment.preview.height,

				largePreviewUrl: attachment.large_preview.uri,
				largePreviewHeight: attachment.large_preview.height,
				largePreviewWidth: attachment.large_preview.width,

				Url: attachment.large_preview.uri,
				width: attachment.large_preview.width, 
				height: attachment.large_preview.height, 
				name: attachment.filename, 
				attributionApp: attachment.attribution_app
					? {
						attributionAppID: attachment.attribution_app.id,
						name: attachment.attribution_app.name,
						logo: attachment.attribution_app.square_logo
					}
					: null
			};
		case "MessageAnimatedImage":
			return {
				Type: "Animated_Image",
				ID: attachment.legacy_attachment_id,
				filename: attachment.filename,
				original_extension: getExtension(attachment.original_extension, attachment.filename),

				previewUrl: attachment.preview_image.uri,
				previewWidth: attachment.preview_image.width,
				previewHeight: attachment.preview_image.height,

				Url: attachment.animated_image.uri,
				width: attachment.animated_image.width,
				height: attachment.animated_image.height,

				thumbnailUrl: attachment.preview_image.uri,
				name: attachment.filename, 
				facebookUrl: attachment.animated_image.uri, 
				rawGifImage: attachment.animated_image.uri,
				animatedGifUrl: attachment.animated_image.uri,
				animatedGifPreviewUrl: attachment.preview_image.uri, 
				animatedWebpUrl: attachment.animated_image.uri, 
				animatedWebpPreviewUrl: attachment.preview_image.uri,
				attributionApp: attachment.attribution_app
					? {
						attributionAppID: attachment.attribution_app.id,
						name: attachment.attribution_app.name,
						logo: attachment.attribution_app.square_logo
					}
					: null
			};
		case "MessageVideo":
			return {
				Type: "Video",
				ID: attachment.legacy_attachment_id,
				filename: attachment.filename,
				original_extension: getExtension(attachment.original_extension, attachment.filename),
				duration: attachment.playable_duration_in_ms,

				thumbnailUrl: attachment.large_image.uri,

				previewUrl: attachment.large_image.uri,
				previewWidth: attachment.large_image.width,
				previewHeight: attachment.large_image.height,

				Url: attachment.playable_url,
				width: attachment.original_dimensions.x,
				height: attachment.original_dimensions.y,

				videoType: attachment.video_type.toLowerCase()
			};
		case "MessageFile":
			return {
				Type: "File",
				ID: attachment.message_file_fbid,
				filename: attachment.filename,
				original_extension: getExtension(attachment.original_extension, attachment.filename),

				Url: attachment.url,
				isMalicious: attachment.is_malicious,
				contentType: attachment.content_type,

				name: attachment.filename, 
				mimeType: "", 
				fileSize: -1
			};
		case "MessageAudio":
			return {
				Type: "Audio",
				ID: attachment.url_shimhash, 
				filename: attachment.filename,
				original_extension: getExtension(attachment.original_extension, attachment.filename),

				duration: attachment.playable_duration_in_ms,
				audioType: attachment.audio_type,
				Url: attachment.playable_url,

				isVoiceMail: attachment.is_voicemail
			};
		default:
			return {
				error: "Don't know about attachment type " + attachment.__typename
			};
	}
}

function formatExtensibleAttachment(attachment) {
	if (attachment.story_attachment) {
		return {
			Type: "Share",
			ID: attachment.legacy_attachment_id,
			Url: attachment.story_attachment.url,

			title: attachment.story_attachment.title_with_entities.text,
			description:
				attachment.story_attachment.description &&
				attachment.story_attachment.description.text,
			source:
				attachment.story_attachment.source == null
					? null
					: attachment.story_attachment.source.text,

			image:
				attachment.story_attachment.media == null
					? null
					: attachment.story_attachment.media.animated_image == null &&
						attachment.story_attachment.media.image == null
						? null
						: (
							attachment.story_attachment.media.animated_image ||
							attachment.story_attachment.media.image
						).uri,
			width:
				attachment.story_attachment.media == null
					? null
					: attachment.story_attachment.media.animated_image == null &&
						attachment.story_attachment.media.image == null
						? null
						: (
							attachment.story_attachment.media.animated_image ||
							attachment.story_attachment.media.image
						).width,
			height:
				attachment.story_attachment.media == null
					? null
					: attachment.story_attachment.media.animated_image == null &&
						attachment.story_attachment.media.image == null
						? null
						: (
							attachment.story_attachment.media.animated_image ||
							attachment.story_attachment.media.image
						).height,
			playable:
				attachment.story_attachment.media == null
					? null
					: attachment.story_attachment.media.is_playable,
			duration:
				attachment.story_attachment.media == null
					? null
					: attachment.story_attachment.media.playable_duration_in_ms,
			playableUrl:
				attachment.story_attachment.media == null
					? null
					: attachment.story_attachment.media.playable_url,

			SubAttachments: attachment.story_attachment.subattachments,
			properties: attachment.story_attachment.properties.reduce(function (
				obj,
				cur
			) {
				obj[cur.key] = cur.value.text;
				return obj;
			},
				{}),

			
			animatedImageSize: "",
			facebookUrl: "", 
			styleList: "", 
			target: "", 
			thumbnailUrl:
				attachment.story_attachment.media == null
					? null
					: attachment.story_attachment.media.animated_image == null &&
						attachment.story_attachment.media.image == null
						? null
						: (
							attachment.story_attachment.media.animated_image ||
							attachment.story_attachment.media.image
						).uri,
			thumbnailWidth:
				attachment.story_attachment.media == null
					? null
					: attachment.story_attachment.media.animated_image == null &&
						attachment.story_attachment.media.image == null
						? null
						: (
							attachment.story_attachment.media.animated_image ||
							attachment.story_attachment.media.image
						).width, 
			thumbnailHeight:
				attachment.story_attachment.media == null
					? null
					: attachment.story_attachment.media.animated_image == null &&
						attachment.story_attachment.media.image == null
						? null
						: (
							attachment.story_attachment.media.animated_image ||
							attachment.story_attachment.media.image
						).height 
		};
	} else {
		return { error: "Don't know what to do with extensible_attachment." };
	}
}

function formatReactionsGraphQL(reaction) {
	return {
		Reaction: reaction.reaction,
		UserID: reaction.user.id
	};
}

function formatEventData(Event) {
	if (Event == null) {
		return {};
	}

	switch (Event.__typename) {
		case "ThemeColorExtensibleMessageAdminText":
			return {
				color: Event.theme_color
			};
		case "ThreadNicknameExtensibleMessageAdminText":
			return {
				nickname: Event.nickname,
				ParticipantID: Event.participant_id
			};
		case "ThreadIconExtensibleMessageAdminText":
			return {
				threadIcon: Event.thread_icon
			};
		case "InstantGameUpdateExtensibleMessageAdminText":
			return {
				gameID: (Event.game == null ? null : Event.game.id),
				update_type: Event.update_type,
				collapsed_text: Event.collapsed_text,
				expanded_text: Event.expanded_text,
				instant_game_update_data: Event.instant_game_update_data
			};
		case "GameScoreExtensibleMessageAdminText":
			return {
				game_type: Event.game_type
			};
		case "RtcCallLogExtensibleMessageAdminText":
			return {
				Event: Event.Event,
				is_video_call: Event.is_video_call,
				server_info_data: Event.server_info_data
			};
		case "GroupPollExtensibleMessageAdminText":
			return {
				Event_type: Event.Event_type,
				total_count: Event.total_count,
				question: Event.question
			};
		case "AcceptPendingThreadExtensibleMessageAdminText":
			return {
				accepter_id: Event.accepter_id,
				requester_id: Event.requester_id
			};
		case "ConfirmFriendRequestExtensibleMessageAdminText":
			return {
				friend_request_recipient: Event.friend_request_recipient,
				friend_request_sender: Event.friend_request_sender
			};
		case "AddContactExtensibleMessageAdminText":
			return {
				contact_added_id: Event.contact_added_id,
				contact_adder_id: Event.contact_adder_id
			};
		case "AdExtensibleMessageAdminText":
			return {
				ad_client_token: Event.ad_client_token,
				ad_id: Event.ad_id,
				ad_preferences_link: Event.ad_preferences_link,
				ad_properties: Event.ad_properties
			};
		
		case "ParticipantJoinedGroupCallExtensibleMessageAdminText":
		case "ThreadEphemeralTtlModeExtensibleMessageAdminText":
		case "StartedSharingVideoExtensibleMessageAdminText":
		case "LightweightEventCreateExtensibleMessageAdminText":
		case "LightweightEventNotifyExtensibleMessageAdminText":
		case "LightweightEventNotifyBeforeEventExtensibleMessageAdminText":
		case "LightweightEventUpdateTitleExtensibleMessageAdminText":
		case "LightweightEventUpdateTimeExtensibleMessageAdminText":
		case "LightweightEventUpdateLocationExtensibleMessageAdminText":
		case "LightweightEventDeleteExtensibleMessageAdminText":
			return {};
		default:
			return {
				error: "Don't know what to with Event data type " + Event.__typename
			};
	}
}

function formatMessagesGraphQLResponse(data) {
	const messageThread = data.o0.data.message_thread;
	const ThreadID = messageThread.thread_key.thread_fbid
		? messageThread.thread_key.thread_fbid
		: messageThread.thread_key.other_user_id;

	const messages = messageThread.messages.nodes.map(function (d) {
		switch (d.__typename) {
			case "UserMessage":
				var maybeStickerAttachment;
				if (d.sticker) {
					maybeStickerAttachment = [
						{
							Type: "Sticker",
							ID: d.sticker.id,
							Url: d.sticker.url,

							packID: d.sticker.pack ? d.sticker.pack.id : null,
							spriteUrl: d.sticker.sprite_image,
							spriteUrl2x: d.sticker.sprite_image_2x,
							width: d.sticker.width,
							height: d.sticker.height,

							caption: d.snippet, 
							description: d.sticker.label, 

							frameCount: d.sticker.frame_count,
							frameRate: d.sticker.frame_rate,
							framesPerRow: d.sticker.frames_per_row,
							framesPerCol: d.sticker.frames_per_col,

							stickerID: d.sticker.id, 
							spriteURI: d.sticker.sprite_image, 
							spriteURI2x: d.sticker.sprite_image_2x 
						}
					];
				}

				var MentionsObj = {};
				if (d.message !== null) {
					d.message.ranges.forEach(e => {
						MentionsObj[e.entity.id] = d.message.text.substr(e.offset, e.length);
					});
				}

				return {
					Type: "Message",
					Attachments: maybeStickerAttachment
						? maybeStickerAttachment
						: d.blob_attachments && d.blob_attachments.length > 0
							? d.blob_attachments.map(formatAttachmentsGraphQLResponse)
							: d.extensible_attachment
								? [formatExtensibleAttachment(d.extensible_attachment)]
								: [],
					Body: d.message !== null ? d.message.text : '',
					Group: messageThread.thread_type === "GROUP",
					MessageID: d.message_id,
					SenderID: d.message_sender.id,
					ThreadID: ThreadID,
					TimeStamp: d.timestamp_precise,

					Mentions: MentionsObj,
					isUnread: d.unread,

					// New
					messageReactions: d.message_reactions
						? d.message_reactions.map(formatReactionsGraphQL)
						: null,
					isSponsored: d.is_sponsored,
					snippet: d.snippet
				};
			case "ThreadNameMessage":
				return {
					Type: "Event",
					MessageID: d.message_id,
					ThreadID: ThreadID,
					Group: messageThread.thread_type === "GROUP",
					SenderID: d.message_sender.id,
					TimeStamp: d.timestamp_precise,
					EventType: "change_thread_name",
					snippet: d.snippet,
					EventData: {
						threadName: d.thread_name
					},

		
					Author: d.message_sender.id,
					LogMessageType: "log:thread-name",
					LogMessageData: { name: d.thread_name }
				};
			case "ThreadImageMessage":
				return {
					Type: "Event",
					MessageID: d.message_id,
					ThreadID: ThreadID,
					Group: messageThread.thread_type === "GROUP",
					SenderID: d.message_sender.id,
					TimeStamp: d.timestamp_precise,
					EventType: "change_thread_image",
					snippet: d.snippet,
					EventData:
						d.image_with_metadata == null
							? {} 
							: {
								threadImage: {
									attachmentID: d.image_with_metadata.legacy_attachment_id,
									width: d.image_with_metadata.original_dimensions.x,
									height: d.image_with_metadata.original_dimensions.y,
									Url: d.image_with_metadata.preview.uri
								}
							},


					LogMessageType: "log:thread-icon",
					LogMessageData: {
						thread_icon: d.image_with_metadata
							? d.image_with_metadata.preview.uri
							: null
					}
				};
			case "ParticipantLeftMessage":
				return {
					Type: "Event",
					MessageID: d.message_id,
					ThreadID: ThreadID,
					Group: messageThread.thread_type === "GROUP",
					SenderID: d.message_sender.id,
					TimeStamp: d.timestamp_precise,
					EventType: "remove_participants",
					snippet: d.snippet,
					EventData: {

						participantsRemoved: d.participants_removed.map(function (p) {
							return p.id;
						})
					},


					LogMessageType: "log:unsubscribe",
					LogMessageData: {
						LeftID: d.participants_removed.map(function (p) {
							return p.id;
						})
					}
				};
			case "ParticipantsAddedMessage":
				return {
					Type: "Event",
					MessageID: d.message_id,
					ThreadID: ThreadID,
					Group: messageThread.thread_type === "GROUP",
					SenderID: d.message_sender.id,
					TimeStamp: d.timestamp_precise,
					EventType: "add_participants",
					snippet: d.snippet,
					EventData: {
						participantsAdded: d.participants_added.map(function (p) {
							return p.id;
						})
					},

					LogMessageType: "log:subscribe",
					LogMessageData: {
						AddedIDs: d.participants_added.map(function (p) {
							return p.id;
						})
					}
				};
			case "VideoCallMessage":
				return {
					Type: "Event",
					MessageID: d.message_id,
					ThreadID: ThreadID,
					Group: messageThread.thread_type === "GROUP",
					SenderID: d.message_sender.id,
					TimeStamp: d.timestamp_precise,
					EventType: "video_call",
					snippet: d.snippet,

					LogMessageType: "other"
				};
			case "VoiceCallMessage":
				return {
					Type: "Event",
					MessageID: d.message_id,
					ThreadID: ThreadID,
					Group: messageThread.thread_type === "GROUP",
					SenderID: d.message_sender.id,
					TimeStamp: d.timestamp_precise,
					EventType: "voice_call",
					snippet: d.snippet,

					// @Legacy
					LogMessageType: "other"
				};
			case "GenericAdminTextMessage":
				return {
					Type: "Event",
					MessageID: d.message_id,
					ThreadID: ThreadID,
					Group: messageThread.thread_type === "GROUP",
					SenderID: d.message_sender.id,
					TimeStamp: d.timestamp_precise,
					snippet: d.snippet,
					EventType: d.extensible_message_admin_text_type.toLowerCase(),
					EventData: formatEventData(d.extensible_message_admin_text),

					LogMessageType: utils.getAdminTextMessageType(
						d.extensible_message_admin_text_type
					),
					LogMessageData: d.extensible_message_admin_text
				};
			default:
				return { error: "Don't know about message type " + d.__typename };
		}
	});
	return messages;
}

module.exports = function (FcaData, Client, Context) {
	return function getThreadHistoryGraphQL(
		ThreadID,
		amount,
		timestamp,
		callback
	) {
		let resolveFunc = function () { };
		let rejectFunc = function () { };
		const returnPromise = new Promise(function (resolve, reject) {
			resolveFunc = resolve;
			rejectFunc = reject;
		});

		if (!callback) {
			callback = function (err, data) {
				if (err) {
					return rejectFunc(err);
				}
				resolveFunc(data);
			};
		}

		const form = {
			"av": Context.GlobalSettings.pageID,
			queries: JSON.stringify({
				o0: {
					doc_id: "1498317363570230",
					query_params: {
						id: ThreadID,
						message_limit: amount,
						load_messages: 1,
						load_read_receipts: false,
						before: timestamp
					}
				}
			})
		};

		FcaData
			.post("https://www.facebook.com/api/graphqlbatch/", Context.jar, form)
			.then(utils.parseAndCheckLogin(Context, FcaData))
			.then(function (resData) {
				if (resData.error) {
					throw resData;
				}
				if (resData[resData.length - 1].error_results !== 0) {
					throw new Error("There was an error_result.");
				}

				callback(null, formatMessagesGraphQLResponse(resData[0]));
			})
			.catch(function (err) {
				return callback(err);
			});

		return returnPromise;
	};
};
