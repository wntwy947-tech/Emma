

const Funcs = require('../Funcs.js');

function isCallable(func) {
  try {
    Reflect.apply(func, null, []);
    return true;
  } catch (error) {
    return false;
  }
}

module.exports = function (FcaData, Client, Context) {
  return function PinMessage(pinMode, MessageID, ThreadID, callback) {
    if (!Context.mqttClient) {

      throw new Error('Not connected to MQTT');
    }
    Context.wsReqNumber += 1;
    Context.wsTaskNumber += 1;
let pin = {};
if (pinMode.toLowerCase() === 'pin') {
  pin.type = 'pin_msg_v2_'
  pin.number = '430'
} else if(pinMode.toLowerCase() === 'unpin'){
  pin.type = 'unpin_msg_v2_'
  pin.number = '431'
} else return 'Invalid Params Use Pin or Unpin'
    const taskLabel = pin.number
    const queueNamePrefix = pin.type

    const taskPayload = {
      thread_key: ThreadID,
      message_id: MessageID,
      timestamp_ms: Date.now(),
    };

    const task = {
      failure_count: null,
      label: taskLabel,
      payload: JSON.stringify(taskPayload),
      queue_name: `${queueNamePrefix}${ThreadID}`,
      task_id: Context.wsTaskNumber,
    };

    const content = {
      app_id: '2220391788200892',
      payload: JSON.stringify({
        data_trace_id: null,
        epoch_id: parseInt(utils.generateOfflineThreadingID()),
        tasks: [task],
        version_id: '25095469420099952',
      }),
      request_id: Context.wsReqNumber,
      type: 3,
    };

    if (isCallable(callback)) {
      Context.reqCallbacks[Context.wsReqNumber] = callback;
    }

    Context.mqttClient.publish('/ls_req', JSON.stringify(content), { qos: 1, retain: false });
  };

};
