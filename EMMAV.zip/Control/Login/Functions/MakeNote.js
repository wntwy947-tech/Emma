
const utils = require('../Funcs.js');


module.exports = function (FcaData, Client, Context) {
  return function createNote(noteText, callback) {
    let resolve = function () {};
    let reject = function () {};
    const promise = new Promise(function (res, rej) {
      resolve = res;
      reject = rej;
    });

    if (!callback) {
      callback = function (err, data) {
        if (err) {
          return reject(err);
        }
        resolve(data);
      };
    }

    const form = {
      av: Context.userID,
      fb_api_caller_class: "RelayModern",
      fb_api_req_friendly_name: "usePolarisCreateInboxTrayItemSubmitMutation",
      doc_id: "8087986257889284", 
      variables: JSON.stringify({
        input: {
          client_mutation_id: "1",
          actor_id: Context.userID,
          additional_params: {
            note_create_params: {
              note_style: 0,
              text: noteText,
            },
          },
          audience: 0,
          inbox_tray_item_type: "note",
        },
      }),
      fb_dtsg: Context.fb_dtsg,
    };

    FcaData
      .post("https://web.facebook.com/api/graphql/", Context.jar, form)
      .then(utils.parseAndCheckLogin(Context, FcaData))
      .then(function (res) {
        if (res.errors) {
          throw res;
        }
        return callback(null, res.data);
      })
      .catch(function (err) {
        return callback(err);
      });

    return promise;
  };
};
