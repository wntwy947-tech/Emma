const utils = require('../Funcs.js');

const { generateOfflineThreadingID } = utils;

function isCallable(func) {
  try {
    Reflect.apply(func, null, []);
    return true;
  } catch (error) {
    return false;
  }
}

module.exports = function (FcaData, Client, Context) {
  return function unsendMessageMqtt(messageID, threadID, callback) {
    if (!Context.mqttClient) {
      throw new Error('Not connected to MQTT');
    }

    Context.wsReqNumber += 1;
    Context.wsTaskNumber += 1;

    const label = '33';

    const taskPayload = {
      message_id: messageID,
      thread_key: threadID,
      sync_group: 1,
    };

    const payload = JSON.stringify(taskPayload);
    const version = '25393437286970779';

    const task = {
      failure_count: null,
      label: label,
      payload: payload,
      queue_name: 'unsend_message',
      task_id: Context.wsTaskNumber,
    };

    const content = {
      app_id: '2220391788200892',
      payload: JSON.stringify({
        tasks: [task],
        epoch_id: parseInt(generateOfflineThreadingID()),
        version_id: version,
      }),
      request_id: Context.wsReqNumber,
      type: 3,
    };

    if (isCallable(callback)) {

    }

    Context.mqttClient.publish('/ls_req', JSON.stringify(content), { qos: 1, retain: false });
  };
};
