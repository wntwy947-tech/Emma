const utils = require('../Funcs.js')
const { generateOfflineThreadingID } = utils;

function isCallable(func) {
	try {
	  Reflect.apply(func, null, []);
	  return true;
	} catch (error) {
	  return false;
	}
  }
  
  module.exports = function (FcaData, Client, Context) {
	return async function GcImage(image, threadKey,  callback) {
		async function handleUpload(image) {
			const form = {
			  images_only: "true",
			  "attachment[]": image,
			};
		  
			try {
			  const resData = await FcaData
				.postFormData(
				  "https://upload.facebook.com/ajax/mercury/upload.php",
				  Context.jar,
				  form,
				  {}
				)
				.then(utils.parseAndCheckLogin(Context, FcaData));
		  
			  if (resData.error) {
				throw resData;
			  }
		  
			  return resData.payload.metadata[0];
			} catch (err) {
			  throw err;
			}
		  }
		  
	  if (!Context.mqttClient) {
		throw new Error("Not connected to MQTT");
	  }
  
	  Context.wsReqNumber += 1;
	  Context.wsTaskNumber += 1;
     const Image = await handleUpload(image)
	  const task = {
		failure_count: null,
		label: "37",
		payload: JSON.stringify({
		  thread_key: threadKey,
		  image_id: Image.image_id,
		  sync_group: 1,
		}),
		queue_name: "thread_image",
		task_id: Context.wsTaskNumber,
	  };
  
	  const content = {
		app_id: "2220391788200892",
		payload: JSON.stringify({
		  tasks: [task],
		  epoch_id:  parseInt(generateOfflineThreadingID()),
		  version_id: "9305733849522974",
		}),
		request_id: Context.wsReqNumber,
		type: 3,
	  };
  
	  if (isCallable(callback)) {
	  }
  
	  Context.mqttClient.publish("/ls_req", JSON.stringify(content), {
		qos: 1,
		retain: false,
	  });
	};
  };
  