const url = require("url");
const stream = require("stream");
const querystring = require("querystring");
const requestx = require("request");

let requestInstance = requestx.defaults({
    jar: true
});

const request = (options) => {
    return new Promise((resolve, reject) => {
        requestInstance(options, (error, response) => {
            if (error) {
                return reject(error);
            }
            resolve(response);
        });
    });
};
request.jar = requestx.jar;

class CustomError extends Error {
    constructor(obj) {
        if (typeof obj === 'string')
            obj = {
                message: obj
            };
        if (typeof obj !== 'object' || obj === null)
            throw new TypeError('Object required');
        obj.message ? super(obj.message) : super();
        Object.assign(this, obj);
    }
}

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

function getCurrentTimestamp() {
    const date = new Date();
    const unixTime = date.getTime();
    return unixTime;
}

function setProxy(proxyUrl) {
    if (typeof proxyUrl == "undefined") {
        requestInstance = requestx.defaults({
            jar: true
        });
    } else {
        requestInstance = requestx.defaults({
            jar: true,
            proxy: proxyUrl
        });
    }
}

function getHeaders(url, options, Context, customHeader) {
    let headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        Referer: "https://www.facebook.com/",
        Host: url.replace("https://", "").split("/")[0],
        Origin: "https://www.facebook.com",
        "user-agent": (options.UserAgent || "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36"),
        Connection: "keep-alive",
        "sec-fetch-site": 'same-origin',
        "sec-fetch-mode": 'cors'
    };
    if (customHeader) Object.assign(headers, customHeader);
    if (Context && Context.region) headers["X-MSGR-Region"] = Context.region;

    return headers;
}

function isReadableStream(obj) {
    return (
        obj instanceof stream.Stream &&
        (getType(obj._read) === "Function" ||
            getType(obj._read) === "AsyncFunction") &&
        getType(obj._readableState) === "Object"
    );
}

async function get(url, jar, qs, options, Context) {
    if (getType(qs) === "Object")
        for (let prop in qs)
            if (qs.hasOwnProperty(prop) && getType(qs[prop]) === "Object") qs[prop] = JSON.stringify(qs[prop]);
    const op = {
        headers: getHeaders(url, options, Context),
        timeout: 60000,
        qs: qs,
        url: url,
        method: "GET",
        jar: jar,
        gzip: true
    };

    return await request(op);
}

async function post(url, jar, form, options, Context, customHeader) {
    const op = {
        headers: getHeaders(url, options, Context, customHeader),
        timeout: 60000,
        url: url,
        method: "POST",
        form: form,
        jar: jar,
        gzip: true
    };
    return await request(op);
}

async function postFormData(url, jar, form, qs, options, Context) {
    let headers = getHeaders(url, options, Context);
    headers["Content-Type"] = "multipart/form-data";
    const op = {
        headers: headers,
        timeout: 60000,
        url: url,
        method: "POST",
        formData: form,
        qs: qs,
        jar: jar,
        gzip: true
    };

    return await request(op);
}

function padZeros(val, len) {
    val = String(val);
    len = len || 2;
    while (val.length < len) val = "0" + val;
    return val;
}

function generateThreadingID(clientID) {
    let k = Date.now();
    let l = Math.floor(Math.random() * 4294967295);
    let m = clientID;
    return "<" + k + ":" + l + "-" + m + "@mail.projektitan.com>";
}

function binaryToDecimal(data) {
    let ret = "";
    while (data !== "0") {
        let end = 0;
        let fullName = "";
        let i = 0;
        for (; i < data.length; i++) {
            end = 2 * end + parseInt(data[i], 10);
            if (end >= 10) {
                fullName += "1";
                end -= 10;
            } else fullName += "0";
        }
        ret = end.toString() + ret;
        data = fullName.slice(fullName.indexOf("1"));
    }
    return ret;
}

function generateOfflineThreadingID() {
    let ret = Date.now();
    let value = Math.floor(Math.random() * 4294967295);
    let str = ("0000000000000000000000" + value.toString(2)).slice(-22);
    let msgs = ret.toString(2) + str;
    return binaryToDecimal(msgs);
}

let h;
let i = {};
let j = {
    _: "%",
    A: "%2",
    B: "000",
    C: "%7d",
    D: "%7b%22",
    E: "%2c%22",
    F: "%22%3a",
    G: "%2c%22ut%22%3a1",
    H: "%2c%22bls%22%3a",
    I: "%2c%22n%22%3a%22%",
    J: "%22%3a%7b%22i%22%3a0%7d",
    K: "%2c%22pt%22%3a0%2c%22vis%22%3a",
    L: "%2c%22ch%22%3a%7b%22h%22%3a%22",
    M: "%7b%22v%22%3a2%2c%22time%22%3a1",
    N: ".channel%22%2c%22sub%22%3a%5b",
    O: "%2c%22sb%22%3a1%2c%22t%22%3a%5b",
    P: "%2c%22ud%22%3a100%2c%22lc%22%3a0",
    Q: "%5d%2c%22f%22%3anull%2c%22uct%22%3a",
    R: ".channel%22%2c%22sub%22%3a%5b1%5d",
    S: "%22%2c%22m%22%3a0%7d%2c%7b%22i%22%3a",
    T: "%2c%22blc%22%3a1%2c%22snd%22%3a1%2c%22ct%22%3a",
    U: "%2c%22blc%22%3a0%2c%22snd%22%3a1%2c%22ct%22%3a",
    V: "%2c%22blc%22%3a0%2c%22snd%22%3a0%2c%22ct%22%3a",
    W: "%2c%22s%22%3a0%2c%22blo%22%3a0%7d%2c%22bl%22%3a%7b%22ac%22%3a",
    X: "%2c%22ri%22%3a0%7d%2c%22state%22%3a%7b%22p%22%3a0%2c%22ut%22%3a1",
    Y: "%2c%22pt%22%3a0%2c%22vis%22%3a1%2c%22bls%22%3a0%2c%22blc%22%3a0%2c%22snd%22%3a1%2c%22ct%22%3a",
    Z: "%2c%22sb%22%3a1%2c%22t%22%3a%5b%5d%2c%22f%22%3anull%2c%22uct%22%3a0%2c%22s%22%3a0%2c%22blo%22%3a0%7d%2c%22bl%22%3a%7b%22ac%22%3a"
};
(function() {
    let l = [];
    for (let m in j) {
        i[j[m]] = m;
        l.push(j[m]);
    }
    l.reverse();
    h = new RegExp(l.join("|"), "g");
})();

function presenceEncode(str) {
    return encodeURIComponent(str)
        .replace(/([_A-Z])|%../g, (m, n) => {
            return n ? "%" + n.charCodeAt(0).toString(16) : m;
        })
        .toLowerCase()
        .replace(h, (m) => {
            return i[m];
        });
}

function presenceDecode(str) {
    return decodeURIComponent(
        str.replace(/[_A-Z]/g, (m) => {
            return j[m];
        })
    );
}

function generatePresence(userID) {
    let time = Date.now();
    return (
        "E" +
        presenceEncode(
            JSON.stringify({
                v: 3,
                time: parseInt(time / 1000, 10),
                user: userID,
                state: {
                    ut: 0,
                    t2: [],
                    lm2: null,
                    uct2: time,
                    tr: null,
                    tw: Math.floor(Math.random() * 4294967295) + 1,
                    at: time
                },
                ch: {
                    ["p_" + userID]: 0
                }
            })
        )
    );
}

function generateAccessiblityCookie() {
    let time = Date.now();
    return encodeURIComponent(
        JSON.stringify({
            sr: 0,
            "sr-ts": time,
            jk: 0,
            "jk-ts": time,
            kb: 0,
            "kb-ts": time,
            hcm: 0,
            "hcm-ts": time
        })
    );
}

function getGUID() {
    let sectionLength = Date.now();
    let id = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
        let r = Math.floor((sectionLength + Math.random() * 16) % 16);
        sectionLength = Math.floor(sectionLength / 16);
        let _guid = (c == "x" ? r : (r & 7) | 8).toString(16);
        return _guid;
    });
    return id;
}

function _formatAttachment(attachment1, attachment2) {
    attachment2 = attachment2 || {
        id: "",
        image_data: {}
    };
    attachment1 = attachment1.mercury ? attachment1.mercury : attachment1;
    let blob = attachment1.blob_attachment;
    let type =
        blob && blob.__typename ? blob.__typename : attachment1.attach_type;
    if (!type && attachment1.sticker_attachment) {
        type = "StickerAttachment";
        blob = attachment1.sticker_attachment;
    } else if (!type && attachment1.extensible_attachment) {
        if (
            attachment1.extensible_attachment.story_attachment &&
            attachment1.extensible_attachment.story_attachment.target &&
            attachment1.extensible_attachment.story_attachment.target.__typename &&
            attachment1.extensible_attachment.story_attachment.target.__typename === "MessageLocation"
        ) type = "MessageLocation";
        else type = "ExtensibleAttachment";

        blob = attachment1.extensible_attachment;
    }
    switch (type) {
        case "sticker":
            return {
                Type: "Sticker",
                ID: attachment1.metadata.stickerID.toString(),
                Url: attachment1.url,
                packID: attachment1.metadata.packID.toString(),
                spriteUrl: attachment1.metadata.spriteURI,
                spriteUrl2x: attachment1.metadata.spriteURI2x,
                width: attachment1.metadata.width,
                height: attachment1.metadata.height,
                caption: attachment2.caption,
                description: attachment2.description,
                frameCount: attachment1.metadata.frameCount,
                frameRate: attachment1.metadata.frameRate,
                framesPerRow: attachment1.metadata.framesPerRow,
                framesPerCol: attachment1.metadata.framesPerCol,
                stickerID: attachment1.metadata.stickerID.toString(),
                spriteURI: attachment1.metadata.spriteURI,
                spriteURI2x: attachment1.metadata.spriteURI2x
            };
        case "file":
            return {
                Type: "File",
                filename: attachment1.name,
                ID: attachment2.id.toString(),
                Url: attachment1.url,
                isMalicious: attachment2.is_malicious,
                contentType: attachment2.mime_type,
                name: attachment1.name,
                mimeType: attachment2.mime_type,
                fileSize: attachment2.file_size
            };
        case "photo":
            return {
                Type: "Photo",
                ID: attachment1.metadata.fbid.toString(),
                filename: attachment1.fileName,
                thumbnailUrl: attachment1.thumbnail_url,
                previewUrl: attachment1.preview_url,
                previewWidth: attachment1.preview_width,
                previewHeight: attachment1.preview_height,
                largePreviewUrl: attachment1.large_preview_url,
                largePreviewWidth: attachment1.large_preview_width,
                largePreviewHeight: attachment1.large_preview_height,
                Url: attachment1.metadata.url,
                width: attachment1.metadata.dimensions.split(",")[0],
                height: attachment1.metadata.dimensions.split(",")[1],
                name: attachment1.fileName
            };
        case "animated_image":
            return {
                Type: "Animated_Image",
                ID: attachment2.id.toString(),
                filename: attachment2.filename,
                previewUrl: attachment1.preview_url,
                previewWidth: attachment1.preview_width,
                previewHeight: attachment1.preview_height,
                Url: attachment2.image_data.url,
                width: attachment2.image_data.width,
                height: attachment2.image_data.height,
                name: attachment1.name,
                facebookUrl: attachment1.url,
                thumbnailUrl: attachment1.thumbnail_url,
                mimeType: attachment2.mime_type,
                rawGifImage: attachment2.image_data.raw_gif_image,
                rawWebpImage: attachment2.image_data.raw_webp_image,
                animatedGifUrl: attachment2.image_data.animated_gif_url,
                animatedGifPreviewUrl: attachment2.image_data.animated_gif_preview_url,
                animatedWebpUrl: attachment2.image_data.animated_webp_url,
                animatedWebpPreviewUrl: attachment2.image_data.animated_webp_preview_url
            };
        case "share":
            return {
                Type: "Share",
                ID: attachment1.share.share_id.toString(),
                Url: attachment2.href,
                title: attachment1.share.title,
                description: attachment1.share.description,
                source: attachment1.share.source,
                image: attachment1.share.media.image,
                width: attachment1.share.media.image_size.width,
                height: attachment1.share.media.image_size.height,
                playable: attachment1.share.media.playable,
                duration: attachment1.share.media.duration,
                SubAttachments: attachment1.share.subattachments,
                properties: {},
                animatedImageSize: attachment1.share.media.animated_image_size,
                facebookUrl: attachment1.share.uri,
                target: attachment1.share.target,
                styleList: attachment1.share.style_list
            };
        case "video":
            return {
                Type: "Video",
                ID: attachment1.metadata.fbid.toString(),
                filename: attachment1.name,
                previewUrl: attachment1.preview_url,
                previewWidth: attachment1.preview_width,
                previewHeight: attachment1.preview_height,
                Url: attachment1.url,
                width: attachment1.metadata.dimensions.width,
                height: attachment1.metadata.dimensions.height,
                duration: attachment1.metadata.duration,
                videoType: "unknown",
                thumbnailUrl: attachment1.thumbnail_url
            };
        case "error":
            return {
                Type: "Error",
                attachment1: attachment1,
                attachment2: attachment2
            };
        case "MessageImage":
            return {
                Type: "Photo",
                ID: blob.legacy_attachment_id,
                filename: blob.filename,
                thumbnailUrl: blob.thumbnail.uri,
                previewUrl: blob.preview.uri,
                previewWidth: blob.preview.width,
                previewHeight: blob.preview.height,
                largePreviewUrl: blob.large_preview.uri,
                largePreviewWidth: blob.large_preview.width,
                largePreviewHeight: blob.large_preview.height,
                Url: blob.large_preview.uri,
                width: blob.original_dimensions.x,
                height: blob.original_dimensions.y,
                name: blob.filename
            };
        case "MessageAnimatedImage":
            return {
                Type: "Animated_Image",
                ID: blob.legacy_attachment_id,
                filename: blob.filename,
                previewUrl: blob.preview_image.uri,
                previewWidth: blob.preview_image.width,
                previewHeight: blob.preview_image.height,
                Url: blob.animated_image.uri,
                width: blob.animated_image.width,
                height: blob.animated_image.height,
                thumbnailUrl: blob.preview_image.uri,
                name: blob.filename,
                facebookUrl: blob.animated_image.uri,
                rawGifImage: blob.animated_image.uri,
                animatedGifUrl: blob.animated_image.uri,
                animatedGifPreviewUrl: blob.preview_image.uri,
                animatedWebpUrl: blob.animated_image.uri,
                animatedWebpPreviewUrl: blob.preview_image.uri
            };
        case "MessageVideo":
            return {
                Type: "Video",
                filename: blob.filename,
                ID: blob.legacy_attachment_id,
                previewUrl: blob.large_image.uri,
                previewWidth: blob.large_image.width,
                previewHeight: blob.large_image.height,
                Url: blob.playable_url,
                width: blob.original_dimensions.x,
                height: blob.original_dimensions.y,
                duration: blob.playable_duration_in_ms,
                videoType: blob.video_type.toLowerCase(),
                thumbnailUrl: blob.large_image.uri
            };
        case "MessageAudio":
            return {
                Type: "Audio",
                filename: blob.filename,
                ID: blob.url_shimhash,
                audioType: blob.audio_type,
                duration: blob.playable_duration_in_ms,
                Url: blob.playable_url,
                isVoiceMail: blob.is_voicemail
            };
        case "StickerAttachment":
            return {
                Type: "Sticker",
                ID: blob.id,
                Url: blob.url,
                packID: blob.pack ? blob.pack.id : null,
                spriteUrl: blob.sprite_image,
                spriteUrl2x: blob.sprite_image_2x,
                width: blob.width,
                height: blob.height,
                caption: blob.label,
                description: blob.label,
                frameCount: blob.frame_count,
                frameRate: blob.frame_rate,
                framesPerRow: blob.frames_per_row,
                framesPerCol: blob.frames_per_column,
                stickerID: blob.id,
                spriteURI: blob.sprite_image,
                spriteURI2x: blob.sprite_image_2x
            };
        case "MessageLocation":
            let urlAttach = blob.story_attachment.url;
            let mediaAttach = blob.story_attachment.media;

            let u = querystring.parse(url.parse(urlAttach).query).u;
            let where1 = querystring.parse(url.parse(u).query).where1;
            let address = where1.split(", ");

            let latitude;
            let longitude;

            try {
                latitude = Number.parseFloat(address[0]);
                longitude = Number.parseFloat(address[1]);
            } catch (err) {
                /* empty */
            }

            let imageUrl;
            let width;
            let height;

            if (mediaAttach && mediaAttach.image) {
                imageUrl = mediaAttach.image.uri;
                width = mediaAttach.image.width;
                height = mediaAttach.image.height;
            }

            return {
                Type: "Location",
                ID: blob.legacy_attachment_id,
                latitude: latitude,
                longitude: longitude,
                image: imageUrl,
                width: width,
                height: height,
                Url: u || urlAttach,
                address: where1,
                facebookUrl: blob.story_attachment.url,
                target: blob.story_attachment.target,
                styleList: blob.story_attachment.style_list
            };
        case "ExtensibleAttachment":
            return {
                Type: "Share",
                ID: blob.legacy_attachment_id,
                Url: blob.story_attachment.url,
                title: blob.story_attachment.title_with_entities.text,
                description: blob.story_attachment.description &&
                    blob.story_attachment.description.text,
                source: blob.story_attachment.source ? blob.story_attachment.source.text : null,
                image: blob.story_attachment.media &&
                    blob.story_attachment.media.image &&
                    blob.story_attachment.media.image.uri,
                width: blob.story_attachment.media &&
                    blob.story_attachment.media.image &&
                    blob.story_attachment.media.image.width,
                height: blob.story_attachment.media &&
                    blob.story_attachment.media.image &&
                    blob.story_attachment.media.image.height,
                playable: blob.story_attachment.media &&
                    blob.story_attachment.media.is_playable,
                duration: blob.story_attachment.media &&
                    blob.story_attachment.media.playable_duration_in_ms,
                playableUrl: blob.story_attachment.media == null ? null : blob.story_attachment.media.playable_url,
                SubAttachments: blob.story_attachment.subattachments,
                properties: blob.story_attachment.properties.reduce(function(obj, cur) {
                    obj[cur.key] = cur.value.text;
                    return obj;
                }, {}),
                facebookUrl: blob.story_attachment.url,
                target: blob.story_attachment.target,
                styleList: blob.story_attachment.style_list
            };
        case "MessageFile":
            return {
                Type: "File",
                filename: blob.filename,
                ID: blob.message_file_fbid,
                Url: blob.url,
                isMalicious: blob.is_malicious,
                contentType: blob.content_type,
                name: blob.filename,
                mimeType: "",
                fileSize: -1
            };
        default:
            throw new Error(
                "unrecognized attach_file of type " +
                type +
                "`" +
                JSON.stringify(attachment1, null, 4) +
                " attachment2: " +
                JSON.stringify(attachment2, null, 4) +
                "`"
            );
    }
}

function formatAttachment(attachments, attachmentIds, attachmentMap, shareMap) {
    attachmentMap = shareMap || attachmentMap;
    return attachments ?
        attachments.map((val, i) => {
            if (!attachmentMap ||
                !attachmentIds ||
                !attachmentMap[attachmentIds[i]]
            ) {
                return _formatAttachment(val);
            }
            return _formatAttachment(val, attachmentMap[attachmentIds[i]]);
        }) : [];
}

function formatDeltaMessage(m) {
    const md = m.delta.messageMetadata;

    const mdata =
        m.delta.data === undefined ?
        [] :
        m.delta.data.prng === undefined ?
        [] :
        JSON.parse(m.delta.data.prng);
    const m_id = mdata.map(u => u.i);
    const m_offset = mdata.map(u => u.o);
    const m_length = mdata.map(u => u.l);
    const Mentions = {};
    for (let i = 0; i < m_id.length; i++) {
        Mentions[m_id[i]] = m.delta.body.substring(
            m_offset[i],
            m_offset[i] + m_length[i]
        );
    }
    return {
        Type: "Message",
        SenderID: formatID(md.actorFbId.toString()),
        Body: m.delta.body || "",
        ThreadID: formatID(
            (md.threadKey.threadFbId || md.threadKey.otherUserFbId).toString()
        ),
        MessageID: md.messageId,
        Attachments: (m.delta.attachments || []).map(v => _formatAttachment(v)),
        Mentions: Mentions,
        TimeStamp: md.timestamp,
        Group: !!md.threadKey.threadFbId,
        ParticipantIDs: m.delta.participants || (md.cid ? md.cid.canonicalParticipantFbids : []) || []
    };
}

function formatID(id) {
    if (id != undefined && id != null) return id.replace(/(fb)?id[:.]/, "");
    else return id;
}

function formatMessage(m) {
    const originalMessage = m.message ? m.message : m;
    const obj = {
        Type: "Message",
        senderName: originalMessage.sender_name,
        SenderID: formatID(originalMessage.sender_fbid.toString()),
        participantNames: originalMessage.group_thread_info ?
            originalMessage.group_thread_info.participant_names :
            [originalMessage.sender_name.split(" ")[0]],
        ParticipantIDs: originalMessage.group_thread_info ?
            originalMessage.group_thread_info.participant_ids.map((v) => {
                return formatID(v.toString());
            }) :
            [formatID(originalMessage.sender_fbid)],
        Body: originalMessage.body || "",
        ThreadID: formatID(
            (
                originalMessage.thread_fbid || originalMessage.other_user_fbid
            ).toString()
        ),
        threadName: originalMessage.group_thread_info ?
            originalMessage.group_thread_info.name :
            originalMessage.sender_name,
        location: originalMessage.coordinates ? originalMessage.coordinates : null,
        MessageID: originalMessage.mid ?
            originalMessage.mid.toString() :
            originalMessage.message_id,
        Attachments: formatAttachment(
            originalMessage.attachments,
            originalMessage.attachmentIds,
            originalMessage.attachment_map,
            originalMessage.share_map
        ),
        TimeStamp: originalMessage.timestamp,
        timestampAbsolute: originalMessage.timestamp_absolute,
        timestampRelative: originalMessage.timestamp_relative,
        timestampDatetime: originalMessage.timestamp_datetime,
        tags: originalMessage.tags,
        reactions: originalMessage.reactions ? originalMessage.reactions : [],
        isUnread: originalMessage.is_unread
    };

    if (m.type === "pages_messaging")
        obj.pageID = m.realtime_viewer_fbid.toString();
    obj.Group = obj.ParticipantIDs.length > 2;

    return obj;
}

function formatHistoryMessage(m) {
    switch (m.action_type) {
        case "ma-type:log-message":
            return formatEvent(m);
        default:
            return formatMessage(m);
    }
}

function formatEvent(m) {
    const originalMessage = m.message ? m.message : m;
    let LogMessageType = originalMessage.log_message_type;
    let LogMessageData;
    if (LogMessageType === "log:generic-admin-text") {
        LogMessageData = originalMessage.log_message_data.untypedData;
        LogMessageType = getAdminTextMessageType(
            originalMessage.log_message_data.message_type
        );
    } else {
        LogMessageData = originalMessage.log_message_data;
    }

    return Object.assign(formatMessage(originalMessage), {
        Type: "Event",
        LogMessageType: LogMessageType,
        LogMessageData: LogMessageData,
        LogMessageBody: originalMessage.log_message_body
    });
}

function getAdminTextMessageType(type) {
    switch (type) {
        case "change_thread_theme":
            return "log:thread-color";
        case "change_thread_icon":
        case "change_thread_quick_reaction":
            return "log:thread-icon";
        case "change_thread_nickname":
            return "log:user-nickname";
        case "change_thread_admins":
            return "log:thread-admins";
        case "group_poll":
            return "log:thread-poll";
        case "change_thread_approval_mode":
            return "log:thread-approval-mode";
        case "messenger_call_log":
        case "participant_joined_group_call":
            return "log:thread-call";
        default:
            return type;
    }
}

function formatDeltaEvent(m) {
    let LogMessageType;
    let LogMessageData;

    switch (m.class) {
        case "AdminTextMessage":
            LogMessageData = m.untypedData;
            LogMessageType = getAdminTextMessageType(m.type);
            break;
        case "ThreadName":
            LogMessageType = "log:thread-name";
            LogMessageData = {
                name: m.name
            };
            break;
        case "ParticipantsAddedToGroupThread":
            LogMessageType = "log:subscribe";
            LogMessageData = {
                AddedIDs: m.addedParticipants
            };
            break;
        case "ParticipantLeftGroupThread":
            LogMessageType = "log:unsubscribe";
            LogMessageData = {
                LeftID: m.leftParticipantFbId
            };
            break;
        case "ApprovalQueue":
            LogMessageType = "log:approval-queue";
            LogMessageData = {
                approvalQueue: {
                    action: m.action,
                    recipientFbId: m.recipientFbId,
                    requestSource: m.requestSource,
                    ...m.messageMetadata
                }
            };
    }

    return {
        Type: "Event",
        ThreadID: formatID(
            (
                m.messageMetadata.threadKey.threadFbId ||
                m.messageMetadata.threadKey.otherUserFbId
            ).toString()
        ),
        MessageID: m.messageMetadata.messageId.toString(),
        LogMessageType: LogMessageType,
        LogMessageData: LogMessageData,
        LogMessageBody: m.messageMetadata.adminText,
        TimeStamp: m.messageMetadata.timestamp,
        Author: m.messageMetadata.actorFbId,
        ParticipantIDs: (m.participants || []).map(p => p.toString())
    };
}

function formatTyp(Event) {
    return {
        Typing: !!Event.st,
        from: Event.from.toString(),
        ThreadID: formatID(
            (Event.to || Event.thread_fbid || Event.from).toString()
        ),
        fromMobile: Event.hasOwnProperty("from_mobile") ? Event.from_mobile : true,
        UserID: (Event.realtime_viewer_fbid || Event.from).toString(),
        Type: "Typ"
    };
}

function formatDeltaReadReceipt(delta) {
    return {
        Reader: (delta.threadKey.otherUserFbId || delta.actorFbId).toString(),
        Time: delta.actionTimestampMs,
        ThreadID: formatID((delta.threadKey.otherUserFbId || delta.threadKey.threadFbId).toString()),
        Type: "Read_Receipt"
    };
}

function formatReadReceipt(Event) {
    return {
        Reader: Event.reader.toString(),
        Time: Event.time,
        ThreadID: formatID((Event.thread_fbid || Event.reader).toString()),
        Type: "Read_Receipt"
    };
}

function formatRead(Event) {
    return {
        ThreadID: formatID(((Event.chat_ids && Event.chat_ids[0]) || (Event.thread_fbids && Event.thread_fbids[0])).toString()),
        Time: Event.timestamp,
        Type: "Read"
    };
}

function getFrom(str, startToken, endToken) {
    let start = str.indexOf(startToken) + startToken.length;
    if (start < startToken.length) return "";
    let lastHalf = str.substring(start);
    let end = lastHalf.indexOf(endToken);
    if (end === -1) throw Error("Could not find endTime " + endToken + " in the given string.");
    return lastHalf.substring(0, end);
}

function getFroms(str, startToken, endToken) {
    let results = [];
    let currentIndex = 0;

    while (true) {
        let start = str.indexOf(startToken, currentIndex);
        if (start === -1) break;

        start += startToken.length;

        let lastHalf = str.substring(start);
        let end = lastHalf.indexOf(endToken);

        if (end === -1) {
            if (results.length === 0) {
                throw Error("Could not find endToken `" + endToken + "` in the given string.");
            }
            break;
        }

        results.push(lastHalf.substring(0, end));
        currentIndex = start + end + endToken.length;
    }

    return results.length === 0 ? "" : results.length === 1 ? results[0] : results;
}

function makeParsable(html) {
    const withoutForLoop = html.replace(/for\s*\(\s*;\s*;\s*\)\s*;\s*/, "");
    const maybeMultipleObjects = withoutForLoop.split(/\}\r\n *\{/);
    if (maybeMultipleObjects.length === 1) return maybeMultipleObjects;
    return "[" + maybeMultipleObjects.join("},{") + "]";
}

function arrToForm(form) {
    return arrayToObject(form,
        (v) => {
            return v.name;
        },
        (v) => {
            return v.val;
        }
    );
}

function arrayToObject(arr, getKey, getValue) {
    return arr.reduce((acc, val) => {
        acc[getKey(val)] = getValue(val);
        return acc;
    }, {});
}

function getSignatureID() {
    return Math.floor(Math.random() * 2147483648).toString(16);
}

function generateTimestampRelative() {
    let d = new Date();
    return d.getHours() + ":" + padZeros(d.getMinutes());
}

function makeDefaults(html, userID, Context) {
    let reqCounter = 1;
    const fb_dtsg = getFrom(html, 'name="fb_dtsg" value="', '"');

    let ttstamp = "2";
    for (let i = 0; i < fb_dtsg.length; i++) {
        ttstamp += fb_dtsg.charCodeAt(i);
    }
    const revision = getFrom(html, 'revision":', ",");

    const mergeWithDefaults = (obj) => {
        const newObj = {
            __user: userID,
            __req: (reqCounter++).toString(36),
            __rev: revision,
            __a: 1,
            fb_dtsg: Context.fb_dtsg ? Context.fb_dtsg : fb_dtsg,
            jazoest: Context.ttstamp ? Context.ttstamp : ttstamp
        };

        if (!obj) return newObj;
        for (let prop in obj) {
            if (obj.hasOwnProperty(prop)) {
                if (!newObj[prop]) newObj[prop] = obj[prop];
            }
        }
        return newObj;
    };

    return {
        get: async (url, jar, qs, Contextx) => await get(url, jar, mergeWithDefaults(qs), Context.GlobalSettings, Contextx || Context),
        post: async (url, jar, form, Contextx) => await post(url, jar, mergeWithDefaults(form), Context.GlobalSettings, Contextx || Context),
        postFormData: async (url, jar, form, qs, Contextx) => await postFormData(url, jar, mergeWithDefaults(form), mergeWithDefaults(qs), Context.GlobalSettings, Contextx || Context)
    };
}
async function AutoNoti(Context, FcaData) { 
    const Sleep = (ms) => new Promise(r => setTimeout(r, ms));
  
    if (!Context || !Context.jar) {
      throw new Error("Missing Context.jar");
    }
    if (!FcaData || typeof FcaData.post !== "function") {
      throw new Error("Missing FcaData.post");
    }
  
    const status  = await CheckLive(Context, FcaData);
    if (!status) {
      throw new Error("Account appears offline/not live (CheckLive returned false).");
    }
  
   
    const uidCookie =
      appState.find(i => i.key === "c_user") ||
      appState.find(i => i.key === "i_user");
  
    if (!uidCookie) {
      throw new Error("Could not find c_user or i_user in appState cookies.");
    }
    const uid = uidCookie.value;
  
    await Sleep(5000);
  
    const form = {
      av: uid,
      fb_api_caller_class: "RelayModern",
      fb_api_req_friendly_name: "FBScrapingWarningMutation",
      variables: "{}",
      server_timestamps: "true",
      doc_id: "6339492849481770",
    };
  
    const bypassResRaw = await FcaData.post(
      "https://www.facebook.com/api/graphql/",
      Context.jar,
      form
    );
  
    let parsed;
    try {
      parsed = typeof bypassResRaw.body === "string"
        ? JSON.parse(bypassResRaw.body)
        : bypassResRaw.body;
    } catch (parseErr) {
       return { success: false };
    }
  
    if (parsed?.data?.fb_scraping_warning_clear?.success) {
      return { success: true, uid, parsed, raw: bypassResRaw };
    } else {
      return { success: false };
    }
  }

  

function parseAndCheckLogin(Context, FcaData, Retries = 0) {
let retryCount = 0;
  return async function handleResponse(data) {
    const { statusCode, body, request } = data;

    if (statusCode >= 500 && statusCode < 600) {
      if (retryCount >= Retries) {
        throw new Error(
          `Request retry failed after ${Retries} attempts (status ${statusCode})`
        );
      }

      await delay(Math.floor(Math.random() * 5000));

      const url =
        request.uri.protocol +
        "//" +
        request.uri.hostname +
        request.uri.pathname;

      const isMultipart =
        request.headers?.["Content-Type"]
          ?.split(";")[0] === "multipart/form-data";

      const response = isMultipart
        ? await FcaData.postFormData(url, Context.jar, request.formData, {})
        : await FcaData.post(url, Context.jar, request.formData);

      return parseAndCheckLogin(Context, FcaData, retryCount + 1)(response);
    }
    if (statusCode !== 200) {
      if (statusCode === 408) return;
      throw new Error(`Unexpected status code: ${statusCode}`);
    }

    let res;
    try {
      res = JSON.parse(makeParsable(body));
    } catch (err) {
      const error = new Error("Failed to parse response JSON");
      error.detail = err;
      error.responseBody = body;
      throw error;
    }
    if (res.redirect && request.method === "GET") {
      const redirectData = await FcaData.get(res.redirect, Context.jar);
      return parseAndCheckLogin(Context, FcaData)(redirectData);
    }
    const cookieMod = res?.jsmods?.require?.[0];
    if (
      Array.isArray(cookieMod) &&
      cookieMod[0] === "Cookie"
    ) {
      cookieMod[3][0] = cookieMod[3][0].replace("_js_", "");

      Context.jar.setCookie(
        formatCookie(cookieMod[3], "facebook"),
        "https://www.facebook.com"
      );
      Context.jar.setCookie(
        formatCookie(cookieMod[3], "messenger"),
        "https://www.facebook.com"
      );
    }
    if (Array.isArray(res?.jsmods?.require)) {
      for (const mod of res.jsmods.require) {
        if (mod[0] === "DTSG" && mod[1] === "setToken") {
          Context.fb_dtsg = mod[3][0];
          Context.ttstamp =
            "2" +
            [...Context.fb_dtsg]
              .map((c) => c.charCodeAt(0))
              .join("");
          break;
        }
      }
    }
    if (res?.error === 1357001) {
      const href = res?.request?.uri?.href || "";

      if (href.includes("https://www.facebook.com/checkpoint/")) {
        if (href.includes("601051028565049")) {
          try {
            const auto = await AutoNoti(Context, FcaData);
            if (auto?.success) {
              return parseAndCheckLogin(Context, FcaData);
            }
          } catch (err) {
            throw new Error(`AutoNoti failed: ${err.message || err}`);
          }
        }

        throw new Error("Checkpoint detected during login");
      }

      throw new Error("Login parsing error");
    }

    return res;
  };
}


function saveCookies(jar) {
    return function(res) {
        let cookies = res.headers["set-cookie"] || [];
        cookies.forEach(function(c) {
            if (c.indexOf(".facebook.com") > -1) {
                jar.setCookie(c, "https://www.facebook.com");
                jar.setCookie(c.replace(/domain=\.facebook\.com/, "domain=.facebook.com"), "https://www.facebook.com");
            }
        });
        return res;
    };
}

const NUM_TO_MONTH = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const NUM_TO_DAY = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function formatDate(date) {
    let d = date.getUTCDate();
    d = d >= 10 ? d : "0" + d;
    let h = date.getUTCHours();
    h = h >= 10 ? h : "0" + h;
    let m = date.getUTCMinutes();
    m = m >= 10 ? m : "0" + m;
    let s = date.getUTCSeconds();
    s = s >= 10 ? s : "0" + s;
    return (NUM_TO_DAY[date.getUTCDay()] + ", " + d + " " + NUM_TO_MONTH[date.getUTCMonth()] + " " + date.getUTCFullYear() + " " + h + ":" + m + ":" + s + " GMT");
}

function formatCookie(arr, url) {
    return arr[0] + "=" + arr[1] + "; Path=" + arr[3] + "; Domain=" + url + ".com";
}

function formatThread(data) {
    return {
        ThreadID: formatID(data.thread_fbid.toString()),
        participants: data.participants.map(formatID),
        ParticipantIDs: data.participants.map(formatID),
        name: data.name,
        nicknames: data.custom_nickname,
        snippet: data.snippet,
        snippetAttachments: data.snippet_attachments,
        snippetSender: formatID((data.snippet_sender || "").toString()),
        unreadCount: data.unread_count,
        messageCount: data.message_count,
        imageSrc: data.image_src,
        TimeStamp: data.timestamp,
        muteUntil: data.mute_until,
        isCanonicalUser: data.is_canonical_user,
        isCanonical: data.is_canonical,
        isSubscribed: data.is_subscribed,
        folder: data.folder,
        isArchived: data.is_archived,
        recipientsLoadable: data.recipients_loadable,
        hasEmailParticipant: data.has_email_participant,
        readOnly: data.read_only,
        canReply: data.can_reply,
        cannotReplyReason: data.cannot_reply_reason,
        lastMessageTimestamp: data.last_message_timestamp,
        lastReadTimestamp: data.last_read_timestamp,
        lastMessageType: data.last_message_type,
        emoji: data.custom_like_icon,
        color: data.custom_color,
        adminIDs: data.admin_ids,
        threadType: data.thread_type
    };
}

function getType(obj) {
    return Object.prototype.toString.call(obj).slice(8, -1);
}

function formatProxyPresence(presence, userID) {
    if (presence.lat === undefined || presence.p === undefined) return null;
    return {
        Type: "Presence",
        TimeStamp: presence.lat * 1000,
        UserID: userID || '',
        Statuses: presence.p
    };
}

function formatPresence(presence, userID) {
    return {
        Type: "Presence",
        TimeStamp: presence.la * 1000,
        UserID: userID || '',
        Statuses: presence.a
    };
}

function decodeClientPayload(payload) {
    function Utf8ArrayToStr(array) {
        let out, i, len, c;
        let char2, char3;
        out = "";
        len = array.length;
        i = 0;
        while (i < len) {
            c = array[i++];
            switch (c >> 4) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                    out += String.fromCharCode(c);
                    break;
                case 12:
                case 13:
                    char2 = array[i++];
                    out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F));
                    break;
                case 14:
                    char2 = array[i++];
                    char3 = array[i++];
                    out += String.fromCharCode(((c & 0x0F) << 12) | ((char2 & 0x3F) << 6) | ((char3 & 0x3F) << 0));
                    break;
            }
        }
        return out;
    }
    return JSON.parse(Utf8ArrayToStr(payload));
}

function getAppState(jar) {
    return jar.getCookies("https://www.facebook.com").concat(jar.getCookies("https://facebook.com")).concat(jar.getCookies("https://www.facebook.com"));
}

function setData_Path(obj, path, value) {
    if (!path.length) {
        return obj;
    }
    const currentKey = path[0];
    let currentObj = obj[currentKey];

    if (!currentObj) {
        obj[currentKey] = value;
        currentObj = obj[currentKey];
    }
    path.shift();
    if (!path.length) {
        currentObj = value;
    } else {
        currentObj = setData_Path(currentObj, path, value);
    }

    return obj;
}

function getPaths(obj, parentPath = []) {
    let paths = [];
    for (let prop in obj) {
        if (typeof obj[prop] === "object") {
            paths = paths.concat(getPaths(obj[prop], [...parentPath, prop]));
        } else {
            paths.push([...parentPath, prop]);
        }
    }
    return paths;
}

function cleanHTML(text) {
    text = text.replace(/(<br>)|(<\/?i>)|(<\/?em>)|(<\/?b>)|(!?~)|(&amp;)|(&#039;)|(&lt;)|(&gt;)|(&quot;)/g, (match) => {
        switch (match) {
            case "<br>":
                return "\n";
            case "<i>":
            case "<em>":
            case "</i>":
            case "</em>":
                return "*";
            case "<b>":
            case "</b>":
                return "**";
            case "~!":
            case "!~":
                return "||";
            case "&amp;":
                return "&";
            case "&#039;":
                return "'";
            case "&lt;":
                return "<";
            case "&gt;":
                return ">";
            case "&quot;":
                return '"';
        }
    });
    return text;
}

async function CheckLive(Context, FcaData) {
	try {
		const res = await FcaData.get("https://m.facebook.com/me", Context.jar);
		const body = res.body.trim();
		const cleanBody = body.startsWith("for (;;);") ? body.slice(9) : body;
		let data;
		try {
			data = JSON.parse(cleanBody);
		} catch {
			data = null;
		}
		if (
			(data && data.error === 1357001) ||
			body.includes("Log in to continue") ||
			body.includes("Please log in to your account.") || 
            body.toLowerCase().includes("log in")
		) {
			return false;
		}
		return true;
	} catch {
		return false;
	}
}


module.exports = {
    CustomError,
    cleanHTML,
    isReadableStream: isReadableStream,
    get: get,
    post: post,
    postFormData: postFormData,
    generateThreadingID: generateThreadingID,
    generateOfflineThreadingID: generateOfflineThreadingID,
    getGUID: getGUID,
    getFrom: getFrom,
    makeParsable: makeParsable,
    arrToForm: arrToForm,
    getSignatureID: getSignatureID,
    getJar: request.jar,
    generateTimestampRelative: generateTimestampRelative,
    makeDefaults: makeDefaults,
    parseAndCheckLogin: parseAndCheckLogin,
    setData_Path,
    getPaths,
    saveCookies,
    getType,
    _formatAttachment,
    formatHistoryMessage,
    formatID,
    formatMessage,
    formatDeltaEvent,
    formatDeltaMessage,
    formatProxyPresence,
    formatPresence,
    formatTyp,
    formatDeltaReadReceipt,
    formatCookie,
    formatThread,
    formatReadReceipt,
    formatRead,
    generatePresence,
    generateAccessiblityCookie,
    formatDate,
    decodeClientPayload,
    getAppState,
    getAdminTextMessageType,
    setProxy,
    getCurrentTimestamp,
    getFroms,
    CheckLive
};

