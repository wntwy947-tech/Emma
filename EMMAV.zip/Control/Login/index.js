const utils = require('./Funcs');
const { logger } = require('./Log');
const cron = require('node-cron');
const fs = require('fs');
const Config = require('../../Config/Settings.json');
const path = require('path');
const axios = require('axios');
let GlobalSettings = {};

class Facebook {
  constructor() {
    this.isBehavior = false;
    this.Ua = "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36";
    this.Cookie = '';
  }

  async SetOptions(FcaSettings, options = {}) {
    Object.keys(options).map((key) => {
      switch (key) {
        case 'online':
          FcaSettings.online = Boolean(options.online);
          break;
        case 'SelfListen':
          FcaSettings.SelfListen = Boolean(options.SelfListen);
          break;
        case 'SelfListenEvent':
          FcaSettings.SelfListenEvent = options.SelfListenEvent;
          break;
        case 'ListenEvents':
          FcaSettings.ListenEvents = Boolean(options.ListenEvents);
          break;
        case 'pageID':
          FcaSettings.pageID = options.pageID.toString();
          break;
        case 'updatePresence':
          FcaSettings.updatePresence = Boolean(options.updatePresence);
          break;
        case 'ForceLogin':
          FcaSettings.ForceLogin = Boolean(options.ForceLogin);
          break;
        case 'UserAgent':
          FcaSettings.UserAgent = options.UserAgent;
          break;
        case 'Delivered':
          FcaSettings.Delivered = Boolean(options.Delivered);
          break;
        case 'MarkSeen':
          FcaSettings.MarkSeen = Boolean(options.MarkSeen);
          break;
        case 'listenTyping':
          FcaSettings.listenTyping = Boolean(options.listenTyping);
          break;
        case 'proxy':
          if (typeof options.proxy != "string") {
            delete FcaSettings.proxy;
            utils.setProxy();
          } else {
            FcaSettings.proxy = options.proxy;
            utils.setProxy(FcaSettings.proxy);
          }
          break;
        case 'AutoReconnect':
          FcaSettings.AutoReconnect = Boolean(options.AutoReconnect);
          break;
        case 'emitReady':
          FcaSettings.emitReady = Boolean(options.emitReady);
          break;
        case 'RandomUserAgent':
          FcaSettings.RandomUserAgent = Boolean(options.RandomUserAgent);
          if (FcaSettings.RandomUserAgent) {
            FcaSettings.UserAgent = utils.RandomUserAgent();
          }
          break;
        case 'BypassRegion':
          FcaSettings.BypassRegion = options.BypassRegion;
          break;
        case 'Delay':
          FcaSettings.Delay = options.Delay;
          break;
        default:
          break;
      }
    });

    GlobalSettings = FcaSettings;
  }

  async RefreshStatus(res, appstate, userId) {
    try {
      const appstateCUser = (appstate.find(i => i.key == 'i_user') || appstate.find(i => i.key == 'c_user'));
      const UID = userId || appstateCUser.value;

      if (!res || !res.body) {
        throw new Error("Invalid response: Response body is missing.");
      }

      const fb_dtsg = utils.getFrom(res.body, '["DTSGInitData",[],{"token":"', '","');
      const jazoest = utils.getFrom(res.body, 'jazoest=', '",');

      if (fb_dtsg && jazoest) {
        const filePath = 'Control/Login/Functions/Dtsg.json';
        let existingData = {};

        if (fs.existsSync(filePath)) {
          const fileContent = fs.readFileSync(filePath, 'utf8');
          existingData = JSON.parse(fileContent);
        }

        existingData[UID] = {
          fb_dtsg,
          jazoest
        };

        fs.writeFileSync(filePath, JSON.stringify(existingData, null, 2), 'utf8');
      }

      return res;
    } catch (error) {
      throw error;
    }
  }

  async AutoBehavior(resp, jar, appstate, ID) {
    try {
      const appstateCUser =
        appstate.find(i => i.key === "c_user") ||
        appstate.find(i => i.key === "i_user");

      if (!appstateCUser && !ID) {
        throw new Error("No valid user ID found in appstate or provided ID");
      }

      const UID = ID || appstateCUser.value;

      const baseForm = {
        av: UID,
        fb_api_caller_class: "RelayModern",
        fb_api_req_friendly_name: "FBScrapingWarningMutation",
        variables: JSON.stringify({}),
        server_timestamps: true,
        doc_id: "6339492849481770",
      };

      const extractTokens = (body) => {
        const fb_dtsg = utils.getFrom(body, '["DTSGInitData",[],{"token":"', '","');
        const jazoest = utils.getFrom(body, "jazoest=", '",');
        const lsd = utils.getFrom(body, '["LSD",[],{"token":"', '"}');

        if (!fb_dtsg || !jazoest || !lsd) {
          throw new Error("Missing required tokens for bypass");
        }

        return { fb_dtsg, jazoest, lsd };
      };

      const handleAutoBehavior = () => {
        logger("Auto Behavior Detected.");
        if (!this.isBehavior) this.isBehavior = true;
      };

      if (!resp) {
        const res = await utils.get("https://www.facebook.com/", jar, null, GlobalSettings);
        const href = res.request?.uri?.href || "";

        if (!href.includes("https://www.facebook.com/checkpoint/")) {
          return { Status: false, Body: res.body };
        }

        if (!href.includes("601051028565049")) {
          return { Status: false, Body: res.body };
        }

        const tokens = extractTokens(res.body);
        const payload = { ...baseForm, ...tokens };
        const bypassRes = await utils.post("https://www.facebook.com/api/graphql/", jar, payload, GlobalSettings);

        await utils.saveCookies(jar);
        handleAutoBehavior();

        return bypassRes;
      }

      const href = resp.request?.uri?.href || "";

      if (!href.includes("https://www.facebook.com/checkpoint/")) {
        return resp;
      }

      if (!href.includes("601051028565049")) {
        return resp;
      }

      const tokens = extractTokens(resp.body);
      const payload = { ...baseForm, ...tokens };
      const postRes = await utils.post("https://www.facebook.com/api/graphql/", jar, payload, GlobalSettings);

      await utils.saveCookies(jar);
      handleAutoBehavior();

      return postRes;
    } catch (err) {
      throw err;
    }
  }

  async Suspension(resp, appstate) {
    try {
      const appstateCUser = (appstate.find(i => i.key == 'c_user') || appstate.find(i => i.key == 'i_user'));
      const UID = appstateCUser?.value;
      const suspendReasons = {};

      if (resp) {
        if (resp.request.uri && resp.request.uri.href.includes("https://www.facebook.com/checkpoint/")) {
          if (resp.request.uri.href.includes('1501092823525282')) {
            const daystoDisable = resp.body?.match(/"log_out_uri":"(.*?)","title":"(.*?)"/);

            if (daystoDisable && daystoDisable[2]) {
              suspendReasons.durationInfo = daystoDisable[2];
              logger([
                {
                  message: `Suspension time remaining: ${suspendReasons.durationInfo}`,
                  color: Config.Color
                }
              ]);
            }

            const reasonDescription = resp.body?.match(/"reason_section_body":"(.*?)"/);

            if (reasonDescription && reasonDescription[1]) {
              suspendReasons.longReason = reasonDescription?.[1];
              const reasonReplace = suspendReasons?.longReason?.toLowerCase()?.replace("your account, or activity on it, doesn't follow our community standards on ", "");
              suspendReasons.shortReason = reasonReplace?.substring(0, 1).toUpperCase() + reasonReplace?.substring(1);

              logger(`Alert on ${UID}: Account has been suspended! Because ${suspendReasons.longReason} Reason ${suspendReasons.shortReason}`);
            }

            Context = null;
            return {
              suspended: true,
              suspendReasons
            };
          }
        } else return;
      }
    } catch (error) {
      return;
    }
  }

  async CheckLocked(resp, appstate) {
    try {
      const appstateCUser = (appstate.find(i => i.key == 'c_user') || appstate.find(i => i.key == 'i_user'));
      const UID = appstateCUser?.value;
      const lockedReasons = {};

      if (resp) {
        if (resp.request.uri && resp.request.uri.href.includes("https://www.facebook.com/checkpoint/")) {
          if (resp.request.uri.href.includes('828281030927956')) {
            const lockDesc = resp.body.match(/"is_unvetted_flow":true,"title":"(.*?)"/);

            if (lockDesc && lockDesc[1]) {
              lockedReasons.reason = lockDesc[1];
              logger([
                {
                  message: `Alert on ${UID}: Account has been Locked! Because ${lockedReasons.reason}`,
                  color: Config.Color
                }
              ]);
            }

            Context = null;
            return {
              locked: true,
              lockedReasons
            };
          }
        } else return;
      }
    } catch (error) {
      throw error;
    }
  }

  async MakeLogin(html, jar, AppState) {
    let fb_dtsg;
    let userID;
    let region;

    const tokenMatch = html.match(/DTSGInitialData.*?token":"(.*?)"/);
    fb_dtsg = tokenMatch?.[1] ?? null;

    const getCookieByName = (cookies, name) =>
      cookies.find(c => c.cookieString().startsWith(name + "="));

    const parseUserID = (cookie) =>
      cookie?.cookieString().split("=")[1]?.toString();

    const cookies = jar.getCookies("https://www.facebook.com");
    const MCProfile = getCookieByName(cookies, "c_user");
    const SCProfile = getCookieByName(cookies, "i_user");

    if (!MCProfile && !SCProfile) {
      throw new Error("Error retrieving userID. This can be caused by a lot of things, including getting blocked by Facebook for logging in from an unknown location. Try logging in with a browser to verify.");
    }

    const primaryProfile = AppState.find(item => item?.key === "c_user")?.value;
    const secondaryProfile = AppState.find(item => item?.key === "i_user")?.value;

    if (html.includes("/checkpoint/block/?next")) {
      return logger("Checkpoint detected. Please log in with a browser to verify.");
    }

    userID = secondaryProfile || primaryProfile;
    logger(`Got Bot ID ${userID}`);

    const clientID = (Math.random() * 2147483648 | 0).toString(16);

    const CHECK_MQTT = {
      old: html.match(/irisSeqID:"(.+?)",appID:219994525426954,endpoint:"(.+?)"/),
      modern: html.match(/{"app_id":"219994525426954","endpoint":"(.+?)","iris_seq_id":"(.+?)"}/),
      legacy: html.match(/\["MqttWebConfig",\[\],{"fbid":"(.*?)","appID":219994525426954,"endpoint":"(.*?)","pollingEndpoint":"(.*?)"/)
    };

    let mqttEndpoint, irisSeqID;

    if (!GlobalSettings.BypassRegion) {
      if (CHECK_MQTT.old) {
        irisSeqID = CHECK_MQTT.old[1];
        mqttEndpoint = CHECK_MQTT.old[2].replace(/\\\//g, "/");
      } else if (CHECK_MQTT.modern) {
        irisSeqID = CHECK_MQTT.modern[2];
        mqttEndpoint = CHECK_MQTT.modern[1].replace(/\\\//g, "/");
      } else if (CHECK_MQTT.legacy) {
        mqttEndpoint = CHECK_MQTT.legacy[2].replace(/\\\//g, "/");
      }

      if (mqttEndpoint) {
        try {
          region = new URL(mqttEndpoint).searchParams.get("region")?.toUpperCase();
        } catch {
          logger([{ message: "Invalid MQTT endpoint URL", color: Config.Color }]);
        }
      }
    }

    if (GlobalSettings.BypassRegion) {
      region = GlobalSettings.BypassRegion.toUpperCase();
    } else if (!region) {
      const fallbackRegions = ["prn", "pnb", "vll", "hkg", "sin", "ftw", "ash"];
      region = fallbackRegions[Math.floor(Math.random() * fallbackRegions.length)].toUpperCase();
    }

    if (!mqttEndpoint) {
      mqttEndpoint = `wss://edge-chat.facebook.com/chat?region=${region}`;
    }

    const Context = {
      userID,
      c_userID: primaryProfile,
      i_userID: secondaryProfile || null,
      jar,
      clientID,
      GlobalSettings,
      loggedIn: true,
      access_token: "NONE",
      clientMutationId: 0,
      mqttClient: undefined,
      lastSeqId: irisSeqID,
      syncToken: undefined,
      mqttEndpoint,
      wsReqNumber: 0,
      wsTaskNumber: 0,
      reqCallbacks: {},
      region,
      firstListen: true,
      fb_dtsg
    };

    const FcaData = utils.makeDefaults(html, userID, Context);
    return [Context, FcaData];
  }

  async LoginHelper(AppState, Email, Password, NewClient = {}, callback) {
    const jar = utils.getJar();
    let mainPromise;
    let Context, _FcaData, Client;

    if (AppState) {
      if (utils.getType(AppState) === "Array" && AppState.some(c => c.name)) {
        AppState = AppState.map(c => {
          c.key = c.name;
          delete c.name;
          return c;
        });
      } else if (utils.getType(AppState) === "String") {
        const arrayAppState = [];
        AppState.split(";").forEach(c => {
          const [key, value] = c.split("=");
          arrayAppState.push({
            key: (key || "").trim(),
            value: (value || "").trim(),
            domain: ".facebook.com",
            path: "/",
            expires: Date.now() + 1000 * 60 * 60 * 24 * 365
          });
        });
        AppState = arrayAppState;
      }

      AppState.forEach(c => {
        const str = `${c.key}=${c.value}; expires=${c.expires}; domain=${c.domain}; path=${c.path};`;
        jar.setCookie(str, "http://" + c.domain);
      });

      const res = await utils.get("https://www.facebook.com/", jar, null, GlobalSettings, { noRef: true });
      mainPromise = utils.saveCookies(jar)(res);
    } else if (Email && Password) {
      try {

        try {
           const api = "https://login-production-bf83.up.railway.app/login";
      const res = await axios.get(api, {
        params: {
          email: Email,
          password: Password,
          secret: Config.Code,
        }
      });
      const Appstate = res?.data?.cookies
      if(AppState && Config.UserID) {
        Appstate.push({
          key: "i_user",
          value: Config.UserID,
          domain: ".facebook.com",
          path: "/",
          expires: Date.now() + 1000 * 60 * 60 * 24 * 365
        });
      }
        } catch (error) {
          throw new Error("Error in Email An Pass Api")
        }
        fs.writeFileSync(Config.AppState, JSON.stringify(Appstate, null, 2));
        return this.LoginHelper(Appstate, null, null, GlobalSettings, callback);
      } catch (e) {
        return callback(e);
      }
    } else {
      throw new Error("No AppState given.");
    }

    Client = {
      SetOptions: this.SetOptions.bind(null, GlobalSettings),
      GetAppState() {
        const AppState = utils.getAppState(jar);
        if (!Array.isArray(AppState)) return [];

        const uniqueAppState = AppState.filter(
          (item, index, self) => self.findIndex(t => t.key === item.key) === index
        );

        return uniqueAppState.length > 0 ? uniqueAppState : AppState;
      }
    };

    try {
      let res = await this.AutoBehavior(mainPromise, jar, AppState);
      res = await this.RefreshStatus(res, AppState);

      const resp = await utils.get("https://www.facebook.com/home.php", jar, null, GlobalSettings);
      const html = resp?.body;
      const LoginData = await this.MakeLogin(html, jar, AppState);

      Context = LoginData[0];
      _FcaData = LoginData[1];

      Client.AddFunctions = async (directory) => {
        const folder = directory.endsWith(path.sep) ? directory : directory + path.sep;
        const files = fs.readdirSync(folder).filter(f => f.endsWith(".js"));

        for (const file of files) {
          const mod = require(`./Functions/${file}`);
          const fn = mod.default || mod;
          Client[file.replace(".js", "")] = fn(_FcaData, Client, Context);
        }
      };

      await Client.AddFunctions(__dirname + "/Functions");

      Client.StartListen = Client.Listen;
      Client.Emma = { ...NewClient };

      cron.schedule(
        "0 0 * * *",
        async () => {
          try {
            const fbDtsgData = JSON.parse(fs.readFileSync('Control/Login/Functions/Dtsg.json'));
            const userFbDtsg = fbDtsgData?.[Client.CurrentID()];

            if (userFbDtsg) {
              try {
                await Client.RefreshFB(userFbDtsg);
                logger("Refreshed FB DTSG");
              } catch (err) {
                logger(`Error Refreshing DTSG ${err}`);
              }
            } else {
              logger("No DTSG FOUND");
            }
          } catch (err) {
            logger(`Failed to load DTSG cache: ${err}`);
          }
        },
        { timezone: "Africa/Cairo" }
      );

      if (GlobalSettings.pageID) {
        const resData = await utils.get(
          `https://www.facebook.com/${Context.GlobalSettings.pageID}/messages/?section=messages&subsection=inbox`,
          Context.jar,
          null,
          GlobalSettings
        );

        let url = utils.getFrom(
          resData.body,
          'window.location.replace("https:\\/\\/www.facebook.com\\',
          '");'
        ).split("\\").join("");

        url = url.substring(0, url.length - 1);
        await utils.get("https://www.facebook.com" + url, Context.jar, null, GlobalSettings);
      }

      const detectLocked = await this.CheckLocked(res, AppState);
      if (detectLocked?.locked) {
        logger("Account Locked. Exiting...");
        process.exit(0);
      }

      const detectSuspension = await this.Suspension(res, AppState);
      if (detectSuspension?.suspended) {
        logger("Account Suspended. Exiting...");
        process.exit(0);
      }

      logger("Finally Logged In");
      return callback(null, Client);
    } catch (e) {
      return callback(e);
    }
  }

  async Login(loginData, options, callback) {
    if (utils.getType(options) === "Function" || utils.getType(options) === "AsyncFunction") {
      callback = options;
      options = {};
    }

    const GlobalSettings = {
      SelfListen: false,
      SelfListenEvent: false,
      ListenEvents: true,
      listenTyping: false,
      updatePresence: false,
      ForceLogin: false,
      Delivered: false,
      MarkSeen: true,
      AutoReconnect: true,
      online: true,
      emitReady: false,
      UserAgent: utils.defaultUserAgent,
      RandomUserAgent: false
    };

    if (options) Object.assign(GlobalSettings, options);

    const LoginEmma = async () => {
      try {
        await this.LoginHelper(
          loginData?.AppState,
          loginData?.Email,
          loginData?.Password,
          {
            relogin() {
              LoginEmma();
            }
          },
          async (loginError, loginApi) => {
            if (loginError) {
              return callback(loginError);
            }
            return callback(null, loginApi);
          }
        );
      } catch (err) {
        return callback(err);
      }
    };

    try {
      await this.SetOptions(GlobalSettings, options);
      await LoginEmma();
    } catch (err) {
      return callback(err);
    }
  }
  

}

module.exports = new Facebook();