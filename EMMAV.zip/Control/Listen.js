module.exports = function ({ api, usersData, threadsData, globalData }) {

  try {
    const logger = require("../Control/Logger/Log");
    const chalk = require("chalk");
    const gradient = require("gradient-string");
    const cons = require('./../Config/Settings.json');
    const theme = cons.DESIGN.Theme.toLowerCase();
    let cra, co, cb;

    if (theme === 'blue') {
      cra = gradient('yellow', 'lime', 'green');
      co = gradient("#243aff", "#4687f0", "#5800d4");
      cb = chalk.blueBright;
    } else if (theme === 'fiery') {
      cra = gradient('orange', 'yellow', 'yellow');
      co = gradient("#fc2803", "#fc6f03", "#fcba03");
      cb = chalk.hex("#fff308");
    } else if (theme === 'red') {
      cra = gradient('yellow', 'lime', 'green');
      co = gradient("red", "orange");
      cb = chalk.hex("#ff0000");
    } else if (theme === 'aqua') {
      cra = gradient("#6883f7", "#8b9ff7", "#b1bffc")
      co = gradient("#0030ff", "#4e6cf2");
      cb = chalk.hex("#3056ff");
    } else if (theme === 'pink') {
      cra = gradient('purple', 'pink');
      co = gradient("#d94fff", "purple");
      cb = chalk.hex("#6a00e3");
    } else if (theme.toLowerCase() === 'retro') {
      cra = gradient("orange", "purple");
      co = gradient.retro;
      cb = chalk.hex("#ffce63");
    } else if (theme.toLowerCase() === 'sunlight') {
      cra = gradient("#f5bd31", "#f5e131");
      co = gradient("#ffff00", "#ffe600");
      cb = chalk.hex("#faf2ac");
    } else if (theme.toLowerCase() === 'teen') {
      cra = gradient("#81fcf8", "#853858");
      co = gradient.teen;
      cb = chalk.hex("#a1d5f7");
    } else if (theme.toLowerCase() === 'summer') {
      cra = gradient("#fcff4d", "#4de1ff");
      co = gradient.summer;
      cb = chalk.hex("#ffff00");
    } else if (theme.toLowerCase() === 'flower') {
      cra = gradient("yellow", "yellow", "#81ff6e");
      co = gradient.pastel;
      cb = gradient('#47ff00', "#47ff75");
    } else if (theme.toLowerCase() === 'ghost') {
      cra = gradient("#0a658a", "#0a7f8a", "#0db5aa");
      co = gradient.mind;
      cb = chalk.blueBright;
    } else if (theme === 'hacker') {
      cra = chalk.hex('#4be813');
      co = gradient('#47a127', '#0eed19', '#27f231');
      cb = chalk.hex("#22f013");
    } else {
      cra = gradient('yellow', 'lime', 'green');
      co = gradient("#243aff", "#4687f0", "#5800d4");
      cb = chalk.blueBright;
    }



    global.loading(`${cra(`[ BOT_INFO ]`)} success!\n${co(`[ NAME ]:`)}  ${cra(`${(!global.Settings.BOTNAME) ? "H I N A" : global.Settings.BOTNAME}`)}  \n${co(`[ FBID ]:`)}  ${cra(`${api.CurrentID()}`)} \n${co(`[ PRFX ]:`)}  ${cra(`No Prefix`)}`, "LOADED");
    logger.loader(`${cra(`[ SQLite ]`)} ${cb(`${global.DB.allThreadData.length}`)} Thread & ${cb(`${global.DB.allUserData.length}`)} Users`);


    const Handler = require("./Actions/Handler.js")
    const { onChat, onEvent, onReply, onReaction, onEvents, onRun, Database } = Handler({ api, usersData, threadsData, globalData });
    const Messages = global.Funcs.message;



    return async (event) => {
      if (event.LogMessageType) {
        await threadsData.refreshInfo(event.ThreadID)
      }

      if (event && (event.Type === "Message" || event.Type === "Message_Reply")) {
        await usersData.addExp(event.SenderID, 1);
      }

      const Message = Messages(api, event);
      async function onListen() {
        if (global.Emma.Listen.size == 0) return;

        try {
          global.Emma.Listen.forEach(async (current, KEY) => {
            try {
              const conditionResult = eval(current.condition);

              if (conditionResult) {
                const resultFunction = eval(current.result);
                if (typeof resultFunction === 'function') {
                  await resultFunction();
                }
                global.Emma.Listen.delete(KEY);
              }
            } catch (err) {
            }
          });
        } catch (err) {
          global.loading(err, "Listener")
        }
      }
      Database({ event })
      try {
        switch (event.Type) {
          case "Message":
          case "Message_Reply":
          case "Message_Unsend":
            onChat({ event });
            onReply({ event });
            onEvent({ event });
            onListen()
            break;
          case "change_thread_image":
            break;
          case "Event":
            onEvents({ event });
            onRun({ event });
            onListen()
            break;
          case "Message_Reaction":
            onReaction({ event });
            onListen()
            if (event.Reaction === "🗑️" && event.SenderID === api.CurrentID() && event.UserID === global.Settings.OwnerID) {
              api.Unsend(event.MessageID);
            }
            break;
          default:
            break;
        }
      } catch (error) {
        console.log(err)
        global.loading(error, "Listener")
      }
    };
  } catch (error) {
    global.loading(error, "Listener")
  }
};
