const Messages = global.Funcs.message;
const { DB, Settings } = global;
const config = Settings;
const log = global.loading;
const { creatingThreadData, creatingUserData } = global.Emma.Database;

module.exports = function ({ api, usersData, threadsData, globalData }) {
  const { ADMINBOT, SUPPORT, AdminOnly, GcAdminOnly } = global.Settings;

  const getRole = (senderID, threadData) => {
    const senderIDStr = String(senderID);
    if (ADMINBOT.includes(senderIDStr)) return 3;
    if (SUPPORT.includes(senderIDStr)) return 2;
    if (threadData && threadData.adminIDs && threadData.adminIDs.includes(senderIDStr)) return 1;
    return 0;
  };

  const checkRestriction = (senderID, threadData, userData) => {
    const senderIDStr = String(senderID);
    const isBotAdmin = ADMINBOT.includes(senderIDStr) || SUPPORT.includes(senderIDStr);

    if (!isBotAdmin) {
      if (userData && userData.banned && userData.banned.status) return { allowed: false, msg: null };
      if (threadData && threadData.banned && threadData.banned.status) return { allowed: false, msg: null };
      if (threadData && !threadData.On) return { allowed: false, msg: null };
    }

    if (!isBotAdmin) {
      if (AdminOnly && GcAdminOnly) {
        return { allowed: false, msg: 'البوت متاح فقط لادمن البوت أو ادمن المجموعة' };
      }
      if (AdminOnly) {
        return { allowed: false, msg: 'البوت متاح فقط لادمن البوت' };
      }
      if (GcAdminOnly && threadData) {
        if (!threadData.adminIDs.includes(senderIDStr)) {
          return { allowed: false, msg: 'البوت متاح فقط لادمن المجموعة' };
        }
      }
    }

    return { allowed: true, msg: null };
  };

  const getLangHelper = (obj, langCode) => {
    if (obj && obj.languages && typeof obj.languages === 'object' && obj.languages.hasOwnProperty(langCode)) {
      return (...values) => {
        let lang = obj.languages[langCode][values[0]] || '';
        for (let i = values.length - 1; i > 0; i--) {
          const expReg = RegExp('%' + i, 'g');
          lang = lang.replace(expReg, values[i]);
        }
        return lang;
      };
    }
    return () => { };
  };

  const onRun = async function ({ event }) {
    try {
      const Message = Messages(api, event);
      const { onEvent } = global.Emma;
      const { SenderID, ThreadID } = event;

      const threadData = await threadsData.get(ThreadID);
      const permission = getRole(SenderID, threadData);

      for (const [key, Run] of onEvent.entries()) {
        const getLang = getLangHelper(Run, global.Settings.Lang);

        try {
          const ExeSettings = {
            api,
            Message,
            usersData,
            Role: permission,
            getLang,
            threadsData,
            event,
          };
          const func = await Run.onRun(ExeSettings);
          if (typeof func === 'function') {
            const innerFunction = func();
            if (typeof innerFunction === 'function') {
              await innerFunction();
            }
          }
        } catch (error) {
          await global.loading(error, 'onActions:');
        }
      }
    } catch (error) {
      await global.loading(error, 'onActions:');
    }
  };

  const onChat = async function ({ event }) {
    try {
      const Message = Messages(api, event);
      const dateNow = Date.now();
      const { commands } = global.Emma;
      const { Body, SenderID, ThreadID } = event;
      const SenderIDStr = String(SenderID);

      const userData = await usersData.get(SenderID);
      const threadData = await threadsData.get(ThreadID);

      let prefix = global.Funcs.getPrefix(ThreadID);

      if (!Body || !Body.startsWith(prefix)) return;

  const [commandName, ...args] = Body.slice(prefix.length).trim().split(/ +/);
      const command = commands.get(commandName) || commands.get(global.Emma.Aliases.get(commandName));

      if (!command) return;

      const check = checkRestriction(SenderID, threadData, userData);
      if (!check.allowed) {
        if (check.msg) return Message.reply(check.msg);
        return;
      }

      const permission = getRole(SenderID, threadData);

      if (command.Emma.Role > permission) {
        return Message.reply("ليس لديك الاذن");
      }

      if (!global.Emma.Rest.has(command.Emma.name)) {
        global.Emma.Rest.set(command.Emma.name, new Map());
      }

      const timestamps = global.Emma.Rest.get(command.Emma.name);
      const expirationTime = (command.Emma.Rest || 1) * 1000;

      if (timestamps.has(SenderIDStr) && dateNow < timestamps.get(SenderIDStr) + expirationTime) {
        return Message.react('⏳');
      }

      const getLang = getLangHelper(command, global.Settings.Lang);

      try {
        const ExSettings = {
          api,
          Message,
          usersData,
          Role: permission,
          threadsData,
          globalData,
          event,
          args,
          getLang,
        };
        command.Begin(ExSettings);
        timestamps.set(SenderIDStr, dateNow);
      } catch (e) {
        await global.loading(e, "onChat:");
      }
    } catch (err) {
      await global.loading(err, "onChat:");
    }
  };

  const onEvent = async function ({ event }) {
    try {
      const Message = Messages(api, event);
      const { commands, EvReg } = global.Emma;
      const { SenderID, ThreadID } = event;

      const threadData = await threadsData.get(ThreadID);
      const userData = await usersData.get(SenderID);

      const permission = getRole(SenderID, threadData);

      const check = checkRestriction(SenderID, threadData, userData);
      if (!check.allowed) return;

      for (const eventReg of EvReg) {
        const cmd = commands.get(eventReg);
        const getLang = getLangHelper(cmd, global.Settings.Lang);

        if (!getLang && cmd.languages && !cmd.languages.hasOwnProperty(global.Settings.Lang)) {
        }

        try {
          const ExSettings = {
            event,
            api,
            Message,
            role: permission,
            Role: permission,
            usersData,
            threadsData,
            globalData,
            getLang,
          };

          if (cmd) {
            cmd.onEvent(ExSettings);
          }
        } catch (error) {
          global.loading(error, "onEvents:");
        }
      }
    } catch (error) {
      global.loading(error, "onEvents:");
    }
  };

  const onEvents = async function ({ event }) {
    try {
      const Message = Messages(api, event);
      const { events } = global.Emma;
      const { SenderID, ThreadID } = event;

      const threadData = await threadsData.get(ThreadID);

      const permission = getRole(SenderID, threadData);

      for (const [key, value] of events.entries()) {
        if (value.Emma.eventType.indexOf(event.LogMessageType) !== -1) {
          const eventRun = events.get(key);
          try {
            const ExeSettings = {
              api,
              Message,
              usersData,
              threadsData,
              Role: permission,
              event,
            };
            await eventRun.Begin(ExeSettings);
          } catch (error) {
            console.log(error);
            await global.loading(error, "onEvent:");
          }
        }
      }
    } catch (error) {
      console.log(error);
      await global.loading(error, "onEvent:");
    }
  };

  const onReaction = async function ({ event }) {
    try {
      const { onReaction, commands } = global.Emma;
      const { MessageID, ThreadID, UserID } = event;

      if (onReaction.has(MessageID)) {
        const Message = Messages(api, event);
        const indexOfMessage = onReaction.get(MessageID);
        const handleNeedExec = commands.get(indexOfMessage.name);

        if (!handleNeedExec) return console.log('Missing Value to respond');

        const reactorID = UserID || event.SenderID;
        const userData = await usersData.get(reactorID);
        const threadData = await threadsData.get(ThreadID);

        const check = checkRestriction(reactorID, threadData, userData);
        if (!check.allowed) return;

        const permission = getRole(reactorID, threadData);

        const getLang = getLangHelper(handleNeedExec, global.Settings.Lang);
        if (!getLang && handleNeedExec.languages && !handleNeedExec.languages.hasOwnProperty(global.Settings.Lang)) {
          return console.log('Missing Lang Key');
        }

        try {
          const ExSettings = {
            api,
            Message,
            usersData,
            threadsData,
            event,
            onReaction: indexOfMessage,
            getLang,
            Role: permission,
          };
          handleNeedExec.onReaction(ExSettings);
          return;
        } catch (error) {
          await global.loading(error, "onReaction:");
        }
      }
    } catch (err) {
      await global.loading(err, "onReaction:");
    }
  };

  const onReply = async function ({ event }) {
    try {
      if (!event.MessageReply) return;
      const Message = Messages(api, event);
      const { onReply, commands } = global.Emma;
      const { MessageReply, SenderID, ThreadID } = event;

      if (onReply.size !== 0) {
        if (!onReply.has(MessageReply.MessageID)) return;

        const userData = await usersData.get(SenderID);
        const threadData = await threadsData.get(ThreadID);

        const check = checkRestriction(SenderID, threadData, userData);
        if (!check.allowed) {
          if (check.msg) return Message.reply(check.msg);
          return;
        }

        const permission = getRole(SenderID, threadData);

        const indexOfMessage = await onReply.get(MessageReply.MessageID);
        if (!commands.has(indexOfMessage.name)) return console.log('Missing Value to respond');

        const handleNeedExec = await commands.get(indexOfMessage.name);

        try {
          const getLang = getLangHelper(handleNeedExec, global.Settings.Lang);
          if (!getLang && handleNeedExec.languages && !handleNeedExec.languages.hasOwnProperty(global.Settings.Lang)) {
            return console.log('Missing Lang Key');
          }

          const ExSettings = {
            api,
            event,
            Message,
            globalData,
            usersData,
            threadsData,
            onReply: indexOfMessage,
            Reply: indexOfMessage,
            getLang,
            Role: permission
          };

          await handleNeedExec.onReply(ExSettings);
          return;
        } catch (error) {
          await global.loading(error, "onReply:");
        }
      }
    } catch (error) {
      await global.loading(error, "onReply:");
    }
  };

  const Database = async function ({ event }) {
    if (!event?.ThreadID) return;
    const { ThreadID, Group } = event;
    const SenderID = event.SenderID || event.author || event.UserID;

    if (ThreadID && Group && !DB.allThreadData.some(t => t.ThreadID === ThreadID)) {
      try {
        if (global.temp.createThreadDataError.includes(ThreadID)) return;

        const findInCreatingThreadData = creatingThreadData.find(t => t.ThreadID === ThreadID);
        if (!findInCreatingThreadData) {
          const threadData = await threadsData.create(ThreadID);
          const Uc = config.DATABASE.type.substring(0, 3).toUpperCase();
          const Mc = config.DATABASE.type.replace(config.DATABASE.type.substring(0, 3), Uc);

          log(`New Thread: ${ThreadID} | ${threadData.threadName} | ${Mc}`, "DATABASE");
        } else {
          await findInCreatingThreadData.promise;
        }
      } catch (err) {
        global.temp.createThreadDataError.push(ThreadID);
        console.log(err);
      }
    }

    if (SenderID && !DB.allUserData.some(u => u.UserID === SenderID)) {
      try {
        const findInCreatingUserData = creatingUserData.find(u => u.UserID === SenderID);
        if (!findInCreatingUserData) {
          const userData = await usersData.create(SenderID);
          log(`New User: ${SenderID} | ${userData.name} | ${config.DATABASE.type}`, "DATABASE");
        } else {
          await findInCreatingUserData.promise;
        }
      } catch (err) {
        console.log(err);
      }
    }
  };

  return {
    onRun,
    onChat,
    onEvent,
    onReaction,
    onReply,
    onEvents,
    Database
  };
};