module.exports.Emma = {
    name: "Join",
    eventType: ["log:subscribe"],
    version: "1.0.4",
    credits: "Emma",
    description: "notify member join"
};

module.exports.Begin = async function ({ api, event, threadsData }) {
    const { ThreadID } = event;


    if (event.LogMessageData.AddedIDs.some(i => i.userFbId == api.CurrentID())) {
        await threadsData.refreshInfo(event.ThreadID)
        api.SendMessage("[✅]~ تم ارسال طلب للنظام", ThreadID);
        api.Nickname(`✅  Emma  ✅`, ThreadID, api.CurrentID());
        api.SendMessage(`نجح الاتصال 👾✅`, ThreadID);
    } else {
        try {

            let { threadName, ParticipantIDs } = await api.GetThreadInfo(ThreadID);

            let nameArray = [];
            let mentions = [];
            let memLength = [];
            let i = 0;

            for (let id in event.LogMessageData.AddedIDs) {
                const userName = await event.LogMessageData.AddedIDs[id].fullName;
                nameArray.push(userName);
                mentions.push({ Tag: userName, ID: id });
                memLength.push(ParticipantIDs.length - i++);
            }


            await threadsData.refreshInfo(event.ThreadID)

            msg = `مرحبا بك يا : ${nameArray.join(', ')}\n في مجموعة\n${threadName}`;

            let formPush = { Body: msg, Mentions: mentions };

            return api.SendMessage(formPush, ThreadID);
        } catch (e) {
            return console.log(e);
        }
    }
};