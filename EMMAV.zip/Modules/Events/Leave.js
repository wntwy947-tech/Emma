
module.exports.Emma = {
  name: "Leave",
  eventType: ["log:unsubscribe"],
  version: "1.0.0",
  credits: "Emma",
  description: "Notify bots or leavers",
};

module.exports.Begin = async function ({ api, event, usersData, threadsData }) {
  await threadsData.refreshInfo(event.ThreadID);
  if (event.LogMessageData.LeftID === api.CurrentID()) return;

  const t = await threadsData.get(event.ThreadID);
  const { settings } = t;

  if (!settings.sendLeaveMessage) return;

  const { ThreadID } = event;
  await threadsData.refreshInfo(event.ThreadID);
  const data = await usersData.get(event.LogMessageData.LeftID);
  const name = data.name;
  const type = event.Author == event.LogMessageData.LeftID ? "خرج بكرامته" : "اترمي برا زي الكلب";

  const msg = `${name}\n${type}`;
  const formPush = { Body: msg };

  return api.SendMessage(formPush, ThreadID);
};