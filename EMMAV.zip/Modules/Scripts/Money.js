module.exports = {
  Emma: {
    name: "رصيدي",
    Aliases: ["فلوسي", "دراهمي"],
    version: "1.1",
    author: "Emma",
    description: "يظهر لك رصيدك الحالي",
    Role: 0,
    cooldown: 3,
    Class: "اقتصاد"
  },

  Begin: async function ({ event, usersData, Message }) {
    const userID = event.SenderID;

    try {
      const money = await usersData.getMoney(userID);

      return Message.reply(`رصيدك الحالي: ${money}$`);
    } catch (err) {
      console.log(err);
      return Message.reply("حدث خطأ أثناء جلب رصيدك ⚠️");
    }
  }
};