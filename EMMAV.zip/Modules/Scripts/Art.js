const moment = require("moment-timezone");

module.exports = {
  Emma: {
    name: "تحويل",
    Aliases: ["Animate"],
    Version: "1.0",
    Author: "Shady Tarek",
    Rest: 30,
    Role: 0,
    Description: "",
    Class: "الذكاء",
  },
  languages: {
    Ar: {
      Done: '✅ | تم الانتهاء من تحويل الصورة الى انمي\n⌯︙بواسطة -› %1\n⌯︙استغرق -› %2 🧭\n⌯︙الموديل -› %3 👾\n⌯︙الوقت -› %4 ⌚\n⌯︙التاريخ -› %5 📚',
      Reply: '⚠️ | الرجاء الرد على صورة',
      Error: '❌ | حدث خطاء اثناء تحويل الصورة الى انمي'
    },
    En: {
      Done: '✅ | Done Animating Your Image\n⌯︙By -› %1\n⌯︙Took -› %2 🧭\n⌯︙Model -› %3 👾\n⌯︙Time -› %4 ⌚\n⌯︙Date -› %5 📚',
      Reply: '⚠️ | Please Reply to an Image',
      Error: '❌ | An Error Occurred While Animating the Image'
    }
  },

  Begin: async function ({ event, args, getLang: GetLang, Message, usersData: Users }) {
    try {
      let Model;
      const txt = args.join(" ");
      const Number = txt.split("--M")[1];
      if (parseInt(Number) && Number < 533) {
        Model = Number;
      } else {
        Model = 1;
      }

      let Final = [];
      let Data;

      if (!event?.MessageReply?.Attachments[0]) {
        return Message.Reply(GetLang('Reply'));
      }

      const startTime = new Date();
      Message.react("⚙️");
      for (const r of event.MessageReply.Attachments) {
        if (r.Type.includes('Photo')) {
          const Img = await Funcs.AiMirror(r.Url, Model);
          Data = Img
          Final.push(Img.Image)
        }
      }



      const endTime = new Date();
      const SenderID = event.SenderID;
      const userNamefromData = await Users.getName(SenderID);
      const drawingTime = (endTime - startTime) / 1000;

      const currentDate = moment.tz("Africa/Cairo").format("YYYY-MM-DD");
      const currentTime = moment.tz("Africa/Cairo").format("h:mm:ss A");
      Message.React("✔️");
      Message.Reply({
        Body: GetLang('Done', userNamefromData, drawingTime, Data.Name, currentTime, currentDate),
        Attachment: Final
      });

    } catch (error) {
      Message.react("❌");
      Message.reply(GetLang('Error'));
    }
  }
};
