const moment = require("moment-timezone");

module.exports = {
  Emma: {
    name: "سيأرت",
    Version: "1.0",
    Author: "Shady Tarek",
    Rest: 5,
    Role: 0,
    Description: "",
    Class: "الذكاء",
  },

  languages: {
    Ar: {
      User: "مستخدم فيسبوك",
      ProvideText: "لم تقم بتوفير نص.",
      Done: '✅ | تم تنفيذ طلبك بنجاح 🏜\n\n⌯︙بواسطة -› %1\n⌯︙استغرق -› %2 🧭\n⌯︙الوقت -› %3 ⌚\n⌯︙التاريخ -› %4 📚',
      Error: "حدث خطأ أثناء إنشاء الصور."
    },
    En: {
      User: "Facebook User",
      ProvideText: "You didn't provide any text.",
      Done: '✅ | Your request has been successfully completed 🏜\n\n⌯︙By -› %1\n⌯︙Took -› %2 🧭\n⌯︙Time -› %3 ⌚\n⌯︙Date -› %4 📚',
      Error: "An error occurred while generating the images."
    }
  },

  Begin: async function ({ args, Message, event, usersData, getLang: GetLang }) {
    try {
      Message.React("⚙️");

      const txt = args.join(" ");
      const pompt = txt.split("--u")[0];
      const prompt = pompt.split("--ar")[0];

      if (!prompt) {
        return Message.reply(GetLang("ProvideText"));
      }

      let ratio = "1:1";
      const Supported = [
        "3:4",
        "4:3",
        "1:1",
        "4:5",
        "2:3",
        "16:9",
        "9:16"
      ];

      const Rindex = args.find(arg => Supported.includes(arg));
      if (Rindex) ratio = Rindex;

      const TP = await Funcs.translate(prompt, "ar", "en");

      const startTime = new Date();

      const X = new Funcs.SeaArt();
      const G = await X.AniGen(TP, ratio);

      const userName =
        (await usersData.getName(event.SenderID)) || GetLang("User");

      const endTime = new Date();
      const drawingTime = (endTime - startTime) / 1000;

      const currentDate = moment
        .tz(global.Settings.TimeZone)
        .format("YYYY-MM-DD");
      const currentTime = moment
        .tz(global.Settings.TimeZone)
        .format("h:mm:ss A");

      Message.React("✔️");
      Message.reply({
        Body: GetLang(
          "Done",
          userName,
          drawingTime,
          currentTime,
          currentDate
        ),
        Attachment: G.urls
      });

    } catch (e) {
      console.log(e);
      Message.React("❌");
      Message.reply(GetLang("Error"));
    }
  },
};
