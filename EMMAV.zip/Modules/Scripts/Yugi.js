const axios = require("axios");

module.exports = {
  Emma: {
    name: "يوغي",
    Aliases: ["yugi"],
    Author: "Shady Tarek",
    Role: 0,
    Rest: 5,
    Description: "Yugi oh cards",
    Class: "الألعاب",
  },

  Begin: async function ({ Message, args }) {
    try {
      if (!args[0]) return;

      const cardName = args.join(" ");
      const response = await axios.get(
        `https://db.ygoprodeck.com/api/v7/cardinfo.php?fname=${encodeURIComponent(cardName)}`
      );

      const card = response.data.data[0];

      const name = card.name || "لا يوجد";
      const atk = card.atk || "لا يوجد";
      const def = card.def || "لا يوجد";
      const level = card.level || "لا يوجد";
      const imageUrl = card.card_images[0].image_url;

      await Message.reply({
        Body:
          `- اسم البطاقة: ${name}\n` +
          `- الهجوم: ${atk}\n` +
          `- الدفاع: ${def}\n` +
          `- المستوى: ${level}`,
        Attachment: await Funcs.getStreamFromURL(imageUrl),
      });
    } catch (e) {
      console.log(e);
      Message.reply("❌ | بطاقة غير موجودة");
    }
  },
};
