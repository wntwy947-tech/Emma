const fs = require("fs");
const path = require("path");

const WA = fs.readFileSync(
  path.join(__dirname + "/cache/Json/Words.json"),
  "utf-8"
);
const wordsArray = JSON.parse(WA);

module.exports = {
  Emma: {
    name: "كلمات",
    Aliases: ["fsw"],
    Author: "Shady Tarek",
    Role: 0,
    Rest: 5,
    Description: "اسرع من يرسل الكلمة يكسب",
    Class: "الألعاب",
  },

  Begin: async function ({ Message }) {
    try {
      const randomWord = getRandomFromArray(wordsArray);

      await Message.reply({
        Body: `⌔︙اسرع واحد يكتب الكلمة ↢ [ ${randomWord} ]`,
      });

      global.Emma.Listen.set(Math.floor(Math.random() * 10000), {
        condition: `event.Body.toLowerCase() === "${randomWord.toLowerCase()}"`,
        result: `async () => {
          try {
            Message.react("✅");
            Message.reply(
              "⌯ | " +
                await usersData.getName(event.SenderID) +
                " ، فاز و كان اسرع شخص يرسل الكلمة : ${randomWord} 📕"
            );
            await usersData.addStars(event.SenderID, 1);
          } catch (e) {}
        }`,
      });
    } catch (e) {
      Message.react("❌");
    }
  },
};

function getRandomFromArray(array) {
  return array[Math.floor(Math.random() * array.length)];
}
