module.exports = {
  Emma: {
    name: "تحدي",
    Aliases: ["rock"],
    Author: "Shady Tarek",
    Role: 0,
    Rest: 5,
    Description: "حجر ورقة مقص",
    Class: "الألعاب",
  },

  Begin: async function ({ usersData, event, api }) {
    try {
      const userName = await usersData.getName(event.SenderID);

      await api.SendMessage(
        `- للبدء اللعبة .
← اخـتــار :
1 - حجرة 🗿
2 - ورقة 📄
3 - مقص ✂

- الرد بالرقم او الاسم 🕹`,
        event.ThreadID,
        (err, info) => {
          global.Emma.onReply.set(info.MessageID, {
            name: "تحدي",
            MessageID: info.MessageID,
            type: "rockPaperScissorsGame",
            author: event.SenderID,
            authorName: userName,
            botChoice: Math.floor(Math.random() * 3) + 1,
          });
        },
        event.MessageID
      );

    } catch (e) { }
  },

  onReply: async function ({ Message, event, Reply, threadsData }) {
    try {
      const { author, type, MessageID, botChoice } = Reply;
      if (author !== event.SenderID) return;
      if (type !== "rockPaperScissorsGame") return;

      const args = event.Body.trim();
      const validChoices = ["1", "2", "3", "حجرة", "ورقة", "مقص"];

      if (!validChoices.includes(args)) {
        return Message.reply(`- خطأ ❌ ، الرد فقط بالرقم أو الاسم .`);
      }

      const userChoice = isNaN(args)
        ? convertChoiceToNumber(args)
        : parseInt(args);

      const result = determineWinner(userChoice, botChoice);

      await Message.Unsend(MessageID);

      Message.reply(
        `- انت اخترت : ${convertNumberToChoice(userChoice)}
- و انا اخترت : ${convertNumberToChoice(botChoice)}
${result}`
      );

      const members = await threadsData.get(event.ThreadID, "members");
      const fm = members.find((u) => u.userID == event.SenderID);
      if (fm) fm.stars += 1;
      await threadsData.set(event.ThreadID, members, "members");
    } catch (e) { }
  },
};

function convertChoiceToNumber(choice) {
  switch (choice) {
    case "حجرة":
      return 1;
    case "ورقة":
      return 2;
    case "مقص":
      return 3;
    default:
      return 0;
  }
}

function convertNumberToChoice(number) {
  switch (number) {
    case 1:
      return "حجرة";
    case 2:
      return "ورقة";
    case 3:
      return "مقص";
    default:
      return "خطأ";
  }
}

function determineWinner(userChoice, botChoice) {
  if (userChoice === botChoice) {
    return "وربي حظظ 🙂";
  } else if (
    (userChoice === 1 && botChoice === 3) ||
    (userChoice === 2 && botChoice === 1) ||
    (userChoice === 3 && botChoice === 2)
  ) {
    return "انا خسرت تفوو 🙂";
  } else {
    return "هينا عمتكك نيهاهاها 🙂";
  }
}
