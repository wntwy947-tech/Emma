module.exports = {
  Emma: {
    name: "اوامر",
    Aliases: ["اوامر", "الاوامر", "help", "commands", "menu"],
    author: "System",
    Role: 0,
    Rest: 5,
    description: "عرض قائمة جميع الأوامر المتاحة",
    Class: "خدمات"
  },

  languages: {
    Ar: {
      commandsList: "⌔︙اوامــر ايما 🌌\n\n%1"
    }
  },

  Begin: async function ({ Message, getLang }) {
    const { commands } = global.Emma;
    const categories = {};

    for (const [name, command] of commands) {
      if (
        !command.Emma ||
        !command.Emma.Class ||
        command.Emma.Hidden === true
      ) continue;

      const category = command.Emma.Class;

      if (!categories[category]) {
        categories[category] = [];
      }

      categories[category].push(name);
    }

    let text = "";
    const sortedCategories = Object.keys(categories).sort();

    for (const category of sortedCategories) {
      const cmds = categories[category].sort();
      text += `❁ │ 『${category}』\n`;
      text += `⌯ ${cmds.join(" ⇌ ")}\n\n`;
    }

    const finalMessage = getLang("commandsList", text.trim());

    const images = [
      "https://i.ibb.co/DfTmkTMb/Zpe-Wgp2-Gps.jpg"
    ];

    const randomImage = images[Math.floor(Math.random() * images.length)];

    return Message.reply({
      Body: finalMessage,
      Attachment: randomImage
    });
  }
};