const moment = require("moment-timezone");

module.exports = {
  Emma: {
    name: "لغيبيلي",
    Version: "1.0",
    Author: "Shady Tarek",
    Rest: 30,
    Role: 0,
    Description: "",
    Class: "الذكاء",
  },
  languages: {
    Ar: {
      Done: '✅ | تم الانتهاء من تحويل الصورة \n⌯︙بواسطة -› %1\n⌯︙استغرق -› %2 🧭\n⌯︙الوقت -› %3 ⌚\n⌯︙التاريخ -› %4 📚',
      Reply: '⚠️ | الرجاء الرد على صورة',
      Error: '❌ | حدث خطاء اثناء تحويل الصورة '
    },
    En: {
      Done: '✅ | Done Editing Your Image\n⌯︙By -› %1\n⌯︙Took -› %2 🧭\n⌯︙Time -› %3 ⌚\n⌯︙Date -› %4 📚',
      Reply: '⚠️ | Please Reply to an Image',
      Error: '❌ | An Error Occurred While Editing the Image'
    }
  },
  Begin: async function ({ event, args, getLang: GetLang, Message, usersData }) {
    try {
      let Arr = [];
      let Final = [];

      let text = args.join(" ");
      if (!text) text = "";

      if (!event?.MessageReply?.Attachments?.[0]) {
        return Message.reply(GetLang("Reply"));
      }

      Message.React("⚙️");

      const Prompt = await Funcs.translate(text, "ar", "en");

      const startTime = new Date();

      const Editor = new Funcs.Ghibili();
      for (const A of event.MessageReply.Attachments) {
        Arr.push(A.Url);
      }

      const Ai = await Editor.Edit(Prompt, Arr);

      for (const Image of Ai.images) {
        Final.push(await Funcs.getStreamFromURL(Image.url));
      }

      const endTime = new Date();
      const SenderID = event.SenderID;
      const userName =
        (await usersData.getName(SenderID)) || "مستخدم فيسبوك";

      const drawingTime = (endTime - startTime) / 1000;

      const currentDate = moment
        .tz("Africa/Cairo")
        .format("YYYY-MM-DD");
      const currentTime = moment
        .tz("Africa/Cairo")
        .format("h:mm:ss A");

      Message.React("✔️");
      Message.reply({
        Body: GetLang(
          "Done",
          userName,
          drawingTime,
          currentTime,
          currentDate
        ),
        Attachment: Final,
      });

    } catch (error) {
      console.log(error);
      Message.React("❌");
      Message.reply(GetLang("Error"));
    }
  },
};
