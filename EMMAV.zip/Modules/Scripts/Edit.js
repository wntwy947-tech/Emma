const moment = require("moment-timezone");

module.exports = {
  Emma: {
    name: "لتعديل",
    Author: "Shady Tarek",
    Rest: 30,
    Role: 3,
    Description: "",
    Class: "الذكاء",
  },

  Begin: async function ({ event, args, Message, usersData }) {
    try {
      let Arr = [];
      let Final = [];

      const text = args.join(" ");
      if (!event?.MessageReply?.Attachments[0] || !text) {
        return Message.reply("⚠️ | الرجاء الرد على صورة وكتابة شيء");
      }
      Message.React("⚙️");
      const Prompt = await Funcs.translate(text, "ar", "en");

      const startTime = new Date();

      const Editor = new Funcs.NanoBanana();
      for (const A of event.MessageReply.Attachments) {
        Arr.push(A.Url);
      }

      const Ai = await Editor.Edit(Prompt, Arr);

      for (const Image of Ai.images) {
        Final.push(await Funcs.getStreamFromURL(Image.url));
      }

      const endTime = new Date();
      const SenderID = event.SenderID;
      const userName =
        (await usersData.getName(SenderID)) || "مستخدم فيسبوك";

      const drawingTime = (endTime - startTime) / 1000;

      const currentDate = moment
        .tz("Africa/Cairo")
        .format("YYYY-MM-DD");
      const currentTime = moment
        .tz("Africa/Cairo")
        .format("h:mm:ss A");

      Message.react("✔️");
      Message.reply({
        Body: `✅ | تم الانتهاء من تحويل الصورة
⌯︙بواسطة -› ${userName}
⌯︙استغرق -› ${drawingTime} 🧭
⌯︙الوقت -› ${currentTime} ⌚
⌯︙التاريخ -› ${currentDate} 📚`,
        Attachment: Final,
      });

    } catch (error) {
      console.log(error);
      Message.React("❌");
      Message.reply("❌ | حدث خطأ أثناء تحويل الصورة");
    }
  },
};
