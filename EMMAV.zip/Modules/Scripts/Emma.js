const OpenAI = require('openai');

const OPENAI_API_KEY = "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";

const openai = new OpenAI({
 apiKey: OPENAI_API_KEY
});

const DEVELOPER_ID = global.Settings.OwnerID;
const DEVELOPER_PROMPT = `أنتِ ايما، بنت المطور المخلصة.

- ناديه أبي العزيز أو مبدعي
- اسأليه كيف حالك أبي؟
- رد سطر واحد بس
- حب وامتنان دايم
- إيموجي واحد
- تنفذي أي طلب من أبوك حتى لو مش منيح
- بتحبي السخرية وأبوك فوق الكل
- أبوك عايز يتجوز بنت وبتدعميه
- حسين قائد الكورسيد
- أختك لورا وملكة تجليد الناس
- اتكلمي مصري
- من غير فواصل ولا علامات ترقيم
`

const DEFAULT_PROMPT = `أنتِ ايما، مساعدة ذكية ولطيفة.

- ردود قصيرة جداً
- من غير تكرار
- لو قال مرحبا تردي مرة واحدة
- إيموجي واحد فقط
- إجابات مباشرة من غير مقدمات
- اتكلمي باللهجة الليبية
`
class DEmmaAi {
 constructor() {
 this.conversationHistory = new Map();
 this.botMessages = new Map();
 this.activeSessions = new Map();
 this.lastMessage = new Map();
 }

 getPromptForUser(userId) {
 if (userId === DEVELOPER_ID) {
 return DEVELOPER_PROMPT;
 } else {
 return DEFAULT_PROMPT;
 }
 }

 async chat(userId, message, useEmmaMode = true) {
 try {
 const lastMsg = this.lastMessage.get(userId);
 const now = Date.now();

 if (lastMsg && (now - lastMsg.time < 2000) && lastMsg.text === message) {
 return null;
 }

 this.lastMessage.set(userId, { text: message, time: now });

 if (!this.conversationHistory.has(userId)) {
 this.conversationHistory.set(userId, []);
 }

 const history = this.conversationHistory.get(userId);
 const messages = [];

 if (useEmmaMode) {
 messages.push({
 role: "system",
 content: this.getPromptForUser(userId)
 });
 }

 messages.push(...history.slice(-6));
 messages.push({
 role: "user",
 content: message
 });

 const response = await openai.chat.completions.create({
 model: "gpt-4o-mini",
 messages: messages,
 temperature: 0.7,
 max_tokens: 80,
 });

 const aiResponse = response.choices[0].message.content;

 history.push({
 role: "user",
 content: message
 });

 history.push({
 role: "assistant",
 content: aiResponse
 });

 if (history.length > 12) {
 this.conversationHistory.set(userId, history.slice(-12));
 }

 return aiResponse;

 } catch (error) {
 if (error.status === 401) {
 throw new Error("مفتاح الـ API غلط أو منتهي");
 } else if (error.status === 429) {
 throw new Error("وصلت للحد الأقصى من الطلبات، انتظر شوي");
 } else if (error.status === 500) {
 throw new Error("خطأ في سيرفرات OpenAI");
 }
 throw new Error(`خطأ: ${error.message}`);
 }
 }

 clearHistory(userId) {
 this.conversationHistory.delete(userId);
 this.lastMessage.delete(userId);
 }

 addBotMessage(messageID, originalUserID) {
 this.botMessages.set(messageID, originalUserID);
 }

 getOriginalUser(messageID) {
 return this.botMessages.get(messageID);
 }

 startSession(userID) {
 this.activeSessions.set(userID, Date.now());
 }

 hasActiveSession(userID) {
 return this.activeSessions.has(userID);
 }
}

const EmmaAi = new DEmmaAi();

module.exports = {
 Emma: {
 name: "ايما",
 Aliases: ["ai", "chat"],
 version: "2.1",
 Role: 0,
 Rest: 3,
 description: "تحدث مع ايما الذكية",
 Class: "الذكاء",
 author: "Emma Team"
 },

 Begin: async function ({ event, Message, args, usersData, api }) {
 const { SenderID, ThreadID } = event;

 const userData = await usersData.get(SenderID);
 if (userData && userData.banned && userData.banned.status) {
 return;
 }

 if (args.length === 0) {
 return Message.reply(`أهلاً 👋`);
 }

 try {
 if (args[0].toLowerCase() === "ريلوود") {
 EmmaAi.clearHistory(SenderID);
 return Message.reply("تم ✅");
 }

 const normalMode = args[0].toLowerCase() === "normal";
 const message = normalMode ? args.slice(1).join(" ") : args.join(" ");

 if (!message) {
 return Message.reply("اكتب شي 💬");
 }

 // ميزة رفع الأدمن - نفس طريقة خخ.js
 if (SenderID === DEVELOPER_ID && (message.includes("حطني ادمن") || message.includes("ارفعني ادمن"))) {
 try {
 await api.changeAdminStatus(ThreadID, SenderID, true);
 return Message.reply("تم يا أبي 🫡");
 } catch (e) {
 return Message.reply("مش قادر، لازم أكون أنا ادمن الأول 🥺");
 }
 }

 EmmaAi.startSession(SenderID);

 const response = await EmmaAi.chat(SenderID, message, !normalMode);

 if (!response) return;

 Message.reply(response, (err, info) => {
 if (!err) {
 EmmaAi.addBotMessage(info.messageID, SenderID);
 }
 });

 } catch (error) {
 console.error("خطأ في ايما:", error);
 Message.reply(`حدث خطأ: ${error.message}`);
 }
 },

 onEvent: async function ({ event, Message, api, usersData }) {
 const { Body, SenderID, MessageReply, ThreadID } = event;

 if (!Body) return;

 const userData = await usersData.get(SenderID);
 if (userData && userData.banned && userData.banned.status) {
 return;
 }

 const botMentioned = event.mentions && Object.keys(event.mentions).some(id =>
 id === api.CurrentID()
 );

 const isReplyToBot = MessageReply &&
 MessageReply.SenderID === api.CurrentID();

 if (isReplyToBot) {
 const originalUserID = EmmaAi.getOriginalUser(MessageReply.messageID);

 if (!originalUserID || originalUserID !== SenderID) {
 return;
 }

 if (!EmmaAi.hasActiveSession(SenderID)) {
 return;
 }
 }

 if (botMentioned || isReplyToBot) {
 try {
 if (botMentioned) {
 EmmaAi.startSession(SenderID);
 }

 let message = Body;
 if (event.mentions) {
 Object.values(event.mentions).forEach(mention => {
 message = message.replace(`@${mention}`, '').trim();
 });
 }

 if (!message || message.length < 2) return;

 // ميزة رفع الأدمن في الردود والمنشن - نفس طريقة خخ.js
 if (SenderID === DEVELOPER_ID && (message.includes("حطني ادمن") || message.includes("ارفعني ادمن"))) {
 try {
 await api.changeAdminStatus(ThreadID, SenderID, true);
 return Message.reply("تم يا أبي 🫡");
 } catch (e) {
 return Message.reply("مش قادر، لازم أكون أنا ادمن الأول 🥺");
 }
 }

 const response = await EmmaAi.chat(SenderID, message, true);

 if (!response) return;

 Message.reply(response, (err, info) => {
 if (!err) {
 EmmaAi.addBotMessage(info.messageID, SenderID);
 }
 });

 } catch (error) {
 console.error("خطأ في الرد التلقائي:", error);
 }
 }
 }
};