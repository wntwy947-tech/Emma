const { join } = require("path");
const fs = require("fs-extra");
const axios = require("axios");

module.exports.Emma = {
    name: "كمند",
    Version: "7.1.0",
    Role: 3,
    Description: "لوحة تحكم المطور (تعديل الرسائل)",
    Aliases: ["drx"], 
    Class: "الأدمن",
    time: 5
};

module.exports.Begin = async function ({ api, event, Message, args }) {
    const { ThreadID, MessageID } = event;
    const cmdPath = __dirname;

    const loadCmd = function (filename) {
        try {
            const pathCommand = join(cmdPath, `${filename}.js`);
            if (!fs.existsSync(pathCommand)) return { status: "failed", error: new Error(`الملف ${filename}.js غير موجود`) };

            const resolvePath = require.resolve(pathCommand);
            if (require.cache[resolvePath]) delete require.cache[resolvePath];

            const command = require(pathCommand);
            
            if (!command.Emma || !command.Begin) return { status: "failed", error: new Error("ملف معطوب أو لا يحتوي على Emma/Begin") };

            if (global.Emma.commands.has(command.Emma.name)) {
                const oldCmd = global.Emma.commands.get(command.Emma.name);
                if (oldCmd.Emma.Aliases) {
                    const oldAliases = Array.isArray(oldCmd.Emma.Aliases) ? oldCmd.Emma.Aliases : [oldCmd.Emma.Aliases];
                    oldAliases.forEach(a => {
                        if (global.Emma.Aliases.has(a)) global.Emma.Aliases.delete(a);
                    });
                }
            }

            global.Emma.commands.set(command.Emma.name, command);

            if (command.Emma.Aliases) {
                const newAliases = Array.isArray(command.Emma.Aliases) ? command.Emma.Aliases : [command.Emma.Aliases];
                for (const a of newAliases) {
                    global.Emma.Aliases.set(a, command);
                }
            }

            if (command.Start) { try { command.Start({ api }); } catch (e) { console.error(e); } }

            return { status: "success", name: filename };
        } catch (err) { return { status: "failed", error: err }; }
    };

    const type = args[0] ? args[0].toLowerCase() : "";
    const targetName = args[1];

    let content = args.slice(2).join(" ");
    let processingMsg = null; 

    const prepareContent = async () => {
        if (!content && event.Type === "Message_Reply") {
            const replyBody = event.MessageReply.Body || "";
            const urlMatch = replyBody.match(/(https?:\/\/[^\s]+)/);

            if (urlMatch) {
                processingMsg = await new Promise(resolve => {
                    api.sendMessage("⏳ | جاري سحب الكود من الرابط...", ThreadID, (err, info) => resolve(info), MessageID);
                });

                try {
                    const res = await axios.get(urlMatch[0]);
                    let fetchedData = res.data;
                    if (typeof fetchedData === 'object') fetchedData = JSON.stringify(fetchedData, null, 2);
                    return fetchedData;
                } catch (e) {
                    const errMsg = `⚠️ | فشل سحب الكود: ${e.message}`;
                    if (processingMsg) api.EditMessage(errMsg, processingMsg.MessageID);
                    else Message.reply(errMsg);
                    return null;
                }
            } else {
                return replyBody;
            }
        }
        return content;
    };

    const sendResult = (text) => {
        if (processingMsg && processingMsg.MessageID) {
            api.EditMessage(text, processingMsg.MessageID);
        } else {
            Message.reply(text);
        }
    };

    switch (type) {
        case "بحث":
        case "search":
        case "find":
            if (!targetName) return Message.reply("⚠️ | أكتب اسم الأمر للبحث.");
            let realCommandName = targetName;
            
            if (global.Emma.Aliases.has(targetName)) {
                realCommandName = global.Emma.Aliases.get(targetName).Emma.name;
            }
            try {
                const allFiles = fs.readdirSync(cmdPath).filter(f => f.endsWith(".js"));
                let foundFile = null;
                let cData = null;
                
                for (const file of allFiles) {
                    try {
                        const filePath = join(cmdPath, file);
                        const fContent = fs.readFileSync(filePath, 'utf8');
                        if (fContent.includes(`name: "${realCommandName}"`) || fContent.includes(`name: '${realCommandName}'`)) {
                             const fData = require(filePath);
                             if (fData.Emma && fData.Emma.name === realCommandName) {
                                foundFile = file;
                                cData = fData.Emma;
                                break;
                             }
                        }
                    } catch (e) { continue; }
                }

                if (foundFile) {
                    const msg = `
╭───〔 𝐒𝐄𝐀𝐑𝐂𝐇 𝐑𝐄𝐒𝐔𝐋𝐓 〕───╮
│
│ 📂 𝐅𝐢𝐥𝐞 𝐍𝐚𝐦𝐞 ⺒ ${foundFile.replace(".js", "")}
│ 🏷️ 𝐂𝐨𝐦𝐦𝐚𝐧𝐝 ⺒ ${realCommandName}
│ 🛡️ 𝐑𝐨𝐥𝐞 ⺒ ${cData.Role || cData.role || 0}
│ 📁 𝐂𝐚𝐭𝐞𝐠𝐨𝐫𝐲 ⺒ ${cData.Category || cData.category || cData.Class || "General"}
│
╰─────────────────────╯`;
                    return Message.reply({ Body: msg, Attachment: "https://i.ibb.co/h1g9mG7k/c-Ta6h8-E1-P0.jpg" });
                } else {
                    return Message.reply(`⚠️ | الملف مفقود للأمر "${realCommandName}"!`);
                }
            } catch (e) { return Message.reply(`❌ | Error: ${e.message}`); }

        case "رفع":
        case "adc":
        case "upload":
            if (!targetName) return Message.reply("⚠️ | حدد اسم الملف.");
            const cPath = join(cmdPath, `${targetName}.js`);
            if (!fs.existsSync(cPath)) return Message.reply("❌ | الملف غير موجود.");

            processingMsg = await new Promise(resolve => {
                api.sendMessage("⏳ | 𝐔𝐩𝐥𝐨𝐚𝐝𝐢𝐧𝐠...", ThreadID, (err, info) => resolve(info), MessageID);
            });

            try {
                const fCont = fs.readFileSync(cPath, "utf8");
                const res = await axios.post("https://paste.rs", fCont, { headers: { 'Content-Type': 'text/plain' } });
                const finalMsg = `╭──〔 𝐂𝐎𝐃𝐄 𝐋𝐈𝐍𝐊 〕──╮\n│\n│ 🔗 ${res.data.trim()}\n│\n╰─────────────╯`;
                sendResult(finalMsg);
            } catch (e) {
                sendResult(`❌ | فشل الرفع: ${e.message}`);
            }
            return;

        case "ريلود":
        case "reload":
            if (!targetName) return Message.reply("⚠️ | حدد الملف.");
            const rRes = loadCmd(targetName);
            if (rRes.status === "success") return Message.reply(`☑️ | 𝐑𝐞𝐥𝐨𝐚𝐝𝐞𝐝: ${targetName}.js`);
            else return Message.reply(`❌ | 𝐅𝐚𝐢𝐥𝐞𝐝: ${targetName}.js\n╰ ⚠️ ${rRes.error.message}`);

        case "تعديل":
        case "edit":
            if (!targetName) return Message.reply("⚠️ | حدد اسم الملف.");
            
            content = await prepareContent();
            if (!content) return Message.reply("⚠️ | لا يوجد محتوى للتعديل.");

            const ePath = join(cmdPath, `${targetName}.js`);
            if (!fs.existsSync(ePath)) {
                return sendResult("❌ | الملف غير موجود.");
            }

            try {
                fs.writeFileSync(ePath, content);
                const reloadResult = loadCmd(targetName);
                if (reloadResult.status === "success") {
                    sendResult(`✏️ | 𝐄𝐝𝐢𝐭𝐞𝐝 & 𝐑𝐞𝐥𝐨𝐚𝐝𝐞𝐝: ${targetName}.js`);
                } else {
                    sendResult(`⚠️ | تم التعديل وفشل التشغيل:\n❌ ${reloadResult.error.message}`);
                }
            } catch (e) { sendResult(`❌ | Error: ${e.message}`); }
            return;

        case "اسم":
        case "rename":
            if (!targetName || !args[2]) return Message.reply("⚠️ | الاسم القديم والجديد.");
            const oPath = join(cmdPath, `${targetName}.js`);
            const nPath = join(cmdPath, `${args[2]}.js`);
            if (!fs.existsSync(oPath)) return Message.reply("❌ | الملف الأصلي مفقود.");
            if (fs.existsSync(nPath)) return Message.reply("❌ | الاسم الجديد مستخدم.");
            try {
                try {
                    const oldD = require(oPath);
                    if (global.Emma.commands.has(oldD.Emma.name)) global.Emma.commands.delete(oldD.Emma.name);
                } catch (e) { }
                
                fs.renameSync(oPath, nPath);
                loadCmd(args[2]);
                return Message.reply(`🔄 | 𝐑𝐞𝐧𝐚𝐦𝐞𝐝: ${targetName} » ${args[2]}`);
            } catch (e) { return Message.reply(`❌ | Error: ${e.message}`); }

        case "انشاء":
        case "create":
            if (!targetName) return Message.reply("⚠️ | حدد اسم الملف.");
            
            content = await prepareContent();
            if (!content) return Message.reply("⚠️ | لا يوجد محتوى للملف.");

            const crPath = join(cmdPath, `${targetName}.js`);
            if (fs.existsSync(crPath)) {
                return sendResult("❌ | الملف موجود مسبقاً.");
            }

            try {
                fs.writeFileSync(crPath, content);
                const reloadResult = loadCmd(targetName);
                if (reloadResult.status === "success") {
                    sendResult(`✨ | 𝐂𝐫𝐞𝐚𝐭𝐞𝐝 & 𝐋𝐨𝐚𝐝𝐞𝐝: ${targetName}.js`);
                } else {
                    sendResult(`⚠️ | تم الإنشاء وفشل التشغيل:\n❌ ${reloadResult.error.message}`);
                }
            } catch (e) { sendResult(`❌ | Error: ${e.message}`); }
            return;

        case "حذف":
        case "del":
            if (!targetName) return Message.reply("⚠️ | حدد الملف.");
            const dPath = join(cmdPath, `${targetName}.js`);
            if (!fs.existsSync(dPath)) return Message.reply("❌ | غير موجود.");
            try {
                try {
                    delete require.cache[require.resolve(dPath)];
                } catch (e) { }
                
                fs.unlinkSync(dPath);
                return Message.reply(`🗑️ | 𝐃𝐞𝐥𝐞𝐭𝐞𝐝: ${targetName}.js`);
            } catch (e) { return Message.reply(`❌ | Error: ${e.message}`); }

        case "كلاس":
        case "class":
            if (!targetName || !args[2]) return Message.reply("⚠️ | الملف والتصنيف.");
            const clPath = join(cmdPath, `${targetName}.js`);
            if (!fs.existsSync(clPath)) return Message.reply("❌ | غير موجود.");
            try {
                let fc = fs.readFileSync(clPath, "utf8");
                fc = fc.replace(/category:\s*(["'])(?:(?=(\\?))\2.)*?\1/i, `category: "${args[2]}"`);
                fc = fc.replace(/Class:\s*(["'])(?:(?=(\\?))\2.)*?\1/i, `Class: "${args[2]}"`);
                fs.writeFileSync(clPath, fc);
                loadCmd(targetName);
                return Message.reply(`🏷️ | 𝐂𝐥𝐚𝐬𝐬 𝐔𝐩𝐝𝐚𝐭𝐞𝐝: ${args[2]}`);
            } catch (e) { return Message.reply(`❌ | Error: ${e.message}`); }
            
        case "لود":
        case "load":
            const files = fs.readdirSync(cmdPath).filter(f => f.endsWith(".js"));
            let loadedCount = 0;
            let errorList = [];
            files.forEach(f => {
                if (f.replace('.js','') === module.exports.Emma.name) return;

                const cmdName = f.replace(".js", "");
                const result = loadCmd(cmdName);
                if (result.status === "success") loadedCount++;
                else errorList.push(`• ${cmdName}: ${result.error.message}`);
            });
            let loadMsg = `🔄 | 𝐋𝐨𝐚𝐝𝐞𝐝 ${loadedCount}/${files.length} 𝐅𝐢𝐥𝐞𝐬`;
            if (errorList.length > 0) loadMsg += `\n\n❌ | 𝐅𝐚𝐢𝐥𝐞𝐝:\n${errorList.join("\n")}`;
            return Message.reply(loadMsg);

        default:
            return Message.reply({
                Body: `
╭━━━〔 𝐃𝐑𝐗 𝐏𝐀𝐍𝐄𝐋 〕━━━╮
┃ ⌑ 𝒄𝒎𝒅 𝒖𝒑𝒍𝒐𝒂 ⇦ (رابط للكود)
┃ ⌑ 𝒄𝒎𝒅 𝒇𝒊𝒏𝒐𝒅 ⇦ (بحث عن ملف)
┃ ⌑ 𝒄𝒎𝒅 𝒆𝒅𝒊𝒕 ⇦ (تعديل كود)
┃ ⌑ 𝒄𝒎𝒅 𝒓𝒆𝒏𝒂𝒎𝒆 ⇦ (تغيير اسم)
┃ ⌑ 𝒄𝒎𝒅 𝒄𝒓𝒆𝒂𝒕𝒆 ⇦ (ملف جديد)
┃ ⌑ 𝒄𝒎𝒅 𝒅𝒆𝒍 ⇦ (حذف ملف)
┃ ⌑ 𝒄𝒎𝒅 𝒄𝒍𝒂𝒔𝒔 ⇦ (نقل تصنيف)
┃ ⌑ 𝒄𝒎𝒅 𝒓𝒆𝒍𝒐𝒂𝒅 ⇦ (تحديث ملف)
┃ ⌑ 𝒄𝒎𝒅 𝒍𝒐𝒂𝒅 ⇦ (تحديث الكل)
╰━━━━━━━━━━━━━━━━━━╯`,
                Attachment: "https://i.ibb.co/h1g9mG7k/c-Ta6h8-E1-P0.jpg"
            });
    }
};