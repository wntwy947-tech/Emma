function GetActions(ActionCode) {
  const ActionsMap = {
    us1: "upsample_subtle",
    us2: "upsample_creative",
    lv: "low_variation",
    hv: "high_variation",
    zo2: "zoom_out_2x",
    "zo1.5": "zoom_out_1_5x",
    sq: "square",
    pl: "pan_left",
    pr: "pan_right",
    pu: "pan_up",
    pd: "pan_down",
    u1: "upsample1",
    u2: "upsample2",
    u3: "upsample3",
    u4: "upsample4",
    "🔁": "reroll",
    v1: "variation1",
    v2: "variation2",
    v3: "variation3",
    v4: "variation4",
  };
  return ActionsMap[ActionCode];
}

function MapActions(ActionsArray) {
  const Codes = {
    upsample_subtle: "us1",
    redo_upsample_subtle: "us1",
    redo_upsample_creative: "us2",
    upsample_creative: "us2",
    low_variation: "lv",
    high_variation: "hv",
    zoom_out_2x: "zo2",
    zoom_out_1_5x: "zo1.5",
    square: "sq",
    pan_left: "pl",
    pan_right: "pr",
    pan_up: "pu",
    pan_down: "pd",
    upsample1: "u1",
    upsample2: "u2",
    upsample3: "u3",
    upsample4: "u4",
    reroll: "🔁",
    variation1: "v1",
    variation2: "v2",
    variation3: "v3",
    variation4: "v4",
  };
  return ActionsArray.map(a => Codes[a]).filter(Boolean);
}

module.exports = {
  Emma: {
    name: "ميدجورني",
    Aliases: ["dj", "mj"],
    Version: "1.0",
    Author: "Shady Tarek",
    Class: "الذكاء",
    Role: 0,
    Rest: 5,
  },

  languages: {
    Ar: {
      ProvideText: "⚠️ | يرجى تقديم نص لإنشاءه",
      Done: "✅ | تم الانتهاء بنجاح ✨\n\nاختار:\n %1",
      TooLong: "⚠️ | اخذ الانشاء الكثير من الوقت تم الغائه",
      IncorrectOption: "⚠️ | اختيار خاطئ اختار بين %1.",
      Processing: "⚠️ | جاري تعديل الصورة انتظر...",
      Action: "✅ | تم تعديل الصورة : %1\nتعديلات اخرى:\n %2",
      Failed: "❌ | فشل في العملية",
    },
    En: {
      ProvideText: "⚠️ | Please provide text to create",
      Done: "✅ | Successfully completed ✨\n\nChoose:\n %1",
      TooLong: "⚠️ | Creation took too long, it was canceled",
      IncorrectOption: "⚠️ | Incorrect option, choose between %1.",
      Processing: "⚠️ | Processing the image, please wait...",
      Action: "✅ | Current Action: %1\nOther Actions:\n %2",
      Failed: "❌ | Failed to process",
    },
  },

  Begin: async function ({ args, Message, event, getLang: GetLang }) {
    Message.react("⚙️");

    let prompt = args.join(" ");

    if (
      event.Type === "Message_Reply" &&
      event.MessageReply?.Attachments?.[0] &&
      ["Photo", "Sticker"].includes(event.MessageReply.Attachments[0].Type)
    ) {
      const imageUrl = event.MessageReply.Attachments[0].Url;
      const imgbbUrl = await Funcs.Upload(imageUrl);
      prompt = `${prompt} --sref ${imgbbUrl}`;
    }

    if (!prompt) {
      return Message.reply(GetLang("ProvideText"));
    }

    try {
      const MJ = new Funcs.MidJourney();
      const image = await MJ.Generate(prompt);
      if (!image?.image_id) return Message.react("❌");

      const Actions = MapActions(image.actions);
      const Options = Actions.map(a => a.toUpperCase()).join(", ");

      Message.reply(
        {
          Body: GetLang("Done", Options),
          Attachment: image.raw_image_url,
        },
        (err, info) => {
          global.Emma.onReply.set(info.MessageID, {
            name: "ميدجورني",
            MessageID: info.MessageID,
            Author: event.SenderID,
            ImageID: image.image_id,
            Actions: image.actions,
          });
        }
      );

      Message.react("✔️");
    } catch (e) {
      console.log(e);
      Message.react("❌");
    }
  },

  onReply: async function ({ Message, event, onReply, getLang: GetLang }) {
    if (event.SenderID !== onReply.Author) return;

    const userInput = event.Body.trim().toLowerCase();
    const validOptions = MapActions(onReply.Actions);

    if (!validOptions.includes(userInput)) {
      return Message.reply(
        GetLang(
          "IncorrectOption",
          validOptions.map(v => v.toUpperCase()).join(", ")
        )
      );
    }

    try {
      Message.react("⚙️");
      await Message.reply(GetLang("Processing"));

      const MJ = new Funcs.MidJourney();
      const Image = await MJ.Action({
        action: GetActions(userInput),
        image_id: onReply.ImageID,
      });

      const NewOptions = MapActions(Image.actions).map(o =>
        o.toUpperCase()
      );

      const info = await Message.reply({
        Body: GetLang(
          "Action",
          userInput.toUpperCase(),
          NewOptions.join(", ")
        ),
        Attachment: Image.raw_image_url,
      });

      Message.react("✔️");

      global.Emma.onReply.set(info.MessageID, {
        name: "ميدجورني",
        Author: event.SenderID,
        MessageID: info.MessageID,
        ImageID: Image.image_id,
        Actions: Image.actions,
      });
    } catch (e) {
      console.log(e);
      Message.react("❌");
      Message.reply(GetLang("Failed"));
    }
  },
};
