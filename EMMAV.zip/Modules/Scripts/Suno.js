const axios = require("axios");

module.exports = {
  Emma: {
    name: "لسونو",
    Author: "Shady Tarek",
    Role: 0,
    Rest: 5,
    Description: "",
    Class: "الذكاء",
  },

  languages: {
    En: {
      Welcome:
        "🏫 | Welcome To The Song Library. Reply With 1 To Use The Prompt Or 2 For Custom Mode.",
      EnterP: "🏫 | Enter Your Prompt",
      EnterL: "🏫 | Enter Your Full Lyrics",
      EnterS: "🏫 | Enter Song Styles",
      EnterT: "🏫 | Enter Song Title",
      Choose: "🏫 | Choose One Of The Two Songs: 1 Or 2",
      Type: "🏫 | Reply With 1 For Song Or 2 For Video",
      OnlyAdmin: "🏫 | Only Admin Can Perform This Command",
    },
    Ar: {
      Welcome:
        "🏫 | مرحبا بك في مكتبة الأغاني. رد بـ 1 لاستخدام النص الجاهز أو 2 للوضع المخصص.",
      EnterP: "🏫 | أدخل نصك",
      EnterL: "🏫 | أدخل الكلمات كاملة",
      EnterS: "🏫 | أدخل الستايل",
      EnterT: "🏫 | أدخل العنوان",
      Choose: "🏫 | اختر واحدة من الأغنيتين: 1 أو 2",
      Type: "🏫 | رد بـ 1 لاختيار أغنية أو 2 لاختيار فيديو",
      OnlyAdmin: "🏫 | فقط الأدمن يستطيع طلب الفيديو",
    },
  },

  Begin: async function ({ Message, event, getLang: GetLang }) {
    const info = await Message.reply({
      Body: GetLang("Welcome"),
    });

    global.Emma.onReply.set(info.MessageID, {
      name: "لسونو",
      MessageID: info.MessageID,
      Author: event.SenderID,
      Type: "Welcome",
    });
  },

  onReply: async function ({ Message, event, onReply, getLang: GetLang }) {
    try {
      if (event.SenderID !== onReply.Author) return;

      if (onReply.Type === "Welcome") {
        if (event.Body.includes("1")) {
          const info = await Message.reply({
            Body: GetLang("EnterP"),
          });
          global.Emma.onReply.set(info.MessageID, {
            name: "لسونو",
            MessageID: info.MessageID,
            Author: event.SenderID,
            Type: "Prompt",
          });
        } else if (event.Body.includes("2")) {
          const info = await Message.reply({
            Body: GetLang("EnterL"),
          });
          global.Emma.onReply.set(info.MessageID, {
            name: "لسونو",
            MessageID: info.MessageID,
            Author: event.SenderID,
            Type: "Lyrics",
          });
        }
      }

      if (onReply.Type === "Prompt") {
        await Message.React("⚙️");
        const Suno = new Funcs.Suno();
        const Song = await Suno.MakePrompt(event.Body);
        await Message.React("✔️");

        const info = await Message.reply({
          Body: GetLang("Choose"),
          Attachment: [
            await Funcs.getStreamFromURL(Song[0].Image),
            await Funcs.getStreamFromURL(Song[1].Image),
          ],
        });

        global.Emma.onReply.set(info.MessageID, {
          name: "لسونو",
          MessageID: info.MessageID,
          Author: event.SenderID,
          Song,
          Type: "Choose",
        });
      }

      if (onReply.Type === "Lyrics") {
        await Message.React("⚙️");
        const info = await Message.reply({
          Body: GetLang("EnterS"),
        });
        global.Emma.onReply.set(info.MessageID, {
          name: "لسونو",
          MessageID: info.MessageID,
          Author: event.SenderID,
          Lyrics: event.Body,
          Type: "Style",
        });
      }

      if (onReply.Type === "Style") {
        const info = await Message.reply({
          Body: GetLang("EnterT"),
        });
        global.Emma.onReply.set(info.MessageID, {
          name: "لسونو",
          MessageID: info.MessageID,
          Author: event.SenderID,
          Style: event.Body,
          Lyrics: onReply.Lyrics,
          Type: "Title",
        });
      }

      if (onReply.Type === "Title") {
        await Message.React("⚙️");
        const Suno = new Funcs.Suno();
        const Song = await Suno.MakeSong(
          onReply.Lyrics,
          onReply.Style,
          event.Body
        );
        await Message.React("✔️");

        const info = await Message.reply({
          Body: GetLang("Choose"),
          Attachment: [
            await Funcs.getStreamFromURL(Song[0].Image),
            await Funcs.getStreamFromURL(Song[1].Image),
          ],
        });

        global.Emma.onReply.set(info.MessageID, {
          name: "لسونو",
          MessageID: info.MessageID,
          Author: event.SenderID,
          Song,
          Type: "Choose",
        });
      }

      if (onReply.Type === "Choose") {
        const choice = event.Body.includes("2") ? 1 : 0;
        const info = await Message.reply({
          Body: GetLang("Type"),
        });
        global.Emma.onReply.set(info.MessageID, {
          name: "لسونو",
          MessageID: info.MessageID,
          Author: event.SenderID,
          Song: onReply.Song,
          Choice: choice,
          Type: "Type",
        });
      }

      if (onReply.Type === "Type") {
        if (event.Body.includes("1")) {
          await Message.reply({
            Body: onReply.Song[onReply.Choice].Lyrics,
          });
          const Stream = await Funcs.getStreamFromURL(
            onReply.Song[onReply.Choice].Audio
          );
          await Message.reply({
            Attachment: Stream,
          });
        }
      }
    } catch (e) {
      console.log(e)
      Message.React("❌");
    }
  },
};
