const moment = require("moment-timezone");

module.exports = {

  Emma: {
    name: "لنانو",
    Version: "1.0",
    Author: "Shady Tarek",
    Rest: 30,
    Role: 0,
    Description: "",
    Class: "الذكاء",
  },

  Begin: async function ({ event, args, Message, usersData }) {
    try {

      function GetRatio(ratio) {
        const [width, height] = ratio.split(":").map(Number);
        return { width, height };
      }

      let Final = [];

      const txt = args.join(" ");
      const Prompt = txt.split("--ar")[0];

      if (!Prompt) {
        return Message.reply("⚠️ | الرجاء كتابة وصف للصورة");
      }

      const Supported = [
        "21:9",
        "16:9",
        "4:3",
        "3:2",
        "1:1",
        "2:3",
        "3:4",
        "9:16",
        "9:21",
      ];

      const ratio =
        args.find((arg) => Supported.includes(arg)) || "1:1";

      const TP = await Funcs.translate(Prompt, "ar", "en");

      const startTime = new Date();
      Message.react("⚙️");

      const Editor = new Funcs.NanoBanana();
      const Rate = GetRatio(ratio);

      const Ai = await Editor.Gen(
        TP,
        Rate.width,
        Rate.height
      );

      for (const Image of Ai.images) {
        Final.push(Image.url);
      }

      const endTime = new Date();
      const SenderID = event.SenderID;
      const userName =
        (await usersData.getName(SenderID)) || "مستخدم فيسبوك";

      const drawingTime = (endTime - startTime) / 1000;

      const currentDate = moment
        .tz("Africa/Cairo")
        .format("YYYY-MM-DD");
      const currentTime = moment
        .tz("Africa/Cairo")
        .format("h:mm:ss A");

      Message.react("✔️");
      Message.reply({
        Body: `✅ | تم الانتهاء من الصورة
⌯︙بواسطة -› ${userName}
⌯︙استغرق -› ${drawingTime} 🧭
⌯︙الوقت -› ${currentTime} ⌚
⌯︙التاريخ -› ${currentDate} 📚`,
        Attachment: Final,
      });

    } catch (error) {
      console.log(error);
      Message.react("❌");
      Message.reply("❌ | حدث خطأ أثناء تحويل الصورة");
    }
  },
};
