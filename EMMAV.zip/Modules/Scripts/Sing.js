const Youtube = require("youtube-search-api");

const Mp3 = async link => {
  const Data = await Funcs.YouTube(link, "128K");
  const Stream = await Funcs.getStreamFromURL(Data.fileUrl, "mp3");
  return {
    Stream,
    Title: Data.title,
    Duration: Data.duration,
  };
};

module.exports = {
  Emma: {
    name: "لشغلي",
    Author: "Shady Tarek",
    Rest: 10,
    Description: "Perhaps listening to music on messenger?",
    Role: 0,
    Class: "خدمات",
  },

  Begin: async function ({ Message, event, args }) {
    if (!args || !args.length) {
      return Message.reply({
        Body: "⚠️︙ Type Something",
      });
    }

    const keywordSearch = args.join(" ");

    if (keywordSearch.startsWith("https://youtu")) {
      const data = await Mp3(keywordSearch);
      return Message.reply({
        Body: `🎵 Title: ${data.Title}\n ⌛ Duration: ${data.Duration}s`,
        Attachment: data.Stream,
      });
    }

    const link = [];
    let msg = "";
    let num = 0;

    const data = (await Youtube.GetListByKeyword(keywordSearch, false, 20)).items;

    for (const value of data) {
      if (!value?.length?.simpleText) continue;
      link.push(value.id);
      num++;
      msg += `${num} - ${value.title} (${value.length.simpleText})\n\n`;
    }

    await Message.React("❔");

    const info = await Message.reply({
      Body: `🔎︙ I Found ${link.length} Search Results:\n\n${msg}\n⚠️︙Just Reply With A Number`,
    });

    global.Emma.onReply.set(info.MessageID, {
      name: 'لشغلي',
      type: "reply",
      MessageID: info.MessageID,
      Author: event.SenderID,
      link,
    });
  },

  onReply: async function ({ Message, event, Reply }) {
    if (Reply.Author !== event.SenderID) return;
    if (Reply.type !== "reply") return;

    try {
      await Message.React("⚙️");

      const index = parseInt(event.Body) - 1;
      if (isNaN(index) || !Reply.link[index]) return;

      const data = await Mp3("https://youtu.be/" + Reply.link[index]);

      await Message.React("✅");

      Message.reply({
        Body: `🎵 Title: ${data.Title}\n ⌛ Duration: ${data.Duration}s`,
        Attachment: data.Stream,
      });
    } catch (e) {
      Message.React("❌");
    }
  },
};
