const cloudscraper = require("cloudscraper");
const { CookieJar } = require("tough-cookie");

class Aki {
  constructor() {
    this.jar = new CookieJar();

    this.baseHeaders = {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Accept":
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
      "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
      "Accept-Encoding": "gzip, deflate, br",
      "Connection": "keep-alive",
      "Upgrade-Insecure-Requests": "1"
    };

    this.xhrHeaders = {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Accept": "application/json, text/javascript, */*; q=0.01",
      "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
      "Accept-Encoding": "gzip, deflate, br",
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "X-Requested-With": "XMLHttpRequest",
      "Origin": "https://ar.akinator.com",
      "Referer": "https://ar.akinator.com/game",
      "Connection": "keep-alive",
      "Sec-Fetch-Site": "same-origin",
      "Sec-Fetch-Mode": "cors",
      "Sec-Fetch-Dest": "empty"
    };
  }

  async CloudFlare(url, options = {}, maxRetries = 20) {
    let attempt = 0;

    while (attempt < maxRetries) {
      try {
        const res = await cloudscraper({
          uri: url,
          method: options.method || "GET",
          headers: options.headers,
          body: options.body,
          jar: this.jar,
          gzip: true,
          resolveWithFullResponse: true
        });

        if (res.statusCode !== 403) {
          return res;
        }
      } catch (err) {
        if (err.statusCode !== 403) {
          throw err;
        }
      }

      attempt++;
      await new Promise(r => setTimeout(r, 500));
    }

    return null;
  }

  async NewGame() {
    try {
      const res = await this.CloudFlare("https://ar.akinator.com/game", {
        method: "POST",
        headers: {
          ...this.baseHeaders,
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: new URLSearchParams({
          sid: "1",
          cm: "false"
        }).toString()
      });

      if (!res) return null;

      const text = res.body;

      const question = text.match(
        /<p class="question-text" id="question-label">(.+?)<\/p>/
      )?.[1];

      const session = text.match(/session: '(.+?)'/)?.[1];
      const signature = text.match(/signature: '(.+?)'/)?.[1];

      if (!question || !session || !signature) return null;

      return {
        question,
        si: session,
        co: signature,
        progression: "0.0000",
        step: "0"
      };
    } catch {
      return null;
    }
  }

  async NextGame(si, co, answer, progression, step) {
    try {
      const res = await this.CloudFlare("https://ar.akinator.com/answer", {
        method: "POST",
        headers: this.xhrHeaders,
        body: new URLSearchParams({
          step,
          progression,
          sid: "NaN",
          cm: "false",
          answer,
          step_last_proposition: "",
          session: si,
          signature: co
        }).toString()
      });

      if (!res) return null;

      return JSON.parse(res.body);
    } catch {
      return null;
    }
  }

  async BackGame(si, co, progression, step) {
    try {
      const res = await this.CloudFlare("https://ar.akinator.com/cancel_answer", {
        method: "POST",
        headers: this.xhrHeaders,
        body: new URLSearchParams({
          step,
          progression,
          sid: "NaN",
          cm: "false",
          session: si,
          signature: co
        }).toString()
      });

      if (!res) return null;

      return JSON.parse(res.body);
    } catch {
      return null;
    }
  }

  async ContinueGame(si, co, progression, step, forward_answer = "1") {
    try {
      const res = await this.CloudFlare("https://ar.akinator.com/exclude", {
        method: "POST",
        headers: this.xhrHeaders,
        body: new URLSearchParams({
          step,
          sid: "",
          cm: "false",
          progression,
          session: si,
          signature: co,
          forward_answer
        }).toString()
      });

      if (!res) return null;

      return JSON.parse(res.body);
    } catch {
      return null;
    }
  }
}

module.exports = {
  Emma: {
    name: "اكيناتور",
    Aliases: ["aki"],
    Author: "Shady Tarek",
    Role: 0,
    Rest: 5,
    Description: "حزر الشخص الذي في بالك",
    Class: "الألعاب",
  },

  Begin: async function ({ event, Message }) {
    try {
      const Akinator = new Aki();
      const game = await Akinator.NewGame();
      if (!game) return;

      Message.reply({ Body: `🧞 | ${game.question}` }, (err, info) => {
        global.Emma.onReply.set(info.MessageID, {
          name: "اكيناتور",
          Author: event.SenderID,
          MessageID: info.MessageID,
          ...game,
        });
      });
    } catch { }
  },

  onReply: async function ({ event, Reply, Message }) {
    try {
      const Akinator = new Aki();
      if (event.SenderID !== Reply.Author)
        return Message.reply("⚠️ | مش دورك");

      let answer;
      switch (event.Body) {
        case "نعم": answer = "0"; break;
        case "لا": answer = "1"; break;
        case "لا اعلم": answer = "2"; break;
        case "من الممكن": answer = "3"; break;
        case "الضاهر لا": answer = "4"; break;
        case "رجوع": answer = "e"; break;
        default:
          return Message.reply(
            "⚠️ | الرد يكون:\nنعم | لا | لا اعلم | رجوع | من الممكن | الضاهر لا"
          );
      }

      const result =
        answer === "e"
          ? await Akinator.BackGame(
            Reply.si,
            Reply.co,
            Reply.progression,
            Reply.step
          )
          : await Akinator.NextGame(
            Reply.si,
            Reply.co,
            answer,
            Reply.progression,
            Reply.step
          );

      if (result?.name_proposition) {
        const img = await Funcs.getStreamFromURL(result.photo);
        return Message.reply(
          {
            Body: `🧞 | اسم الشخصية : ${result.name_proposition}\n\n🧞 | نبذة : ${result.description_proposition}`,
            Attachment: img,
          },
          (e, info) => {
            global.Emma.onReply.set(info.MessageID, {
              name: "اكيناتور",
              Author: event.SenderID,
              MessageID: info.MessageID,
              ...Reply,
              Done: true,
            });
          }
        );
      }

      Message.reply({ Body: `🧞 | ${result.question}` }, (e, info) => {
        global.Emma.onReply.set(info.MessageID, {
          name: "اكيناتور",
          Author: event.SenderID,
          MessageID: info.MessageID,
          progression: result.progression,
          si: Reply.si,
          co: Reply.co,
          step: result.step,
        });
      });
    } catch { }
  },
};
