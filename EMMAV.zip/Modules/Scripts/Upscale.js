const axios = require("axios");
const FormData = require("form-data");
const crypto = require("crypto");


module.exports = {
  Emma: {
    name: "توضيح",
    Aliases: ["iv"],
    Version: "1.0",
    Author: "Shady Tarek",
    Rest: 30,
    Role: 0,
    Description: "",
    Class: "الذكاء",
  },

  languages: {
    Ar: {
      ReplyWithImage: "⚠️ | رد على صورة أو مجموعة صور",
      Processing: "⚙️ | جاري معالجة الصور...",
      Success: "✅ | تم رفع جودة الصور بنجاح",
      Error: "❌ | حدث خطأ أثناء رفع جودة الصور",
    },
    En: {
      ReplyWithImage: "⚠️ | Reply with images",
      Processing: "⚙️ | Processing images...",
      Success: "✅ | Successfully enhanced the image quality",
      Error: "❌ | An error occurred while enhancing the image quality",
    },
  },

  Begin: async function ({ event, Message, getLang: GetLang }) {
    try {
      if (!event?.MessageReply?.Attachments?.[0]) {
        return Message.reply(GetLang("ReplyWithImage"));
      }

      const imageUrls = [];
      for (const I of event.MessageReply.Attachments) {
        if (I.Type?.includes("Photo")) {
          imageUrls.push(I.Url);
        }
      }

      Message.react("⚙️");
      const processingMessage = await Message.reply(
        GetLang("Processing")
      );

      const Images = [];
      for (const url of imageUrls) {
        Images.push(await Funcs.Upscale(url));
      }

      Message.react("✔️");
      Message.unsend(processingMessage.MessageID);

      Message.reply({
        Body: GetLang("Success"),
        Attachment: Images,
      });
    } catch (error) {
      console.log(error);
      Message.react("❌");
      Message.reply(GetLang("Error"));
    }
  },
};
