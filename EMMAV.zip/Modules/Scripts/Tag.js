module.exports = {
  Emma: {
    name: "تاغ",
    Aliases: ["tagall"],
    Author: "Shady Tarek",
    Role: 1,
    Rest: 80,
    Description: "",
    Class: "ثريدز",
  },

  Begin: async function ({ api, event, args }) {
    try {
      const botID = api.CurrentID();

      const listUserID = event.ParticipantIDs.filter(
        (id) => id !== botID && id !== event.SenderID
      );

      let Body =
        args.length !== 0
          ? args.join(" ")
          : "تعالو";

      let Mentions = [];
      let index = 0;

      for (const idUser of listUserID) {
        Body = "‎" + Body;
        Mentions.push({
          id: idUser,
          tag: "‎",
          fromIndex: index - 1,
        });
        index -= 1;
      }

      return api.SendMessage(
        { Body, Mentions },
        event.ThreadID,
        event.MessageID
      );
    } catch (e) { }
  },
};
