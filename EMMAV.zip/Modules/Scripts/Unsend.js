module.exports.Emma = {
  name: "احذف",
  Aliases: ["حذف", "مسح"],
  Role: 1,
  Class: "ثريدز",
  Rest: 0
};



module.exports.Begin = function ({ api, event }) {
  if (event && event.MessageReply && event.MessageReply?.SenderID != api.CurrentID()) return api.SendMessage("كيف يعني بدك اهكر حسابو عشان احذف الرسالة ؟🤨", event.ThreadID, event.MessageID);
  if (!event.MessageReply) return api.SendMessage("رد ع وسالة لبدك تحذف", event.ThreadID, event.MessageID);
  return api.Unsend(event.MessageReply.MessageID);
}