const fs = require("fs");
const path = require("path");

module.exports = {
  Emma: {
    name: "عربي",
    Aliases: ["words"],
    Author: "Shady Tarek",
    Role: 0,
    Rest: 5,
    Description: "لعبة مفرد او جمع",
    Class: "الألعاب",
  },

  Begin: async function ({ Message, event }) {
    try {
      const singularFilePath = path.join(
        __dirname + "/cache/Json/one.json"
      );
      const pluralFilePath = path.join(
        __dirname + "/cache/Json/two.json"
      );

      const singularArray = JSON.parse(
        fs.readFileSync(singularFilePath, "utf-8")
      );
      const pluralArray = JSON.parse(
        fs.readFileSync(pluralFilePath, "utf-8")
      );

      const isSingular = Math.random() < 0.5;

      const randomName = isSingular
        ? singularArray[
        Math.floor(Math.random() * singularArray.length)
        ]
        : pluralArray[
        Math.floor(Math.random() * pluralArray.length)
        ];

      await Message.reply({
        Body: `⌔︙ارسل مفرد او جمع: [ ${randomName} ]`,
      });

      global.Emma.Listen.set(Math.floor(Math.random() * 10000), {
        condition: `event?.Body?.toLowerCase() === "${isSingular ? "مفرد" : "جمع"}"`,
        result: `async () => {
          try {
            Message.react("✅");
            Message.reply("⇜ | " + await usersData.getName(event.SenderID) + "  ألف مبروك 🎉، لقد ارسلت الاجابة الصحيحة للكلمة ؛ - ${randomName}");
             await usersData.addStars(event.SenderID, 1)
          } catch (e) {
          }
        }`,
      });
    } catch (e) {
      Message.React("❌");
    }
  },
};
