module.exports = {
  Emma: {
    name: "توب",
    Aliases: ["topu"],
    Author: "Shady Tarek",
    Role: 0,
    Rest: 5,
    Description: "افضل المتفاعلين",
    Class: "ثريدز",
  },

  Begin: async function ({ usersData, Message }) {
    try {
      await Message.react("🏅");

      const Data = await usersData.getAll();

      const Top = Data.map((user) => ({
        name: user.name,
        stars: user.stars,
      }));

      const FilteredTop = Top.filter((u) => u.stars > 0);

      const SortedTop = FilteredTop
        .sort((a, b) => b.stars - a.stars)
        .slice(0, 10);

      const Result = SortedTop
        .map((user, index) => {
          const rank = index + 1;
          let medal = "🏅";
          if (rank === 1) medal = "🏆";
          else if (rank === 2) medal = "🥈";
          else if (rank === 3) medal = "🥉";

          return (
            `🎖 | الترتيب : 『${medal}』\n` +
            `👥 | الإسم : 『${user.name || "No Name"}』\n` +
            `🔢 | النجوم : 『${user.stars}』 نجمة\n`
          );
        })
        .join("\n");

      await Message.reply(
        `🏆 أعلى المتصدرين 🏆\n\n${Result}\n\n🔄 | يتم تصفير النقاط شهريًا.`
      );
    } catch (e) {
      Message.react("❌");
    }
  },
};
