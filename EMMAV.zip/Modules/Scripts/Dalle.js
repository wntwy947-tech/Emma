const moment = require("moment-timezone");
const OpenAI = require("openai");

module.exports.Emma = {
  name: "دالي",
  Version: "1.0",
  Author: "Shady Tarek",
  Rest: 5,
  Role: 0,
  Description: "",
  Class: "الذكاء"
}

module.exports.languages = {
  Ar: {
    User: "مستخدم فيسبوك",
    ProvideText: "لم تقم بتوفير نص.",
    Done: "✅ | تم تنفيذ طلبك بنجاح 🏜\n\n⌯︙بواسطة -› %1\n⌯︙استغرق -› %2 🧭\n⌯︙الوقت -› %3 ⌚\n⌯︙التاريخ -› %4 📚",
    Error: "حدث خطأ أثناء إنشاء الصور."
  },
  En: {
    User: "Facebook User",
    ProvideText: "You didn't provide any text.",
    Done: "✅ | Your request has been successfully completed 🏜\n\n⌯︙By -› %1\n⌯︙Took -› %2 🧭\n⌯︙Time -› %3 ⌚\n⌯︙Date -› %4 📚",
    Error: "An error occurred while generating the images."
  }
}
const openai = new OpenAI({
  apiKey: global.Settings.OpenAi
});

module.exports.Begin = async function ({
  args,
  Message,
  event,
  usersData,
  getLang: GetLang
}) {
  try {
    Message.React("⚙️");

    const txt = args.join(" ");
    const prompt = txt.split("--ar")[0];

    if (!prompt) {
      return Message.reply(GetLang("ProvideText"));
    }

    const Ratio = {
      "1:1": "1024x1024",
      "4:7": "1024x1792",
      "7:4": "1792x1024"
    };

    let ratio = "1:1";
    const Supported = Object.keys(Ratio);
    const Rindex = args.find(arg => Supported.includes(arg));
    if (Rindex) ratio = Rindex;

    const TP = await Funcs.translate(prompt, "ar", "en");
    const Images = [];
    const startTime = new Date();

    for (let i = 0; i < 4; i++) {
      const response = await openai.images.generate({
        model: "dall-e-3",
        prompt: TP,
        size: Ratio[ratio]
      });
      Images.push(response.data[0].url);
    }

    const userName =
      (await usersData.getName(event.SenderID)) || GetLang("User");

    const endTime = new Date();
    const drawingTime = (endTime - startTime) / 1000;

    const currentDate = moment
      .tz(global.Settings.TimeZone)
      .format("YYYY-MM-DD");

    const currentTime = moment
      .tz(global.Settings.TimeZone)
      .format("h:mm:ss A");

    Message.React("✔️");
    Message.Reply({
      Body: GetLang(
        "Done",
        userName,
        drawingTime,
        currentTime,
        currentDate
      ),
      Attachment: Images
    });

  } catch (e) {

    Message.React("❌");
    Message.Reply(GetLang("Error"));
  }
};
