const axios = require("axios");

module.exports = {
  Emma: {
    name: "مجموعتي",
    Aliases: ["boxinfo"],
    Author: "Shady Tarek",
    Role: 0,
    Rest: 0,
    Description: "",
    Class: "ثريدز",
  },

  languages: {
    En: {
      Msg:
        `[⚜️] » Group Name: %1\n\n` +
        `[⚜️] » ID: %2\n\n` +
        `[⚜️] » Join Requests: %3\n\n` +
        `[⚜️] » Information : There is %4 member\n\n` +
        `[⚜️] » Emoji: %5\n\n` +
        `[⚜️] » Number of admins: %6\n\n` +
        `[⚜️] » Number of males: %7\n\n` +
        `[⚜️] » Number of females: %8\n\n` +
        `[⚜️] » Total number of messages: %9`,
      On: "On",
      Off: "Off",
    },
    Ar: {
      Msg:
        `[⚜️] » اسم المجموعة : %1\n\n` +
        `[⚜️] » المعرف : %2\n\n` +
        `[⚜️] » طلبات الانضمام : %3\n\n` +
        `[⚜️] » المعلومات : يوجد %4 عضو\n\n` +
        `[⚜️] » الايموجي : %5\n\n` +
        `[⚜️] » عدد الإداريين : %6\n\n` +
        `[⚜️] » عدد الذكور : %7\n\n` +
        `[⚜️] » عدد الإناث : %8\n\n` +
        `[⚜️] » العدد الإجمالي للرسائل : %9`,
      On: "مفعلة",
      Off: "غير مفعلة",
    },
  },

  Begin: async function ({ api, event, Message, getLang: GetLang }) {
    try {
      const threadInfo = await api.GetThreadInfo(event.ThreadID);

      const threadMem = threadInfo.ParticipantIDs.length;
      const adminCount = threadInfo.adminIDs.length;
      const messageCount = threadInfo.messageCount;

      let males = 0;
      let females = 0;

      for (const u of threadInfo.userInfo) {
        if (u.gender === "MALE") males++;
        else if (u.gender === "FEMALE") females++;
      }

      const approval =
        threadInfo.approvalMode === true
          ? GetLang("On")
          : GetLang("Off");

      let Image;
      try {
        Image = await Funcs.Upscale(threadInfo.imageSrc);
      } catch {
        Image = null;
      }

      await Message.reply({
        Body: GetLang(
          "Msg",
          threadInfo.threadName,
          threadInfo.ThreadID,
          approval,
          threadMem,
          threadInfo.emoji,
          adminCount,
          males,
          females,
          messageCount
        ),
        Attachment: Image,
      });
    } catch (e) {
      Message.react("❌");
    }
  },
};
