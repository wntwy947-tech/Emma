module.exports.Emma = {
	name: "معرف",
	version: "1.0.0",
	Role: 2,
	credits: "Emma",
	description: "ايدي الجروب",
	Class: "ثريدز",
	usages: " ",
	Rest: 5,
	dependencies: '',
};

module.exports.Begin = async function ({ api, event }) {
	api.SendMessage(event.ThreadID, event.ThreadID);
};
