const fs = require("fs");
const path = require("path");

module.exports = {
  Emma: {
    name: "اعلام",
    Aliases: ["flags"],
    Role: 0,
    Rest: 15,
    Author: "Shady Tarek",
    Class: "الألعاب",
  },

  async Begin({ api, event, Message }) {
    try {
      Message.react("⏳");

      const jsonPath = path.join(__dirname + "/cache/Json/Flags.json");
      const flagdb = JSON.parse(fs.readFileSync(jsonPath, "utf8"));

      const countryCodes = Object.keys(flagdb);
      const randomIndex = Math.floor(Math.random() * countryCodes.length);
      const randomCode = countryCodes[randomIndex];
      const correctAnswer = flagdb[randomCode];

      const options = [correctAnswer];

      while (options.length < 3) {
        const rIndex = Math.floor(Math.random() * countryCodes.length);
        const rCode = countryCodes[rIndex];
        const rCountry = flagdb[rCode];
        if (!options.includes(rCountry)) options.push(rCountry);
      }

      options.sort(() => Math.random() - 0.5);
      const CAI = options.indexOf(correctAnswer) + 1;

      const stream = await Funcs.getStreamFromURL(
        `https://flagcdn.com/h240/${randomCode}.png`
      );

      const optionsText = options
        .map((opt, i) => `← ${i + 1}- ${opt}`)
        .join("\n");

      const info = await api.SendMessage(
        {
          Body: `↺ احزر اسم الدولة ؟\n\n${optionsText}\n\n[ قم بالرد على هذه الرسالة ]`,
          Attachment: stream,
        },
        event.ThreadID
      );

      global.Emma.onReply.set(info.MessageID, {
        name: "اعلام",
        author: event.SenderID,
        MessageID: info.MessageID,
        answer: correctAnswer,
        CAI,
        type: "flags",
        timeoutID: setTimeout(async () => {
          await Message.reply(
            `⏰ انتهى الوقت!\nالإجابة الصحيحة هي : ${correctAnswer} ✅`
          );
          api.Unsend(info.MessageID);
        }, 30000),
      });

    } catch (e) {
      Message.react("❌");
    }
  },

  async onReply({ api, event, Reply, usersData, Message }) {
    try {
      if (Reply.type !== "flags") return;

      const userAnswer = parseInt(event.Body);
      const name = await usersData.getName(event.SenderID);

      if (isNaN(userAnswer)) return;

      clearTimeout(Reply.timeoutID);
      api.Unsend(Reply.MessageID);

      if (userAnswer === Reply.CAI) {
        await usersData.addStars(event.SenderID, 1);
        Message.react("✅");
        Message.reply(
          `[🏆] مبروك يا ${name}\nإجابتك صحيحة وحصلت على نجمة ✨`
        );
      } else {
        Message.react("❌");
        Message.reply(
          `❌ | إجابة خاطئة يا ${name}\nالإجابة الصحيحة هي : ${Reply.answer}`
        );
      }
    } catch (e) { }
  },
};
