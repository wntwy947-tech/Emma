const fs = require("fs-extra");
const { Mods } = global;

module.exports = {
  Emma: {
    name: "بريفكس",
    version: "1.3",
    Credits: "Emma",
    Rest: 5,
    Role: 3,
    Class: "الأدمن"
  },

  languages: {
    Ar: {
      reset: "تم إعادة تعيين البادئة الافتراضية : %1",
      onlyAdmin: "فقط المطور يستطيع تغيير بادئة النظام",
      confirmGlobal: "تفاعل علي الرسالة لتغيير بادئة النظام كله",
      confirmThisThread: "تفاعل علي هذه الرسالة لتغيير بادئة المجموعة",
      successGlobal: "تم تغيير البادئة الافتراضية للنظام الي: %1",
      successThisThread: "تم تغيير البادئة الخاصة بالمجموعة الي : %1",
      myPrefix: "🌐 | بادئة النظام : %1\n🛸 | بادئة المجموعة: %2"
    }
  },

  Begin: async function ({ Message, Role, args, event, threadsData, getLang }) {

    if (args[0] == 'ترسيت') {
      await threadsData.set(event.ThreadID, null, "data.prefix");
      return Message.reply(getLang("reset", global.Settings.PREFIX));
    }

    const newPrefix = args[0];
    const formSet = {
      Emma: {
        name: this.Emma.name,
        author: event.SenderID,
        newPrefix
      }
    };

    if (args[1] === "عام") {
      if (Role < 3)
        return Message.reply(getLang("onlyAdmin"));
      else
        formSet.Emma.setGlobal = true;
    } else {
      formSet.Emma.setGlobal = false;
    }

    return Message.reply(args[1] === "عام" ? getLang("confirmGlobal") : getLang("confirmThisThread"), (err, info) => {
      formSet.Emma.MessageID = info.MessageID;
      global.Emma.onReaction.set(info.MessageID, formSet.Emma);
    });
  },

  onReaction: async function ({ Message, threadsData, event, onReaction, getLang }) {
    const { author, newPrefix, setGlobal } = onReaction;
    if (event.UserID !== author)
      return;
    if (setGlobal) {
      global.Settings.PREFIX = newPrefix;
      fs.writeFileSync(global.Emma.SettingsDir, JSON.stringify(global.Settings, null, 2));
      return Message.reply(getLang("successGlobal", newPrefix));
    } else {
      await threadsData.set(event.ThreadID, newPrefix, "data.prefix");
      return Message.reply(getLang("successThisThread", newPrefix));
    }
  },

  onEvent: async function ({ event, Message, getLang }) {
    if (event.Body && (event.Body.toLowerCase() === "بادئة" || event.Body.toLowerCase() === "prefix")) {
      return Message.reply(getLang("myPrefix", global.Settings.PREFIX, global.Funcs.getPrefix(event.ThreadID)));
    }
  }
};