module.exports = {
  Emma: {
    name: "خزنه",
    Aliases: ["خزنة", "clipboard"],
    Role: 0,
    Rest: 0,
    Description: "تخزين نصوص وميديا",
    Class: "خدمات",
  },

  Begin: async function ({ args, event, Message, usersData }) {
    try {
      const sub = args[0];
      let user = await usersData.get(event.SenderID);
      if (!user) await usersData.create(event.SenderID);

      if (sub === "تخزين") {
        return Message.reply(
          `مرحبا بك فالامر التخزين 👨‍💼
رد بعنوان النص لبدك تخزنو ✅`,
          (err, info) => {
            if (err) return;
            global.Emma.onReply.set(info.MessageID, {
              name: "خزنه",
              type: "title",
              sid: event.SenderID,
              MessageID: info.MessageID,
            });
          }
        );
      }

      if (sub === "عرض") {
        const data = await usersData.get(event.SenderID);
        const clipboard = data?.data?.clipboard || [];

        if (!clipboard.length)
          return Message.reply("ما عندك ولا نص حافظه 😔👍");

        let msg = `✅ عناوين النصوص لانت حافظها ✅\n\n`;
        clipboard.forEach((o, i) => {
          msg += `${i + 1} ⋆˚ ⬷ ${o.title}\n\n`;
        });
        msg += `رد برقم العنوان لبدك عرضه:\n\nالعدد: ${clipboard.length} 🦊`;

        return Message.reply(msg, (err, info) => {
          if (err) return;
          global.Emma.onReply.set(info.MessageID, {
            name: "خزنه",
            type: "showText",
            sid: event.SenderID,
            MessageID: info.MessageID,
          });
        });
      }

      if (sub === "ميديا") {
        if (!event.MessageReply?.Attachments?.length)
          return Message.reply("رد على صورة او فيديو او اوديو ...");

        const media = [];
        for (const a of event.MessageReply.Attachments) {
          media.push(
            await Funcs.topMedia(
              a.Url,
              a.Type === "Video"
                ? "mp4"
                : a.type === "Audio"
                  ? "mp3"
                  : "png"
            )
          );
        }

        return Message.reply("اختر عنوان للميديا", (err, info) => {
          if (err) return;
          global.Emma.onReply.set(info.MessageID, {
            name: "خزنه",
            type: "media",
            sid: event.SenderID,
            MessageID: info.MessageID,
            media,
          });
        });
      }

      if (sub === "مشاهدة") {
        const data = await usersData.get(event.SenderID);
        const media = data?.data?.media || [];

        if (!media.length)
          return Message.reply("ما عندك ولا ميديا حافظه 😔👍");

        let msg = `✅ عناوين الميديا لانت حافظها ✅\n\n`;
        media.forEach((o, i) => {
          msg += `${i + 1} ⋆˚ ⬷ ${o.title}\n\n`;
        });
        msg += `رد برقم العنوان لبدك عرضه:\n\nالعدد: ${media.length} 🦊`;

        return Message.reply(msg, (err, info) => {
          if (err) return;
          global.Emma.onReply.set(info.MessageID, {
            name: "خزنه",
            type: "showMedia",
            sid: event.SenderID,
            MessageID: info.MessageID,
          });
        });
      }

      return Message.reply(
        "الأدوات المتوفرة\n\n" +
        "عرض: عرض النصوص 🗄️\n" +
        "تخزين: تخزين نص جديد 🦊\n" +
        "ميديا: حفظ ميديا 😡\n" +
        "مشاهدة: مشاهدة الميديا 👽"
      );
    } catch (err) {
      console.error(err);
      Message.reply("حدث خطأ ❎");
    }
  },

  onReply: async function ({ event, Message, usersData, Reply }) {
    try {
      if (event.SenderID !== Reply.sid) return;

      const data = await usersData.get(event.SenderID);
      const bro = data?.data || {};

      if (Reply.type === "title") {
        Message.unsend(Reply.MessageID);
        if (bro.clipboard?.find((x) => x.title === event.Body))
          return Message.reply("العنوان موجود بالفعل ❌");

        return Message.reply("الان رد بالنص ✍️", (e, info) => {
          if (e) return;
          global.Emma.onReply.set(info.MessageID, {
            name: "خزنه",
            type: "text",
            sid: event.SenderID,
            title: event.Body,
            MessageID: info.MessageID,
          });
        });
      }

      if (Reply.type === "text") {
        Message.unsend(Reply.MessageID);
        bro.clipboard = bro.clipboard || [];
        bro.clipboard.push({ title: Reply.title, text: event.Body });
        await usersData.set(event.SenderID, bro.clipboard, "data.clipboard");
        return Message.reply("تم حفظ النص بنجاح ✅");
      }

      if (Reply.type === "showText") {
        const idx = parseInt(event.Body) - 1;
        const clip = bro.clipboard?.[idx];
        if (!clip) return Message.reply("رقم غير صحيح ❌");
        return Message.reply(`العنوان: ${clip.title}\n\n${clip.text}`);
      }

      if (Reply.type === "media") {
        Message.unsend(Reply.MessageID);
        bro.media = bro.media || [];
        bro.media.push({ title: event.Body, media: Reply.media });
        await usersData.set(event.SenderID, bro.media, "data.media");
        return Message.reply("تم حفظ الميديا بنجاح ✅");
      }

      if (Reply.type === "showMedia") {
        const idx = parseInt(event.Body) - 1;
        const m = bro.media?.[idx];
        if (!m) return Message.reply("رقم غير صحيح ❌");

        const files = [];
        for (const one of m.media) {
          files.push(await Funcs.getStreamFromURL(one));
        }
        return Message.reply({
          Body: `العنوان: ${m.title}`,
          Attachment: files,
        });
      }
    } catch (err) {
      console.error(err);
      Message.reply("حدث خطأ أثناء تنفيذ العملية ❎");
    }
  },
};
