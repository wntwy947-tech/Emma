module.exports = {
  Emma: {
    name: "طرد",
    Aliases: ["kick"],
    Author: "Shady Tarek",
    Role: 1,
    Rest: 0,
    Description: "",
    Class: "ثريدز",
  },
  languages: {
    Ar: {
      needPermssion: "⚠️ | صعدني ادمن لاستطيع طرد الاعضاء",
      missingTag: "⚠️ | الرجاء عمل تاغ او الرد علي رساله",
    },
  },
  Begin: async function ({ api, event, Message, threadsData, getLang: GetLang }) {
    try {
      const threadData = await threadsData.get(event.ThreadID);

      if (!threadData.adminIDs.includes(api.CurrentID())) {
        return Message.reply(GetLang("needPermssion"));
      }

      let targetIDs = [];
      const mention = Object.keys(event.Mentions || {});

      if (mention.length === 0 && event.MessageReply) {
        targetIDs.push(event.MessageReply.SenderID);
      } else if (mention.length !== 0 && !event.MessageReply) {
        targetIDs = mention;
      }

      if (targetIDs.length === 0) {
        return Message.reply(GetLang("missingTag"));
      }

      for (const targetID of targetIDs) {
        if (
          threadData.adminIDs.includes(targetID) &&
          event.SenderID !== global.Settings.OwnerID
        ) {
          return Message.reply("⚠️ | لا استطيع طرد ادمن");
        }

        if (
          global.Settings.OwnerID === targetID &&
          event.SenderID !== global.Settings.OwnerID
        ) {
          return api.Kick(event.SenderID, event.ThreadID);
        }


        Message.react("✅");
        await api.Kick(targetID, event.ThreadID);
      }
    } catch (e) {
      console.log(e);
      Message.react("❌");
    }
  },
};
