const moment = require("moment-timezone");
moment.tz.setDefault("Africa/Algiers");

module.exports = {
  Emma: {
    name: "هدية",
    aliases: ["daily", "gift"],
    version: "1.2",
    author: "Emma",
    description: "احصل على هديتك اليومية",
    Role: 0,
    cooldown: 5,
    Class: "اقتصاد"
  },

  Begin: async function ({ event, usersData, Message }) {
    const userID = event.SenderID;

    try {
      const userData = await usersData.get(userID);
      const lastClaim = userData?.data?.lastDaily || 0;
      const now = Date.now();
      const cooldown = 24 * 60 * 60 * 1000;

      if (now - lastClaim < cooldown) {
        const timeLeft = cooldown - (now - lastClaim);
        const hours = Math.floor(timeLeft / (60 * 60 * 1000));
        const minutes = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));

        return Message.reply(
          `لقد أخذت هديتك اليوم.\nالوقت المتبقي: ${hours}س ${minutes}د`
        );
      }

      const moneyReward = Math.floor(Math.random() * (500 - 100 + 1)) + 100;

      userData.money = (userData.money || 0) + moneyReward;
      userData.data.lastDaily = now;

      await usersData.set(userID, userData);

      return Message.reply(
        `تمت إضافة ${moneyReward}$ إلى رصيدك.\nرصيدك الحالي: ${userData.money}$`
      );

    } catch (err) {
      console.error("Error in daily command:", err);
      return Message.reply("حدث خطأ أثناء الحصول على الهدية");
    }
  }
};