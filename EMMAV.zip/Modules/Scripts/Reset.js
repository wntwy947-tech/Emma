const fs = require("fs-extra");
const path = require("path");

module.exports = {
  Emma: {
    name: "ترسيت",
    Aliases: ["reset", "restart"],
    version: "1.0",
    credits: "Emma",
    Rest: 5,
    Role: 3,
    description: "",
    Class: "الأدمن"
  },

  Start: function ({ api }) {
    const pathFile = `${__dirname}/cache/restart.txt`;
    if (fs.existsSync(pathFile)) {
      const [tid, mid, time] = fs.readFileSync(pathFile, "utf-8").split(" ");
      api.ReactHttp("✅", mid, (err) => { }, true)
      api.SendMsgHttp(`✅ | تمت إعادة تشغيل ايما\n⏰ | الوقت : ${(Date.now() - time) / 1000}s`, tid);
      fs.unlinkSync(pathFile);
    }

    const cachePath = path.join(__dirname, "cache");
    fs.readdir(cachePath, (err, files) => {
      if (err) {

        return;
      }

      files.forEach((file) => {
        const fileExt = path.extname(file).toLowerCase();
        if (fileExt === ".png" || fileExt === ".jpg" || fileExt === ".mp4" || fileExt === ".gif") {
          const filePath = path.join(cachePath, file);
          fs.unlink(filePath, (err) => {
            if (err) {
              console.error("Error deleting file:", err);
            }
          });
        }
      });
    });
  },
  Begin: async function ({ Message, event }) {
    Message.react("🔄");
    const pathFile = `${__dirname}/cache/restart.txt`;
    fs.writeFileSync(pathFile, `${event.ThreadID} ${event.MessageID} ${Date.now()}`);
    await Message.reply("🔄 | إعادة تشغيل ايما...", () => {
      eval("process.exit(1)");
    });
  }
};