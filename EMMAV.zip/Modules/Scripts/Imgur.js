const { ImgurClient } = require("imgur");
const axios = require("axios");

module.exports = {
  Emma: {
    name: "ايمجر",
    Version: "1.1.5",
    Role: 0,
    Author: "Shady Tarek",
    Description: "رفع الصور والفيديوهات",
    Class: "خدمات",
  },

  languages: {
    Ar: {
      Reply: "🖼️ | قم بالرد على صورة أو فيديو!",
      Done: "%1",
      Error: "❌ | حدث خطأ أثناء عملية الرفع",
    },
    En: {
      Reply: "🖼️ | Please reply to an image or video!",
      Done: "✅ | Upload Completed Successfully\n⌯︙Links:\n%1\n⌯︙Total Files › %2",
      Error: "❌ | An error occurred while uploading",
    },
  },

  Begin: async function ({ Message, event, getLang: GetLang }) {
    try {
      const imgur = new ImgurClient({
        clientId: "b88f92544843717",
      });

      if (
        event.Type !== "Message_Reply" ||
        !event.MessageReply?.Attachments?.length
      ) {
        return Message.reply({
          Body: GetLang("Reply"),
        });
      }

      Message.React("⚙️");

      const links = [];

      for (const { Url } of event.MessageReply.Attachments) {
        const response = await axios.get(Url, {
          responseType: "stream",
        });

        const res = await imgur.upload({
          image: response.data,
          type: "stream",
        });
        links.push(res.data.link);
      }

      Message.React("✔️");
      Message.reply({
        Body: GetLang("Done", links.join("\n"), links.length),
      });
    } catch (e) {
      console.log(e);
      Message.reply({
        Body: GetLang("Error"),
      });
    }
  },
};
