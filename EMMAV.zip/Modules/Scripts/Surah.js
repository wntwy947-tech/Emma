const axios = require("axios");
const fs = require("fs");
const path = require("path");

const SURAH_NAMES_FILE = path.join(
  __dirname + "/cache/Json/Surah.json"
);

function loadSurahNames() {
  try {
    return JSON.parse(fs.readFileSync(SURAH_NAMES_FILE, "utf-8"));
  } catch {
    return {};
  }
}

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

module.exports = {
  Emma: {
    name: "آية",
    Aliases: ["surah"],
    Author: "Shady Tarek",
    Role: 0,
    Rest: 5,
    Description: "احزر اسم السورة",
    Class: "الألعاب",
  },

  Begin: async function ({ Message }) {
    try {
      const getRandomSurah = async () => {
        const num = Math.floor(Math.random() * 108) + 1;
        const res = await axios.get(
          `https://api.alquran.cloud/v1/surah/${num}`
        );
        return res.data.data;
      };

      const getRandomAyah = (surah) => {
        const num = Math.floor(Math.random() * surah.numberOfAyahs) + 1;
        return surah.ayahs.find(
          (a) => a.numberInSurah === num
        );
      };

      const surahData = await getRandomSurah();
      const surahNames = loadSurahNames();
      const ayah = getRandomAyah(surahData);

      const correctName = surahNames[surahData.name];
      if (!correctName || !ayah) return;

      const wrongOptions = shuffleArray(
        Object.values(surahNames).filter(
          (n) => n !== correctName
        )
      ).slice(0, 2);

      const options = shuffleArray([
        ...wrongOptions,
        correctName,
      ]);

      await Message.reply({
        Body: `${ayah.text}
${options.map(o => `↫. ${o}`).join("\n")}

⌯︙ احزر اسم السورة من الآية ☝`,
      });

      global.Emma.Listen.set(
        Math.floor(Math.random() * 10000),
        {
          condition: `event.Body.toLowerCase() === "${correctName.toLowerCase()}"`,
          result: `async () => {
            try {
              Message.react("✅");
              Message.reply(
                "⌯ | " +
                  await usersData.getName(event.SenderID) +
                  " ↫ قام بارسال اسم السورة الصحيحة : ${correctName}"
              );
              await usersData.addStars(event.SenderID, 1);
            } catch (e) {}
          }`,
        }
      );
    } catch (e) {
      Message.react("❌");
    }
  },
};
