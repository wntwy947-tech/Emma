const request = require("request");

module.exports = {
  Emma: {
    name: "ترجمي",
    Aliases: ["trans", "translate"],
    Version: "2.2.0",
    Role: 0,
    Author: "Shady Tarek",
    Description: "يترجم النصوص",
    Rest: 5,
    Class: "خدمات",
  },

  languages: {
    Ar: {
      NoText: "⚠️ | يجب كتابة نص أو الرد على رسالة",
      Error: "⚠️ | حدث خطأ!",
      Result: "%1\n\n🌐 الترجمة من %2 إلى %3",
    },
    En: {
      NoText: "⚠️ | You must write text or reply to a message",
      Error: "⚠️ | An error occurred!",
      Result: "%1\n\n🌐 Translated from %2 to %3",
    },
  },

  Begin: async function ({ Message, event, args, getLang: GetLang }) {
    let translateThis = "";
    let lang = "ar";

    if (event.Type === "Message_Reply") {
      translateThis = event.MessageReply.Body || "";

      const langIndex = args.findIndex(
        a => a === "--lang" || a === "--اللغة"
      );
      if (langIndex !== -1 && args[langIndex + 1]) {
        lang = args[langIndex + 1].toLowerCase();
      }
    } else {
      if (!args.length) {
        return Message.reply({
          Body: GetLang("NoText"),
        });
      }

      const langIndex = args.findIndex(
        a => a === "--lang" || a === "--اللغة"
      );
      if (langIndex !== -1 && args[langIndex + 1]) {
        lang = args[langIndex + 1].toLowerCase();
        args.splice(langIndex, 2);
      }

      translateThis = args.join(" ");
    }

    switch (lang) {
      case "ar":
      case "arabic":
        lang = "ar";
        break;
      case "en":
      case "english":
        lang = "en";
        break;
      case "fr":
      case "french":
        lang = "fr";
        break;
      case "de":
      case "german":
        lang = "de";
        break;
      case "es":
      case "spanish":
        lang = "es";
        break;
      case "it":
      case "italian":
        lang = "it";
        break;
      case "ja":
      case "japanese":
        lang = "ja";
        break;
      case "ko":
      case "korean":
        lang = "ko";
        break;
      case "ru":
      case "russian":
        lang = "ru";
        break;
      case "zh":
      case "chinese":
        lang = "zh-CN";
        break;
      default:
        lang = "ar";
    }

    return request(
      encodeURI(
        `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${translateThis}`
      ),
      (err, response, body) => {
        if (err) {
          return Message.reply({
            Body: GetLang("Error"),
          });
        }

        const data = JSON.parse(body);
        let text = "";

        data[0].forEach(item => {
          if (item[0]) text += item[0];
        });

        const fromLang = data[2];

        Message.reply({
          Body: GetLang("Result", text, fromLang, lang),
        });
      }
    );
  },
};
