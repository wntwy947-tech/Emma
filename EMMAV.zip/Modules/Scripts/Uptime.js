const os = require("os");
const si = require("systeminformation");
const axios = require("axios");
const moment = require("moment-timezone");

module.exports = {
  Emma: {
    name: "up",
    Version: "1.3.1",
    Role: 3,
    Author: "Shady Tarek",
    Class: "الأدمن",
    Rest: 5,
  },

  Begin: async function ({ api, Message }) {

    function formatUptime(sec) {
      const d = Math.floor(sec / 86400);
      const h = Math.floor((sec % 86400) / 3600);
      const m = Math.floor((sec % 3600) / 60);
      const s = Math.floor(sec % 60);
      return `${d}d ${h}h ${m}m ${s}s`;
    }

    const sent = await Message.reply("⏳ Getting server info...");

    const now = moment().tz(global.Settings.TimeZone);
    const dateStr = now.format("MMM D, YYYY");
    const timeStr = now.format("hh:mm:ss A");

    let ping;
    try {
      const startPing = Date.now();
      await axios.get("https://www.google.com", { timeout: 5000 });
      ping = Date.now() - startPing;
    } catch {
      ping = 999;
    }

    const cpuData = await si.cpu();
    const cpuLoad = await si.currentLoad();

    const cpuModel = `${cpuData.manufacturer} ${cpuData.brand}`.trim();
    const cpuCores = cpuData.cores;
    const cpuUsage = cpuLoad.currentLoad.toFixed(1);

    const mem = await si.mem();
    const totalRAM = (mem.total / 1024 / 1024).toFixed(0);
    const usedRAM = (mem.used / 1024 / 1024).toFixed(0);
    const freeRAM = (mem.free / 1024 / 1024).toFixed(0);

    const disks = await si.fsSize();

    let totalDisk = 0;
    let usedDisk = 0;

    disks.forEach(d => {
      totalDisk += d.size;
      usedDisk += d.used;
    });

    totalDisk = (totalDisk / 1024 / 1024 / 1024).toFixed(1);
    usedDisk = (usedDisk / 1024 / 1024 / 1024).toFixed(1);
    const freeDisk = (totalDisk - usedDisk).toFixed(1);

    const runtime = formatUptime(process.uptime());
    const platform = os.platform();
    const arch = os.arch();
    const hostname = os.hostname();

    const nets = os.networkInterfaces();
    let ip = "Unknown";

    for (const name in nets) {
      for (const net of nets[name]) {
        if (net.family === "IPv4" && !net.internal) {
          ip = net.address;
          break;
        }
      }
    }

    let status;

    if (ping < 150 && cpuUsage < 50 && usedRAM < totalRAM * 0.6)
      status = "✅ | Smooth System";
    else if (ping < 400)
      status = "⚠️ | Moderate Load";
    else
      status = "❌ | Heavy Load";

    function line(label, value) {
      return `❁┊🔹 ${label}: ${value}`;
    }

    const msg = `
◈ ──『 ❀ UPTIME INFO ❀ 』── ◈

❁┊⏰ Runtime
${line("Time", runtime)}

❁┊👑 System Info
${line("OS", `${platform} ${arch}`)}

${line("CPU Model", cpuModel)}
${line("CPU Cores", cpuCores)}
${line("CPU Usage", `${cpuUsage} %`)}

${line("RAM Total", `${totalRAM} MB`)}
${line("RAM Used", `${usedRAM} MB`)}
${line("RAM Free", `${freeRAM} MB`)}

${line("Storage Total", `${totalDisk} GB`)}
${line("Storage Used", `${usedDisk} GB`)}
${line("Storage Free", `${freeDisk} GB`)}


❁┊✅ Other Info
${line("Date", dateStr)}
${line("Time", timeStr)}
${line("Ping", `${ping * 10} ms`)}
${line("Status", status)}

◈ ──────────── ◈
`;

    await api.EditMessage(sent.MessageID, msg);
  }
};
