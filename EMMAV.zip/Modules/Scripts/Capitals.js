const fs = require("fs");
const path = require("path");

const capitalsFilePath = path.join(
  __dirname + "/cache/json/Capitals.json"
);

module.exports = {
  Emma: {
    name: "عواصم",
    Aliases: ["capitals"],
    Author: "Shady Tarek",
    Role: 0,
    Rest: 5,
    Description: "لعبة عواصم",
    Class: "الألعاب",
  },

  Begin: async function ({ Message, event }) {
    try {
      const capitals = JSON.parse(
        fs.readFileSync(capitalsFilePath, "utf-8")
      );

      const randomIndex = Math.floor(Math.random() * capitals.length);
      const randomCapital = capitals[randomIndex];

      await Message.reply({
        Body: `⌯︙عاصمة ${randomCapital.country} ؟`,
      });

      global.Emma.Listen.set(Math.floor(Math.random() * 10000), {
        condition: `event.Body.toLowerCase() === "${randomCapital.city.toLowerCase()}"`,
        result: `async () => {
          try {
            Message.react("✅");
            Message.reply(
              "⇜ | " +
                await usersData.getName(event.SenderID) +
                " ألف مبروك 🎉، الإجابة صحيحة، عاصمة " +
                "${randomCapital.country} هي : ${randomCapital.city}"
            );
            await usersData.addStars(event.SenderID, 1);
          } catch (e) {}
        }`,
      });
    } catch (e) {
      Message.React("❌");
    }
  },
};
