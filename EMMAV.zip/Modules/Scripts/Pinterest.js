module.exports = {
  Emma: {
    name: "بينت",
    Author: "Shady Tarek",
    Rest: 10,
    Description: "",
    Role: 0,
    Class: "خدمات",
  },

  languages: {
    En: {
      WrongUsage:
        "❌ | Invalid usage. Please type something to search for or reply with an image.",
      Result:
        '🔍 Search Results: %1  \n📌 Request: %2 \n↪️ Reply with "more" for more',
      Ended: "✅ | No More Results To Get.",
    },
    Ar: {
      WrongUsage:
        "❌ | استخدام خاطئ، يرجى كتابة شيء للبحث أو الرد بصورة.",
      Result:
        '🔍 نتائج البحث: %1  \n📌 الطلب: %2 \n↪️ رد ب "المزيد" للمزيد',
      Ended: "✅ | لا يوجد المزيد من النتائج.",
    },
  },

  Begin: async function ({ event, args, Message, getLang: GetLang }) {
    try {
      let data;
      const keySearch = args.join(" ");

      Message.React("⚙️");

      if (
        !keySearch &&
        event.MessageReply?.Attachments?.[0]?.Type !== "Photo"
      ) {
        return Message.reply({
          Body: GetLang("WrongUsage"),
        });
      }

      if (event.MessageReply?.Attachments?.[0]?.Type === "Photo") {
        data = await Funcs.PinLens(
          event.MessageReply.Attachments[0].Url
        );
      } else {
        data = await Funcs.Pinterest(keySearch);
      }

      const firstBatch = await Promise.all(
        data.slice(0, 20).map(d => Funcs.getStreamFromURL(d))
      );

      Message.React("✔️");

      const info = await Message.reply({
        Attachment: firstBatch,
        Body: GetLang("Result", data.length, keySearch),
      });

      global.Emma.onReply.set(info.MessageID, {
        name: "بينت",
        MessageID: info.MessageID,
        Items: data,
        Max: 20,
        Length: data.length,
        Search: keySearch,
        Author: event.SenderID,
      });
    } catch (e) {
      console.log(e)
      Message.React("❌");
    }
  },

  onReply: async function ({ event, Message, getLang: GetLang, onReply }) {
    try {
      if (onReply.Author !== event.SenderID) return;
      if (
        event.Body !== "المزيد" &&
        event.Body?.toLowerCase() !== "more"
      ) {
        return;
      }

      Message.React("⚙️");

      const Min = onReply.Max;
      const Max = Min + 20;

      if (Min >= onReply.Items.length) {
        return Message.reply({
          Body: GetLang("Ended"),
        });
      }

      const nextBatch = await Promise.all(
        onReply.Items.slice(Min, Max).map(d => Funcs.getStreamFromURL(d))
      );

      Message.React("✔️");

      const info = await Message.reply({
        Attachment: nextBatch,
        Body: GetLang("Result", onReply.Length, onReply.Search),
      });

      global.Emma.onReply.delete(onReply.MessageID);
      global.Emma.onReply.set(info.MessageID, {
        name: "بينت",
        MessageID: info.MessageID,
        Items: onReply.Items,
        Max: Max,
        Length: onReply.Length,
        Search: onReply.Search,
        Author: event.SenderID,
      });
    } catch (e) {
      console.log(e)
      Message.React("❌");
    }
  },
};
