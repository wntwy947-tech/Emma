module.exports = {
  Emma: {
    name: "لبرومبت",
    Aliases: ["prompt", "pr"],
    Author: "Shady Tarek",
    Role: 0,
    Rest: 30,
    Description: "",
    Class: "الذكاء",
  },
  languages: {
    Ar: {
      SendImageOrLink: "ارسل صورة او رابط.⚠️",
      CreatingText: "جاري صنع نص من الصورة..⌛",
      Error: "❌ | حدث خطاء اثناء تحويل الصورة الى نص ",
    },
    En: {
      SendImageOrLink: "Send an image or a link.⚠️",
      CreatingText: "Creating text from the image..⌛",
      Error: "❌ | An error occurred while converting the image to text ",
    },
  },
  Begin: async function ({ args, event, Message, getLang: GetLang }) {
    try {
      let imageUrl;

      if (event.Type === "Message_Reply") {
        const att = event.MessageReply?.Attachments?.[0];
        if (att && ["Photo", "Sticker"].includes(att.Type)) {
          imageUrl = att.Url;
        }
      }
      else if (
        args[0]?.match(/(https?:\/\/.*\.(?:png|jpg|jpeg))/gi)
      ) {
        imageUrl = args[0];
      }

      if (!imageUrl) {
        Message.react("⚙️");
        return Message.reply(GetLang("SendImageOrLink"));
      }

      Message.react("⚙️");
      const processing = await Message.reply(
        GetLang("CreatingText")
      );

      const Gen = new Funcs.Prompt();
      const Res = await Gen.Generate(imageUrl);

      Message.react("✔️");
      await Message.unsend(processing.MessageID);

      await Message.reply(Res.descriptions[0]);
    } catch (e) {
      Message.react("❌");
      Message.reply(GetLang("Error"));
    }
  },
};
