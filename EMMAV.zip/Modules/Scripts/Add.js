const axios = require("axios");
const { findUid } = global.Funcs;

module.exports.Emma = {
  name: "ضيفي",
  Version: "1.0.0",
  Role: 1,
  Author: "Emma",
  description: "",
  Class: "ثريدز",
  usages: "",
  Rest: 5
};

module.exports.Begin = async function ({ api, event, args }) {
  const { ThreadID, MessageID } = event;

  if (!args[0]) {
    return api.SendMessage(
      "[⚜️]→ الرجاء إدخال الرابط أو معرف المستخدم الذي تريد إضافته إلى المجموعة!",
      ThreadID,
      MessageID
    );
  }

  const linkOrUid = args[0];

  try {
    let uid;
    if (linkOrUid.includes("facebook.com")) {
      uid = await findUid(linkOrUid);
    } else {
      uid = linkOrUid;
    }

    const { ParticipantIDs, approvalMode, adminIDs } = await api.GetThreadInfo(ThreadID);

    api.AddUser(uid, ThreadID, (err) => {
      if (ParticipantIDs.includes(uid)) {
        return api.SendMessage(
          "[⚜️]→ العضو موجود بالفعل في المجموعة",
          ThreadID,
          MessageID
        );
      }
      if (err) {
        return api.SendMessage(
          "[⚜️]→ لا يمكن إضافة أعضاء إلى المجموعة",
          ThreadID,
          MessageID
        );
      }
      if (approvalMode && !adminIDs.some((item) => item.id == api.CurrentID())) {
        return api.SendMessage(
          "[⚜️]→ تمت إضافة المستخدم إلى قائمة الموافقة",
          ThreadID,
          MessageID
        );
      }
      return api.SendMessage(
        "[⚜️]→ تمت إضافة أعضاء إلى المجموعة بنجاح",
        ThreadID,
        MessageID
      );
    });
  } catch (error) {
    console.error(error);
    return api.SendMessage(
      "[⚜️]→ لا يمكن إضافة أعضاء إلى المجموعة",
      ThreadID,
      MessageID
    );
  }
};
